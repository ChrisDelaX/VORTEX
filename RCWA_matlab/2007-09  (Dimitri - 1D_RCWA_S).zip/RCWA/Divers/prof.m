clear all

L=6;
h=12;

for i=1:8,
    
    for j=1:8,
        
        z(i,j)=(h/4)*cos(2*pi*i/L)+(h/4)*cos(2*pi*j/L)+h/2;
        
    end;
    
end;

surf(z); shading interp

for i=1:10,
        
        Z(i)=(i-1)*h/9;
    
        f(i)=((1/pi)*acos((2*Z(i)-h)/h));
    
end;

figure;

plot(Z,f);

clear f Z

Z(1)=h

for i=1:9,
        
        f(i)=(i*0.1)^2;
    
        Z(i+1)=h/4*cos(pi*sqrt(f(i)))+h/4*cos(pi*sqrt(f(i)))+h/2;
        
        e(i)=Z(i)-Z(i+1);
        
end;

