function[tp_inv_mat]=A_mat(E1,E2,F,N)

%Construction matrice eps

%Passage de la permittivit� du r�seau � sa transform�e de Fourier

Ftmp=F*1024;
        
for i=1:1024,
    
            if i<Ftmp
        
            Etmp(i)=1/E1;
        
            else
        
            Etmp(i)=1/E2;
            
            end
            
end
    

%Etmp=ifft(Etmp);%/(1024);

%Etmp=fftshift(Etmp);

i=-N;

for k=1:2*N+1,
    
    p=-N;
    
    for j=1:2*N+1,
        
        tp_inv_mat(k,j)=Etmp(513+(i-p));
        
        p=p+1;
        
    end;
    
i=i+1;    
    
end;

