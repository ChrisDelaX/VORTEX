%Profile trap�zoidale
%--------------------

% Remplissage Grande Base: param�tre Fa

% Remplissage Petite Base: param�tre Fb
 
% mat�riau r�seau 1: E1

% mat�riau r�seau 2: E2

% L: discr�tisation, nombre de couche

% de 1 � L, du superstrat au substrat

% profondeur totale: d

for l=1:L,
       
    pas=(Fa-Fb)/(L-1);
    
    Ftmp1=(1-(Fb+(l-1)*pas))/2*1024;

    Ftmp2=(1+(Fb+(l-1)*pas))/2*1024;
    
    for i=1:1024,
    
            if i<=Ftmp1
        
            Etmp(l,i)=E1;
        
            elseif i<=Ftmp2
            
            Etmp(l,i)=E2;
                           
            else
            
            Etmp(l,i)=E1;
            
            end;
            
end;

end;
    
    
    