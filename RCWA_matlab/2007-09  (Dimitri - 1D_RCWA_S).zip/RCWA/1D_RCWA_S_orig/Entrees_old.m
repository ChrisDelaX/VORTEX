%Configuration g�n�rale du probl�me
%----------------------------------


%Param�tres de calculs
%---------------------


    %Troncature
    
        %En X (N donc 2N+1 ordres au total)  
    
        N=8;
        
        
    %Quadrillage
    
        quad=10;
        
    
%Param�tres du r�seau
%--------------------    
    

%Nombre de couches

    L=3;

    
%Pas du r�seau

    %En X

    %Lxmin=;
    %Lxmax=;
    
    for i=1:quad,
    
    Lb_s(i)=1.21-0.050+(i-1)*0.100/quad;
    %Lb=1.21;
    
    end;

    %Lb=0.590;
    
    %Lb=2.16;
    
        %Nombre de point d'�chantillonnage
    
        %nLx=;
   
%Epaisseurs

    %dmin(l)=;
    %dmax(l)=;
    
    for i=1:quad,
        
    d_AR(i)=0.673-0.025+(i-1)*0.050/quad; %0.381e-6;
    d_znse(i)=3.35-0.050+(i-1)*0.10/quad;
    
    end;
    
    %d=2.25;
    
    %d=1.64;
    
%Permittivit�s
%-------------


    %Diamant
    %-------
    
    A_d=1 ;
    
    B_d=0.3306 ; C_d=175.0 ;
    
    D_d= 4.3356 ; E_d=106.0 ;    

    %Ge
    %--
    T=77;
    
    A_Ge=-6.040e-3*T + 11.05128 ; B_Ge = 9.295e-3*T + 4.00536 ;

    C_Ge = -5.392e-4*T + 0.599034 ; D_Ge = 4.151e-4*T + 0.09145;

    E_Ge = 1.51408*T + 3426.5 ;
    
    
    %CdTe dispersion coefficient - s2
    %---------------------------
    
    T=77;
    
    A_cdte = -2.373e-4*T + 3.8466; B_cdte = 8.057e-4*T + 3.2215;

    C_cdte = -1.10e-4*T + 0.1866; D_cdte = -2.160e-2*T + 12.718;

    E_cdte = -3.160e1*T + 18753;


    %ZnSe dispersion coefficient - s2
    %---------------------------
    
    T=298;
    
    A_ZnSe = 1; B_ZnSe = 4.46395;

    C_ZnSe = 0.20108^2; D_ZnSe = 0.46132;

    E_ZnSe = 0.39211^2; F_ZnSe = 2.88289 ;
    
    G_ZnSe = 47.04759^2 ;
    
    %Silicon dispersion coefficient - sX
    %------------------------------
    
    %T=298;
    
    %A_si=1.600e-4*T+3.431;
    
    %B_si=-2.643e-2;
    
    %C_si=4.324e-3;
    
    %D_si=-3.194e-4;
    
    %E_si=8.835e-6;

    %Permittivit�s milieu ext�rieur incident
    
    %EI=5.6644;
    
    %Permittivit�s milieu ext�rieur �mergent
    
    %EIII=1;
    
    
    %Permittivit�s du r�seau
    %-----------------------
    
        %R�seau en relief de surface
        %---------------------------
        
        
            %Permittivit� milieu 1
            
            %for i=1:10,

            %E1(1)=(1.45)^2;%(1.45+sqrt(-1)*0.0315)^2;
            %E1(2)=5.6644;
            %E1(3)=5.6644;
            
            %end;
            
            %Permittivit� milieu 2
            
            %for i=1:10,

            %E2(1)=1;
            %E2(2)=1;
            %E2(3)=(1.45)^2;
            
            %end;
            
            %Facteur de remplissage
            
                %En X
            
                %Fxmin=;
                %Fxmax=;
                
                for i=1:quad,

                F_s(i)=0.85-0.05+(i-1)*0.1/quad;
            
                end;
               
                %F=0.90;
                
                %F=0.2;
                
                    %Nombre de point d'�chantillonnage
    
                    %nFx=;

            
        %R�seau en volume
        %----------------
        
        
            %Permittivit� moyenne
            
            %epsm(l)=;
            
            %Modulation de permittivit�
            
            %modmin(l)=;
            %modmax(l)=;
            %mod(l)=;
            
                %Nombre de point d'�chantillonnage
    
                %nmod=;
            
                
                
%Incidence
%---------

    %Longueur d'onde
    
    lbmin=3.5;
    lbmax=4.1;
    %lbmax=2.18+(2.18/(2*15));
    
    %lb=2;
    
        %Nombre de point d'�chantillonnage
    
        nlb=16;

    %Angle incidence non conique
    
    %thetamin=;
    %thetamax=;
    
    %for i=1:quad,
        
        %theta_s(i)=30*pi/180+(i-1)*5/quad;
        
        %end;
    
        %for i=1:1,
        
        %theta_s=(40.2769*pi/180);%-sqrt(21-1)*0.0182*pi/180;
        
        %theta_s(i)=(40.2769*pi/180)-(0.0875*pi/180)+(i-1)*(0.0875/20)*pi/180;
        
        %theta_s(i)=38.03*pi/180-(0.0833*pi/180)+(i-1)*(0.0833/20)*pi/180;
        %theta_s(i)=0;
        
        %end;
        
        %Nombre de point d'�chantillonnage
    
        %ntheta=;
    theta=pi*0/180;
    %Angle incidence conique

    %phimin=;
    %phimax=;
    %phi=sqrt(21-1)*0.0182*pi/180;
    phi=0;
        %Nombre de point d'�chantillonnage
    
        %nlphi=;
        
    %Angle polarisation
    
    %psimax=;
    %psimin=;
    psi=pi/4;
    
        %Nombre de point d'�chantillonnage
    
        %nlpsi=;
        
    

    

    
