%Programme principal
%-------------------
%-------------------

%Gestion de la m�moire
%---------------------
%---------------------

    %Lib�ration 
    %----------

    clear all;close all;

    %Lectures des entr�es
    %--------------------
    %--------------------

    Entrees_old;
       
    %Allocation m�moire
    %------------------

    kx_mat=zeros(2*N+1);
    ky_mat=zeros(2*N+1);
    kIz_mat=zeros(2*N+1);
    kIIIz_mat=zeros(2*N+1);
    
    E=zeros(2*N+1);
    A=zeros(2*N+1);
    B=zeros(2*N+1);
    D=zeros(2*N+1);

    Omega=zeros(2*(2*N+1));
    
    Tuu_l=zeros(2*(2*N+1));
    Rud_l=zeros(2*(2*N+1));
    Rdu_l=zeros(2*(2*N+1));
    Tdd_l=zeros(2*(2*N+1));

    F_lp1=zeros(4*(2*N+1));
  
    X_lp1=zeros(2*(2*N+1));

%Choix du param�tre de boucle principale "i" et d�but boucle principale
%----------------------------------------------------------------------
%----------------------------------------------------------------------

for Lb_c=1:quad,
    
   Lb=Lb_s(Lb_c);
    
    for d_c=1:quad,
        
       d(2)=d_znse(d_c); 
       
        for d_c_ar=1:quad,
        
        d(1)=d_AR(d_c_ar);
         
        d(3)=d(1);
             
             for F_c=1:quad,
         
                F=F_s(F_c);
            
            %for theta_c=1:1,
                
                %theta=theta_s(theta_c);
                
                clear lb;
                
%Vecteur de polarisation incident
%--------------------------------

ux=cos(psi)*cos(theta)*cos(phi)-sin(psi)*sin(phi);

uy=cos(psi)*cos(theta)*sin(phi)+sin(psi)*cos(phi);

uz=-cos(psi)*sin(theta);
            
if exist('lb')==1,
    
    nlb=1;
    lbmin=lb;
    incr=0;
    
else
    
incr=(lbmax-lbmin)/nlb;

end;

for i=1:nlb,
    
    lb(i)=lbmin+(i-1)*incr;
    
    %lb_compteur=lb(i);

    
    
    %Indices des mat�riaux
    %---------------------
    
        %Indice milieu incident
        %----------------------
        
        %EIII=1;%air
        
        %Indices r�seau (milieu 1 et milieu 2)
        %-------------------------------------
        
            %couche1
            %-------
        
            YF3_data;
            
            E1(1,i)=(spline(YF3_l,YF3_n,lb(i))+sqrt(-1)*(spline(YF3_l,YF3_k,lb(i))))^2;
            
            E2(1,i)=1;
            
            %couche2
            %-------
            
            %E1(2,i)=sellmeier2(lb(i),A_cdte,B_cdte,C_cdte,D_cdte,E_cdte);
            E1(2,i)=sellmeier3(lb(i),A_ZnSe,B_ZnSe,C_ZnSe,D_ZnSe,E_ZnSe,F_ZnSe,G_ZnSe);
            %E_test(i)=E1(2);
            E2(2,i)=1;
            
            %couche3
            %-------
        
            %E1(3)=sellmeier3(lb(i),A_ZnSe,B_ZnSe,C_ZnSe,D_ZnSe,E_ZnSe,F_ZnSe,G_ZnSe);
            E1(3,i)=E1(2,i);
            E2(3,i)=E1(1,i);         
            
        %Indice substrat
        %---------------
        
        %EI=E1(2);
    
    %E1(i)=sellmeierX(lb(i),A_si,B_si,C_si,D_si,E_si);
    
    %E1(i)=sellmeier2b(lb(i),A_d,B_d,C_d,D_d,E_d);
    
    %E1(i)=sellmeier2(lb(i),A_cdte,B_cdte,C_cdte,D_cdte,E_cdte);
    
    %E1(i)=sellmeier3(lb(i),A_ZnSe,B_ZnSe,C_ZnSe,D_ZnSe,E_ZnSe,F_ZnSe,G_ZnSe);
    
    %E1(i)=7.2361;
    
    %E2=1;
    
    EI=E1(2,i);
    
    %EI=1;
    
    EIII=1;%E1(i);
    
%Calcul Vecteur d'onde
%---------------------

k=2*pi/lb(i);
    
%Boucle sur "j"
%--------------

%Construction ky
%---------------

    ky=k*sqrt(EI)*sin(theta)*sin(phi);

for j=1:2*N+1,
    
    jbis=j-(N+1);
    
    %Construction kx_vec
    %-------------------
    
    kx_vec(j)=k*(sqrt(EI)*sin(theta)*cos(phi)-jbis*(lb(i)/Lb));   
  
    %Construction kIz_vec 
    %--------------------
    
    kIz_vec(j)=sqrt(k^2*EI-(kx_vec(j))^2-(ky)^2);

    %Construction kIIIz_vec 
    %----------------------

    kIIIz_vec(j)=sqrt(k^2*EIII-(kx_vec(j))^2-(ky)^2);
    
end;%Fin de la boucle sur "j"

%Matrice kx
%----------

kx_mat=diag(kx_vec)/k;
kxoo=kx_mat(N+1,N+1);

%Matrice ky
%----------

ky_vec=ky*ones(2*N+1,1);
ky_mat=diag(ky_vec)/k;
kyoo=ky_mat(N+1,N+1);

%Matrice kIz
%-----------

kIz_mat=diag(kIz_vec)/k;

%Matrice kIIIz
%-------------

kIIIz_mat=diag(kIIIz_vec)/k;   

%Matrice delta
%-------------

delta=eye(2*N+1);
delta(N+1,N+1)=1;


%Boucle "l", le nombre de couches
%--------------------------------
%--------------------------------


%M�thode des matrices S
%----------------------

%Initialisation
%--------------

Tuu_l=eye(2*(2*N+1));
Rud_l=zeros(2*(2*N+1));
Rdu_l=zeros(2*(2*N+1));
Tdd_l=eye(2*(2*N+1));

%Calcul de W_lp1 initial
%-----------------------

F_lp1=[eye(2*N+1)                         zeros(2*N+1)                       eye(2*N+1)                       zeros(2*N+1)                  
       zeros(2*N+1)                       eye(2*N+1)                         zeros(2*N+1)                     eye(2*N+1)
       kx_mat*ky_mat/kIIIz_mat            (ky_mat^2+kIIIz_mat^2)/kIIIz_mat   -kx_mat*ky_mat/kIIIz_mat         -(ky_mat^2+kIIIz_mat^2)/kIIIz_mat
       -(kx_mat^2+kIIIz_mat^2)/kIIIz_mat  -kx_mat*ky_mat/kIIIz_mat           (kx_mat^2+kIIIz_mat^2)/kIIIz_mat  kx_mat*ky_mat/kIIIz_mat ];
  
X_lp1=[eye(2*(2*N+1))];
   

for l=1:L,
    
%l=L-l+1;

%Valeur et vecteurs propres de la matrice Omega
%----------------------------------------------

E=E_mat(E1(l,i),E2(l,i),F,N);
A=A_mat(E1(l,i),E2(l,i),F,N);
B=B_mat(kx_mat,E,N,A);
D=D_mat(ky_mat,E,N,A);

Omega=Omega_mat(kx_mat,ky_mat,E,A,B,D,N);

[W,Sigmatmp]=eig(Omega);%'nobalance'); 


    %Matrice F
    %---------
    
        %Matrices V
        %----------
            
            %Matrice Sigma - vecteur sigma
            %-----------------------------
            
            Sigmatmp=diag(sqrt(Sigmatmp));
            
            %Test sur les valeurs propres
            %----------------------------
            
            for j=1:2*N+1,
        
                if (real(Sigmatmp(j))+imag(Sigmatmp(j)))>0
            
                Sigmatmp(j)=Sigmatmp(j);
            
            elseif (real(Sigmatmp(j))+imag(Sigmatmp(j)))<0
            
                Sigmatmp(j)=-Sigmatmp(j);
            
            end;
        
        end;
                        
            sigma=Sigmatmp;
                                   
            Sigma=diag(sigma);
            
            %Matrices Q
            %----------
            
            Q11=kx_mat*ky_mat;
            Q12=inv(A)-ky_mat^2;
            Q21=kx_mat^2-E;
            Q22=-kx_mat*ky_mat;
            
            %Matrices W
            %----------
            
            W1=W(1:2*N+1,1:2*(2*N+1));
            W2=W(2*N+1+1:2*(2*N+1),1:2*(2*N+1));
            
            %Matrices V
            %----------
            
            V1=(Q11*W1+Q12*W2)*inv(Sigma);
            V2=(Q21*W1+Q22*W2)*inv(Sigma);
        
    
    F11=W2;
    F12=W2;
    F21=W1;
    F22=W1;
    F31=sqrt(-1)*V2;
    F32=-sqrt(-1)*V2;
    F41=sqrt(-1)*V1;
    F42=-sqrt(-1)*V1;
            
    
    %Matrices X
    %----------
    
    X_l=X_lp1;
        
    X_lp1=diag(exp(-k*sigma*d(l)));
    
    %Matrices T et F
    %---------------
    
    F_l=F_lp1;
    
    F_lp1=[W2          W2
           W1          W1
           sqrt(-1)*V2 -sqrt(-1)*V2
           sqrt(-1)*V1 -sqrt(-1)*V1];clear W1 W2 V1 V2
                 
    %[F_lp1U,F_lp1S,F_lp1V]=svd(F_lp1); 
          
    %T=F_lp1V*inv(F_lp1S)*F_lp1U'*F_l;clear F_lp1U F_lp1S F_lp1V F_l;
    
    T=inv(F_lp1)*F_l;
    
    t11=T(1:2*(2*N+1),1:2*(2*N+1));
    t12=T(1:2*(2*N+1),2*(2*N+1)+1:2*2*(2*N+1));
    t21=T(2*(2*N+1)+1:2*2*(2*N+1),1:2*(2*N+1));
    t22=T(2*(2*N+1)+1:2*2*(2*N+1),2*(2*N+1)+1:2*2*(2*N+1));

    clear T;
    
    %[t22U,t22S,t22V]=svd(t22);
    
    %invt22=t22V*inv(t22S)*t22U';clear t22U t22S t22V;
    
    invt22=inv(t22);
    
    %Matrice S
    %---------
    
        %Matrice s
        %---------
          
        s=[t11-t12*invt22*t21  t12*invt22
           -invt22*t21         invt22];clear t11 t12 t21 t22 invt22;
        
            %Matrice s chapeau
            %-----------------
    
            s_chap_g=[eye(2*(2*N+1))    zeros(2*(2*N+1)) 
                      zeros(2*(2*N+1))  X_l];   
                      
            s_chap_d=[X_l               zeros(2*(2*N+1)) 
                      zeros(2*(2*N+1))  eye(2*(2*N+1))];   
                  
            clear X_l;
                  
            s_chap=s_chap_g*s*s_chap_d;clear s;
            
            tuu=s_chap(1:2*(2*N+1),1:2*(2*N+1));
            rud=s_chap(1:2*(2*N+1),2*(2*N+1)+1:2*2*(2*N+1));
            rdu=s_chap(2*(2*N+1)+1:2*2*(2*N+1),1:2*(2*N+1));
            tdd=s_chap(2*(2*N+1)+1:2*2*(2*N+1),2*(2*N+1)+1:2*2*(2*N+1));
    
            clear s s_chap_g s_chap_d;
            
    Tuu_lm1=Tuu_l;
    Rud_lm1=Rud_l;
    Rdu_lm1=Rdu_l;
    Tdd_lm1=Tdd_l;
    
    
    Tuu_l=tuu*inv(eye(2*(2*N+1))-Rud_lm1*rdu)*Tuu_lm1;
    Rud_l=rud+tuu*Rud_lm1*inv(eye(2*(2*N+1))-rdu*Rud_lm1)*tdd;
    Rdu_l=Rdu_lm1+Tdd_lm1*rdu*inv(eye(2*(2*N+1))-Rud_lm1*rdu)*Tuu_lm1;       
    Tdd_l=Tdd_lm1*inv(eye(2*(2*N+1))-rdu*Rud_lm1)*tdd;    
         
    clear Tuu_lm1 Rud_lm1 Rdu_lm1 Tdd_lm1;
    
    clear tuu rud rdu tdd;
    
end;

%Fin de la boucle � rebourd sur "l"

%Calcul de Sn
%------------

F_l=F_lp1;


F_lp1=[eye(2*N+1)                     zeros(2*N+1)                       eye(2*N+1)                     zeros(2*N+1)                       
       zeros(2*N+1)                   eye(2*N+1)                         zeros(2*N+1)                   eye(2*N+1)  
       kx_mat*ky_mat/kIz_mat          (ky_mat^2+kIz_mat^2)/kIz_mat       -kx_mat*ky_mat/kIz_mat         -(ky_mat^2+kIz_mat^2)/kIz_mat                                 
       -(kx_mat^2+kIz_mat^2)/kIz_mat  -kx_mat*ky_mat/kIz_mat             (kx_mat^2+kIz_mat^2)/kIz_mat   kx_mat*ky_mat/kIz_mat];  
     
   
    %[F_lp1U,F_lp1S,F_lp1V]=svd(F_lp1); 
          
    %T=F_lp1V*inv(F_lp1S)*F_lp1U'*F_l;clear F_lp1U F_lp1S F_lp1V F_l;
    
    T=inv(F_lp1)*F_l;
    
    t11=T(1:2*(2*N+1),1:2*(2*N+1));
    t12=T(1:2*(2*N+1),2*(2*N+1)+1:2*2*(2*N+1));
    t21=T(2*(2*N+1)+1:2*2*(2*N+1),1:2*(2*N+1));
    t22=T(2*(2*N+1)+1:2*2*(2*N+1),2*(2*N+1)+1:2*2*(2*N+1));
    
    clear T;

    %Matrice S
    %---------
    
        %Matrice s
        %---------
          
        %[t22U,t22S,t22V]=svd(t22);
    
        %invt22=t22V*inv(t22S)*t22U';clear t22U t22S t22V;
        
        invt22=inv(t22);
        
        s=[t11-t12*inv(t22)*t21  t12*invt22
           -invt22*t21           invt22];clear t11 t12 t21 t22 invt22;
        
            %Matrice s chapeau
            %-----------------
    
            s_chap_g=[eye(2*(2*N+1))    zeros(2*(2*N+1)) 
                      zeros(2*(2*N+1))  X_lp1];   
                      
            s_chap_d=[X_lp1             zeros(2*(2*N+1)) 
                      zeros(2*(2*N+1))  eye(2*(2*N+1))];   
                  
            clear X_lp1;   
                  
            s_chap=s_chap_g*s*s_chap_d;clear s s_chap_g s_chap_d;
            
            tuu=s_chap(1:2*(2*N+1),1:2*(2*N+1));
            rud=s_chap(1:2*(2*N+1),2*(2*N+1)+1:2*2*(2*N+1));
            rdu=s_chap(2*(2*N+1)+1:2*2*(2*N+1),1:2*(2*N+1));
            tdd=s_chap(2*(2*N+1)+1:2*2*(2*N+1),2*(2*N+1)+1:2*2*(2*N+1));
            
            clear s_chap;
            
    Tuu_lm1=Tuu_l;
    Rud_lm1=Rud_l;
    Rdu_lm1=Rdu_l;
    Tdd_lm1=Tdd_l;
    
    Tuu_l=tuu*inv(eye(2*(2*N+1))-Rud_lm1*rdu)*Tuu_lm1;
    Rud_l=rud+tuu*Rud_lm1*inv(eye(2*(2*N+1))-rdu*Rud_lm1)*tdd;
    Rdu_l=Rdu_lm1+Tdd_lm1*rdu*inv(eye(2*(2*N+1))-Rud_lm1*rdu)*Tuu_lm1;       
    Tdd_l=Tdd_lm1*inv(eye(2*(2*N+1))-rdu*Rud_lm1)*tdd;    
   
    clear Tuu_lm1 Rud_lm1 Rdu_lm1 Tdd_lm1 tuu rud rdu tdd;
    
%Equation finale
%---------------
%---------------

S=[Tuu_l Rud_l
   Rdu_l Tdd_l];

fintmp=zeros(2*N+1,1);
fintmp(N+1)=1;

fin1=[zeros(2*N+1,1)
      zeros(2*N+1,1)
      ux*fintmp
      uy*fintmp];

%Solutions
%---------
%---------
    
    solut=S*[fin1];
 
%Resultats
%---------
%---------

    %Amplitudes dans la base  xyz
    %----------------------------

Rx=solut(1:2*N+1);

Ry=solut((2*N+1)+1:2*(2*N+1));

Tx=solut(2*(2*N+1)+1:3*(2*N+1));

Ty=solut(3*(2*N+1)+1:4*(2*N+1));

Rz=(-kx_vec'.*Rx-ky_vec.*Ry)./kIz_vec';

Tz=(-kx_vec'.*Tx-ky_vec.*Ty)./kIIIz_vec';

    %Amplitudes dans la base s(TE) p(TM)
    %-----------------------------------

for j=1:2*N+1,
    
    if ky==0
        
    Phi(j)=0;
    
    else

    Phi(j)=atan(ky./kx_vec(j));
      
    end;
    
end;
    
%Phi=Phi';

Rs=cos(Phi').*Ry-sin(Phi').*Rx;

Rp=(1/k).*(cos(Phi').*(kIz_vec'.*Rx-kx_vec'.*Rz)-sin(Phi').*(ky_vec.*Rz-kIz_vec'.*Ry));

Ts=(cos(Phi').*Ty-sin(Phi').*Tx);

Tp=(1/k)*(cos(Phi').*(kIIIz_vec'.*Tx-kx_vec'.*Tz)-sin(Phi').*(ky_vec.*Tz-kIIIz_vec'.*Ty));

    %Efficacit�s de diffraction
    %--------------------------
   
    
    nIc=k*sqrt(EI)*cos(theta);
    
    %nIIIc=k*sqrt(EIII)*cos(theta);
    
    DER_s(i,:) = (Rs.*conj(Rs).*real(kIz_vec/nIc)')';
    
    DER_p(i,:) = (Rp.*conj(Rp).*real((kIz_vec/EI)/nIc)')';
    
    DET_s(i,:) = (Ts.*conj(Ts).*real(kIIIz_vec/nIc)')'; 
    
    DET_p(i,:) = (Tp.*conj(Tp).*real((kIIIz_vec/EIII)/nIc)')';
    
    %test=1-sum((DER_s(i,:))'+(DER_p(i,:))'+(DET_s(i,:))'+(DET_p(i,:))');

    %DER=real(kIz_vec'/(k*sqrt(EI(i))*cos(theta))).*((abs(Rx)).^2+(abs(Ry)).^2+(abs(Rz)).^2);
    
    %DET=real(kIIIz_vec'/(k*sqrt(EI(i))*cos(theta))).*((abs(Tx)).^2+(abs(Ty)).^2+(abs(Tz)).^2);
   
    test=1-sum(DER_s(i,:)+DER_p(i,:)+DET_s(i,:)+DET_p(i,:));
    
    if abs(test) > 1e-10
        
        stop=1;
        
    end;
   
    %test=1-sum(DER+DET);
    
    dphi_sp(i)=atan2(imag(Tp(N+1)),real(Tp(N+1)))-atan2(imag(Ts(N+1)),real(Ts(N+1)));
    
    %dphi_sp(i)=atan2(imag(Rp(N+1)),real(Rp(N+1)))-atan2(imag(Rs(N+1)),real(Rs(N+1)));
    
    %dphi_sp(i)=-(angle(Tp(N+1))-angle(Ts(N+1)));
    
    %dphi_xy(i)=angle(Tx(N+1))-angle(Ty(N+1));
    
    %dphi_sp(i)=(angle(Tp(N+1))-angle(Ts(N+1)));
    
    %dphi_xy(i)=angle(Tx(N+1))-angle(Ty(N+1));
    
%Efficacit�s
%-----------

DET_s_fin(Lb_c,d_c,d_c_ar,F_c,i)=DET_s(i,N+1);

DET_p_fin(Lb_c,d_c,d_c_ar,F_c,i)=DET_p(i,N+1);


    %cacul param�tre q
    %-----------------

    q(Lb_c,d_c,d_c_ar,F_c,i)=(DET_s_fin(Lb_c,d_c,d_c_ar,F_c,i)./DET_p_fin(Lb_c,d_c,d_c_ar,F_c,i)).^2;
    dphi_sp_stock(Lb_c,d_c,d_c_ar,F_c,i)=dphi_sp(i);
end;

%Fin de la boucle principale sur "i"

%D�phasage
%---------

dphi_sp_unwrap(Lb_c,d_c,d_c_ar,F_c,:)=abs(unwrap(dphi_sp_stock(Lb_c,d_c,d_c_ar,F_c,:)));

if dphi_sp_unwrap(Lb_c,d_c,d_c_ar,F_c,nlb/2)>pi,
    dphi_sp_unwrap(Lb_c,d_c,d_c_ar,F_c,:)=dphi_sp_unwrap(Lb_c,d_c,d_c_ar,F_c,:)-pi;
end;

%Null Depth
%----------

eps(Lb_c,d_c,d_c_ar,F_c,:)=(2*dphi_sp_unwrap(Lb_c,d_c,d_c_ar,F_c,:)-pi).^2;

nul(Lb_c,d_c,d_c_ar,F_c,:)=((1+sqrt(q(Lb_c,d_c,d_c_ar,F_c,:))).^2)./((1-sqrt(q(Lb_c,d_c,d_c_ar,F_c,:))).^2+eps(Lb_c,d_c,d_c_ar,F_c,:).*sqrt(q(Lb_c,d_c,d_c_ar,F_c,:)));



end;

%Fin de la boucle principale sur "Lb_c"

end;

%Fin de la boucle principale sur "d_c"

end;

%Fin de la boucle principale sur "F_c"

end;


%dphi_sp_fin=dphi_sp+pi;

%dphi_xy=unwrap(dphi_xy);

%if dphi(nlb/2)<0

%    dphi=dphi+2*pi;
    
%else
    
%    dphi=dphi;
    
%end;

%figure;

%plot(lb,dphi_sp);

%figure;



%Doublage du d�phasage pour arriver � pi
%---------------------------------------



%dphi_xy=2*dphi_xy+2*pi;

%dphi_sp=-2*dphi_sp+4*pi;




%plot(lb,dphi_xy);

%moy(theta_c)=mean(dphi_sp)


%Calcul epsilon
%--------------


%nul_phase_sp=(dphi_sp-pi).^2;

%nul_phase_xy=(dphi_sp-pi).^2;


%cacul du taux de nulling r�sultant
%----------------------------------

%nul_res_sp(:,Lb_c,d_c,F_c)=((1+sqrt(q)).^2)./((1-sqrt(q)).^2+nul_phase_sp.*sqrt(q));

%nul_res_xy(:,Lb_c,d_c,F_c)=((1+sqrt(q)).^2)./((1-sqrt(q)).^2+nul_phase_xy'.*sqrt(q));

%eps_phase=sqrt(4*nul_phase);

%nul_eq=nul_phase'+(((2*DET_s(:,9)).^2-(2*DET_p(:,9)).^2)./(2*DET_p(:,9).^2)).^2/16

%eps_eq=sqrt(4*nul_eq);

%sig(theta_c)=sqrt(sum((dphi_sp-pi).*(dphi_sp-pi))/nlb);

%sig_sp(theta_c)=sqrt(var(dphi_sp));

%sig_sp(Lb_c,d_c,F_c,theta_c)=sqrt(var(dphi_sp));

%sig_xy(Lb_c,d_c,F_c,theta_c)=sqrt(var(dphi_xy));

%moy(Lb_c,d_c,F_c,theta_c)=mean(dphi_sp);


%plot(lb,nul_phase_sp);
%hold on;



%r=4/(sum((dphi_sp-pi).^2)/nlb)

%figure;

%plot(lb,2*DET_s_fin);

%hold on;

%plot(lb,2*DET_p_fin);

%figure;

%eps=(dphi_sp-pi).^2;

%plot(lb,eps);

%nul=((1+sqrt(q)).^2)./((1-sqrt(q)).^2+eps'.*sqrt(q));

%figure;
%
%plot(lb,(1./nul));

%plot(DER_p(:,N+1));

%figure;

%plot(DER_s(:,N+1));

%hold on;

%plot(DER_p(:,N+1));