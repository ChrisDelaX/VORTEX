clear Rb alpha R s

Rb=pi*0.0833/180;


for i=1:41,

R(i)=theta_s(i)-theta_s(21);

end;


for i=1:41,
    
    alpha(i)=acos(R(i)/Rb);
    
    
end;

%s(1)=R(1)*2*sin(alpha(1))*Rb;

for i=1:40,
    
    
    test(i)=R(i+1)-R(i);
    s(i)=(R(i+1)-R(i))*2*sin(real(alpha(i)))*Rb;
    
    
end;


s(41)=0;