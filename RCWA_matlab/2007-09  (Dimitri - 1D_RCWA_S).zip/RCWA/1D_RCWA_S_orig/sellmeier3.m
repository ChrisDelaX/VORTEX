%Equation de Sellmeier

function[n]=sellmeier2(l,A,B,C,D,E,F,G)

n=(A+(B*(l^2)/((l^2)-C))+(D*(l^2)/((l^2)-E))+(F*(l^2)/((l^2)-G)));