%Configuration g�n�rale du probl�me
%----------------------------------


%Param�tres de calculs
%---------------------


    %Troncature
    
        %En X (M donc 2M+1 ordres au total)  
    
        M=8;
        
        %En Y (N donc 2N+1 ordres au total)
        
        N=0;
       
    %Param�tre alpha (entre 0 et 1)
    
        a=0.5;
        
    
%Param�tres du r�seau
%--------------------    
    

%Nombre de couches

    L=1;

    
%Pas du r�seau

    %En X

    %Lxmin=;
    %Lxmax=;
    Lbx=427e-9;
    
        %Nombre de point d'�chantillonnage
    
        %nLx=;
    
    %En Y
    
    %Lymin=;
    %Lymax=;
    Lby=1;
    
        %Nombre de point d'�chantillonnage
    
        %nLy=;

%Epaisseurs

    %dmin(l)=;
    %dmax(l)=;
    d(1)=1.56e-6;
        
%Permittivit�s
%-------------


    %Permittivit�s milieu ext�rieur incident
    %---------------------------------------
    
    EI=1;
    
    %Permittivit�s milieu ext�rieur �mergent
    %---------------------------------------
    
    %CdTe � 7 K
    %----------
    
    %T=7;
    
    %A_cdte = -2.373e-4*T + 3.8466; B_cdte = 8.057e-4*T + 3.2215;

    %C_cdte = -1.10e-4*T + 0.1866; D_cdte = -2.160e-2*T + 12.718;

    %E_cdte = -3.160e1*T + 18753;

    EIII=11.56;
    
    
    %Permittivit�s du r�seau
    %-----------------------
    
        %R�seau en relief de surface
        %---------------------------
        
        
            %Permittivit� milieu 1
            
            E1(1)=1;
    
            %Permittivit� milieu 2
            
            E2(1)=11.56;
            
            %Facteur de remplissage
            
                %En X
            
                %Fxmin=0.1;
                %Fxmax=0.9;
                Fx(1)=0.83;
            
                    %Nombre de point d'�chantillonnage
    
                    %nFx=9;
    
                %En Y
    
                %Fymin=0.1;
                %Fymax=0.9;
                Fy(1)=0.5;
    
                    %Nombre de point d'�chantillonnage
    
                    %nFy=9;
            
        %R�seau en volume
        %----------------
        
        
            %Permittivit� moyenne
            
            %epsm(l)=;
            
            %Modulation de permittivit�
            
            %modmin(l)=;
            %modmax(l)=;
            %mod(l)=;
            
                %Nombre de point d'�chantillonnage
    
                %nmod=;
            
                
                
%Incidence
%---------

    %Longueur d'onde
    
    lbmin=2e-6;
    lbmax=2.5e-6;
    %lb=7.7;
    
        %Nombre de point d'�chantillonnage
    
        nlb=50;

    %Angle incidence non conique
    
    %thetamin=;
    %thetamax=;
    theta=0;
    
        %Nombre de point d'�chantillonnage
    
        %ntheta=;
    
    %Angle incidence conique

    %phimin=;
    %phimax=;
    phi=0;
    
        %Nombre de point d'�chantillonnage
    
        %nlphi=;
        
    %Angle polarisation
    
    %psimax=;
    %psimin=;
    psi=pi/4;
    
        %Nombre de point d'�chantillonnage
    
        %nlpsi=;
        
    

    

    
