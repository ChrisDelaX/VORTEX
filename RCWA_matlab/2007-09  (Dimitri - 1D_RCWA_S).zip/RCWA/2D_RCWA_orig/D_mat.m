function[Dtmp]=D_mat(ky_mat,E,I)

%Construction matrice D

Dtmp=ky_mat*inv(E)*ky_mat-I;