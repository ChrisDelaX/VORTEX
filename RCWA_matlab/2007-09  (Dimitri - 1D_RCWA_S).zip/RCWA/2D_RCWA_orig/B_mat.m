function[Btmp]=B_mat(kx_mat,E,I)

%Construction matrice B

Btmp=kx_mat*inv(E)*kx_mat-I;
