function[Omega]=Omega_mat(kx_mat,ky_mat,a,E,A,B,D,MN)

%Construction matrice Omega l

Omega=[kx_mat^2+D*(a*E+(1-a)*inv(A))                       ky_mat*(inv(E)*kx_mat*(a*inv(A)+(1-a)*E)-kx_mat)
       kx_mat*(inv(E)*ky_mat*(a*E+(1-a)*inv(A))-ky_mat)    ky_mat^2+B*(a*inv(A)+(1-a)*E)];

%Omega=[zeros(MN)                  zeros(MN)                   ky_mat*inv(E)*kx_mat          eye(MN)-ky_mat*inv(E)*ky_mat
%       zeros(MN)                  zeros(MN)                   kx_mat*inv(E)*kx_mat-eye(MN)  -kx_mat*inv(E)*ky_mat
%       kx_mat*ky_mat              a*inv(A)+(1-a)*E-ky_mat^2   zeros(MN)                     zeros(MN)
%       kx_mat^2-a*E-(1-a)*inv(A)  -kx_mat*ky_mat              zeros(MN)                     zeros(MN)];


%Omega=[kx_mat^2+D*E                                ky_mat*(inv(E)*kx_mat*E-kx_mat)
%       kx_mat*(inv(E)*ky_mat*E-ky_mat)             ky_mat^2+B*E];