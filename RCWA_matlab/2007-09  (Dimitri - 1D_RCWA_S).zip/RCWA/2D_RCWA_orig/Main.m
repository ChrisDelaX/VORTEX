%Programme principal
%-------------------
%-------------------


clear all


%Lectures des entr�es
%--------------------

Entrees;

MN=(2*M+1)*(2*N+1);

%Vecteur de polarisation incident
%--------------------------------

ux=cos(psi)*cos(theta)*cos(phi)-sin(psi)*sin(phi);

uy=cos(psi)*cos(theta)*sin(phi)-sin(psi)*cos(phi);

uz=-cos(psi)*sin(theta);


%Choix du param�tre de boucle principale "i" et d�but boucle principale
%----------------------------------------------------------------------
%----------------------------------------------------------------------

if exist('lb')==1,
    
    nlb=1;
    lbmin=lb;
    incr=0;
    
else
    
incr=(lbmax-lbmin)/(nlb-1);

end;

for i=1:nlb,
    
    clear kx ky kIz kIIIz;
    
    lb(i)=lbmin+(i-1)*incr;

    %E2(i)=sellmeier2(lb(i),A_cdte,B_cdte,C_cdte,D_cdte,E_cdte);
    
    %EIII(i)=E2(i);
    
%Calcul Vecteur d'onde
%---------------------

k=2*pi/lb(i);
    
%Boucle sur "m" (x)
%------------------

t=1;

for j=1:2*M+1,
    
    m=j-(M+1);
    
    %Etape construction kx
    %---------------------
    
    kx(j)=k*(sqrt(EI)*sin(theta)*cos(phi)-m*(lb(i)/Lbx));
    
%Boucle sur "n" (y)
%------------------

for h=1:2*N+1,
    
    n=h-(N+1);
    
    %Etape construction ky
    %---------------------
    
    ky(h)=k*(sqrt(EI)*sin(theta)*sin(phi)-n*(lb(i)/Lby));

    %Etape construction kIz 
    %----------------------

    %if sqrt(EI)>sqrt((kx(j)/k)^2+(ky(h)/k)^2)

    kIz(j,h)=sqrt(k^2*EI-(kx(j))^2-(ky(h))^2);

    %elseif sqrt(EI)<sqrt((kx(j)/k)^2+(ky(h)/k)^2)
    
    %kIz(j,h)=-sqrt(-1)*k*sqrt((kx(j)/k)^2+(ky(h)/k)^2-EI);
        
    %end;
    
    %Etape construction kIIIz 
    %------------------------

    %if sqrt(EIII)>sqrt((kx(j)/k)^2+(ky(h)/k)^2)

    kIIIz(j,h)=sqrt(k^2*EIII-(kx(j))^2-(ky(h))^2);

    %elseif sqrt(EIII)<sqrt((kx(j)/k)^2+(ky(h)/k)^2)
    
    %kIIIz(j,h)=-sqrt(-1)*k*sqrt((kx(j)/k)^2+(ky(h)/k)^2-EIII);
        
    %end;
    
    kxtmp(t)=kx(j);
    
    kytmp(t)=ky(h);
    
    kIztmp(t)=kIz(j,h);
    
    kIIIztmp(t)=kIIIz(j,h);
    
    t=t+1;
    
end;%Fin de la boucle sur "n"

end;%Fin de la boucle sur "m"

%Vecteur kx
%----------

kx_vec=kxtmp; clear kxtmp;

%Matrice kx
%----------

kx_mat=diag(kx_vec)/k;
kxoo=kx_mat(round(MN/2),round(MN/2));

%Vecteur ky
%----------

ky_vec=kytmp; clear kxtmp;

%Matrice ky
%----------

ky_mat=diag(ky_vec)/k;
kyoo=ky_mat(round(MN/2),round(MN/2));

%Vecteur kIz
%-----------

kIz_vec=kIztmp; clear kIztmp;

%Matrice kIz
%-----------

kIz_mat=diag(kIz_vec)/k;

%Vecteur kIIIz
%-------------

kIIIz_vec=kIIIztmp; clear kIIIztmp;   

%Matrice kIIIz
%-------------

kIIIz_mat=diag(kIIIz_vec)/k;   

%Matrice delta
%-------------

delta=zeros(MN,1);
delta(round(MN/2))=1;


%Boucle � rebourd sur "l", le nombre de couches
%----------------------------------------------
%----------------------------------------------


%Initialisation
%--------------

    I=I_mat(MN);

    %Matrices X
    %----------
    
    X=zeros(2*MN,2*MN,L);
    
    %Matrice a
    %---------
    
    a_mat=zeros(2*MN,2*MN,L);
    
    %Matrice f(L+1)
    %--------------

    f_lp1=[I         zeros(MN)
           zeros(MN) I];
    
    %Matrice g(L+1)
    %--------------
    
    g_lp1=[-kx_mat*ky_mat/kIIIz_mat           -(ky_mat^2+kIIIz_mat^2)/kIIIz_mat
           (kx_mat^2+kIIIz_mat^2)/kIIIz_mat   kx_mat*ky_mat/kIIIz_mat];

         
for l=1:L,
    
l=L-l+1;

%Valeur et vecteurs propres de la matrice Omega
%----------------------------------------------

if exist('E')==1
    
B=B_mat(kx_mat,E,I);
D=D_mat(ky_mat,E,I);

Omega=Omega_mat(kx_mat,ky_mat,a,E,A,B,D,MN);

else    
    
E=E_mat(E1(l),E2(l),Fx(l),Fy(l),M,N);
A=A_mat(E1(l),E2(l),Fx(l),Fy(l),M,N);
B=B_mat(kx_mat,E,I);
D=D_mat(ky_mat,E,I);

Omega=Omega_mat(kx_mat,ky_mat,a,E,A,B,D,MN);

end;

[W,Sigmatmp]=eig(Omega);
     

%Matrice [f1;g1]
%---------------

    %Matrices F
    %----------
    
        %Matrices V
        %----------
            
            %Matrices Q
            %----------
            
            Q11=kx_mat*ky_mat;
            Q12=a*inv(A)+(1-a)*E-ky_mat^2;
            Q21=kx_mat^2-a*E-(1-a)*inv(A);
            Q22=-kx_mat*ky_mat;
            
            %Matrices W
            %----------
            
            %W1=W(1:2*MN,1:MN)';
            %W2=W(1:2*MN,MN+1:2*MN)';
            
            W1=W(1:MN,1:2*MN);
            W2=W(MN+1:2*MN,1:2*MN);
            
            %Matrice Sigma - vecteur sigma
            %-----------------------------
            
            Sigmatmpb=diag(sqrt(Sigmatmp));
            
            
            %Test sur les valeurs propres
            %----------------------------
            
            %for i=1:2*MN,
        
            %    if (real(Sigmatmpb(i))+imag(Sigmatmpb(i)))>0
            
            %    Sigmatmpb(i)=Sigmatmpb(i);
            
            %    elseif (real(Sigmatmpb(i))+imag(Sigmatmpb(i)))<0
            
            %    Sigmatmpb(i)=-Sigmatmpb(i);
            
            %end;
        
            %end;
            
            
            sigma=Sigmatmpb; %clear Sigmatmpbis;
            
            Sigma=diag(sigma);
            
           
        V1=(Q11*W1+Q12*W2)*Sigma^(-1);
        V2=(Q21*W1+Q22*W2)*Sigma^(-1);
        
    
    F11=W2;
    F12=W2;
    F21=W1;
    F22=W1;
    F31=sqrt(-1)*V2;
    F32=-sqrt(-1)*V2;
    F41=sqrt(-1)*V1;
    F42=-sqrt(-1)*V1;
    
    
    %Matrices X
    %----------
    
    X(:,:,1)=diag(exp(-k*sigma*d(1)));
    
    %Matrices a et b
    %---------------

    F=[F11 F12
       F21 F22
       F31 F32
       F41 F42];
    
     abtmp=inv(F)*[f_lp1;g_lp1];  
       
     a_mat(:,:,l)=abtmp(1:2*MN,1:2*MN);
     
     b=abtmp(2*MN+1:4*MN,1:2*MN);

                       
fgtemp=[F11+F12*(X(:,:,l)*b*inv(a_mat(:,:,l))*X(:,:,l))
        F21+F22*(X(:,:,l)*b*inv(a_mat(:,:,l))*X(:,:,l))
        F31+F32*(X(:,:,l)*b*inv(a_mat(:,:,l))*X(:,:,l))
        F41+F42*(X(:,:,l)*b*inv(a_mat(:,:,l))*X(:,:,l))];


f_lp1=fgtemp(1:2*MN,1:2*MN);


g_lp1=fgtemp(2*MN+1:4*MN,1:2*MN);


end;%Fin de la boucle � rebourd sur "l"


%Equation finale
%---------------
%---------------


fin1=[ux*delta
      uy*delta
      delta*(kyoo*uz-sqrt(EI)*cos(theta)*uy)
      delta*(sqrt(EI)*cos(theta)*ux-kxoo*uz)];
  
fin2=[I                              zeros(MN)
      zeros(MN)                      I
      (kx_mat*ky_mat)/kIz_mat        (ky_mat^2+kIz_mat^2)/kIz_mat
      -(kx_mat^2+kIz_mat^2)/kIz_mat  -(kx_mat*ky_mat)/kIz_mat];
  
fin3=[f_lp1
      g_lp1];


%Solutions
%---------
%---------


royal_mat=[fin2 -fin3];

solut=royal_mat\(-fin1);

    %R�cursion
    %---------

    T_1=solut(2*MN+1:4*MN);

    T=T_1;

    for l=1:L,
    
        T=inv(a_mat(:,:,l))*X(:,:,l)*T;

    end;


%Resultats
%---------
%---------

%Vecteurs amplitudes complexes
%-----------------------------

Rx=solut(1:MN);

Ry=solut(MN+1:2*MN);

Tx=T(1:MN);

Ty=T(MN+1:2*MN);

Rz=(-kx_vec'.*Rx-ky_vec'.*Ry)./kIz_vec';

Tz=(-kx_vec'.*Tx-ky_vec'.*Ty)./kIIIz_vec';


    %Efficacit�s de diffraction
    %--------------------------
    
    DER=real(kIz_vec'/(k*sqrt(EI)*cos(theta))).*((abs(Rx)).^2+(abs(Ry)).^2+(abs(Rz)).^2);
    
    DET=real(kIIIz_vec'/(k*sqrt(EI)*cos(theta))).*((abs(Tx)).^2+(abs(Ty)).^2+(abs(Tz)).^2);
    
    test=1-sum(DER+DET)
    
    DER_i(i)=DER(round(MN/2));
    
    DET_i(i)=DET(round(MN/2));
    
    
    %D�phasage TE-TM pour l'ordre 0
    %------------------------------
   
    psif(i)=atan(abs(Ty(round(MN/2)))/abs(Tx(round(MN/2))));
    psifb(i)=angle(Ty(round(MN/2)))-angle(Tx(round(MN/2)));

    
    
end;%Fin de la boucle principale sur "i"
