%Programme principal
%-------------------
%-------------------


clear all


%Lectures des entr�es
%--------------------

Entrees;

MN=(2*M+1)*(2*N+1);

%Vecteur de polarisation incident
%--------------------------------

ux=cos(psi)*cos(theta)*cos(phi)-sin(psi)*sin(phi);

uy=cos(psi)*cos(theta)*sin(phi)-sin(psi)*cos(phi);

uz=-cos(psi)*sin(theta);


%Choix du param�tre de boucle principale "i" et d�but boucle principale
%----------------------------------------------------------------------
%----------------------------------------------------------------------

if exist('lb')==1,
    
    nlb=1;
    lbmin=lb;
    incr=0;
    
else
    
incr=(lbmax-lbmin)/(nlb-1);

end;

for i=1:nlb,
    
    clear kx ky kIz kIIIz;
    
    lb(i)=lbmin+(i-1)*incr;

    E2(i)=sellmeier2(lb(i),A_cdte,B_cdte,C_cdte,D_cdte,E_cdte);
    
    EIII(i)=E2(i);
    
    for F=1:9,
        
        Fx(F)=Fxmin+(F-1)*(Fxmax-Fxmin)/(nFx-1);
        
        Fy(F)=Fymin+(F-1)*(Fymax-Fymin)/(nFy-1);
        
%Calcul Vecteur d'onde
%---------------------

k=2*pi/lb(i);
    
%Boucle sur "m" (x)
%------------------

t=1;

for j=1:2*M+1,
    
    m=j-(M+1);
    
    %Etape construction kx
    %---------------------
    
    kx(j)=k*(sqrt(EI)*sin(theta)*cos(phi)-m*(lb(i)/Lbx));
    
%Boucle sur "n" (y)
%------------------

for h=1:2*N+1,
    
    n=h-(N+1);
    
    %Etape construction ky
    %---------------------
    
    ky(h)=k*(sqrt(EI)*sin(theta)*sin(phi)-n*(lb(i)/Lby));

    %Etape construction kIz 
    %----------------------

    %if sqrt(EI)>sqrt((kx(j)/k)^2+(ky(h)/k)^2)

    kIz(j,h)=sqrt(k^2*EI-(kx(j))^2-(ky(h))^2);

    %elseif sqrt(EI)<sqrt((kx(j)/k)^2+(ky(h)/k)^2)
    
    %kIz(j,h)=-sqrt(-1)*k*sqrt((kx(j)/k)^2+(ky(h)/k)^2-EI);
        
    %end;
    
    %Etape construction kIIIz 
    %------------------------

    %if sqrt(EIII)>sqrt((kx(j)/k)^2+(ky(h)/k)^2)

    kIIIz(j,h)=sqrt(k^2*EIII(i)-(kx(j))^2-(ky(h))^2);

    %elseif sqrt(EIII)<sqrt((kx(j)/k)^2+(ky(h)/k)^2)
    
    %kIIIz(j,h)=-sqrt(-1)*k*sqrt((kx(j)/k)^2+(ky(h)/k)^2-EIII);
        
    %end;
    
    kxtmp(t)=kx(j);
    
    kytmp(t)=ky(h);
    
    kIztmp(t)=kIz(j,h);
    
    kIIIztmp(t)=kIIIz(j,h);
    
    t=t+1;
    
end;%Fin de la boucle sur "n"

end;%Fin de la boucle sur "m"

%Vecteur kx
%----------

kx_vec=kxtmp; clear kxtmp;

%Matrice kx
%----------

kx_mat=diag(kx_vec)/k;
kxoo=kx_mat(round(MN/2),round(MN/2));

%Vecteur ky
%----------

ky_vec=kytmp; clear kxtmp;

%Matrice ky
%----------

ky_mat=diag(ky_vec)/k;
kyoo=ky_mat(round(MN/2),round(MN/2));

%Vecteur kIz
%-----------

kIz_vec=kIztmp; clear kIztmp;

%Matrice kIz
%-----------

kIz_mat=diag(kIz_vec)/k;

%Vecteur kIIIz
%-------------

kIIIz_vec=kIIIztmp; clear kIIIztmp;   

%Matrice kIIIz
%-------------

kIIIz_mat=diag(kIIIz_vec)/k;   

%Matrice delta
%-------------

delta=zeros(MN,1);
delta(round(MN/2))=1;


%Boucle � rebourd sur "l", le nombre de couches
%----------------------------------------------
%----------------------------------------------


%Initialisation
%--------------
    
    l=1;
    
    I=I_mat(MN);

%Valeur et vecteurs propres de la matrice Omega
%----------------------------------------------

    
E=E_mat(E1(l),E2(i),Fx(F),Fy(F),M,N);
A=A_mat(E1(l),E2(i),Fx(F),Fy(F),M,N);
B=B_mat(kx_mat,E,I);
D=D_mat(ky_mat,E,I);

Omega=Omega_mat(kx_mat,ky_mat,a,E,A,B,D,MN);

[W,Sigmatmp]=eig(Omega);

res(i,F)=max(abs(imag(diag(sqrt(Sigmatmp)))));

end;

end;