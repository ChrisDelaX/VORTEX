function[Dtmp]=D_mat(ky_mat,E,MN)

%Construction matrice D

Dtmp=ky_mat*inv(E)*ky_mat-eye(MN);