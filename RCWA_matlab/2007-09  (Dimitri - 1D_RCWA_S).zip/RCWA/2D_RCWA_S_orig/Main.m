%Programme principal
%-------------------
%-------------------


%Gestion de la m�moire
%---------------------
%---------------------

    %Lib�ration 
    %----------

    clear all

    %Lectures des entr�es
    %--------------------
    %--------------------

    Entrees_sin;

    MN=(2*M+1)*(2*N+1);
    
    %Allocation m�moire
    %------------------

    kx_mat=zeros(MN);
    ky_mat=zeros(MN);
    kIz_mat=zeros(MN);
    kIIIz_mat=zeros(MN);
    
    E=zeros(MN);
    A=zeros(MN);

    Omega=zeros(2*MN);
    
    Tuu_l=zeros(2*MN);
    Rud_l=zeros(2*MN);
    Rdu_l=zeros(2*MN);
    Tdd_l=zeros(2*MN);

    F_lp1=zeros(4*MN);
  
    X_lp1=zeros(2*MN);


%Vecteur de polarisation incident
%--------------------------------
%--------------------------------

for th=1:ntheta,
%     
%     theta_tmp(th)=thetamin+(th-1)*(thetamax-thetamin)/(ntheta-1);
%     theta=theta_tmp(th);
    ux=cos(psi)*cos(theta)*cos(phi)-sin(psi)*sin(phi);

    uy=cos(psi)*cos(theta)*sin(phi)+sin(psi)*cos(phi);

    uz=-cos(psi)*sin(theta);


%Choix du param�tre de boucle principale "i" et d�but boucle principale
%----------------------------------------------------------------------
%----------------------------------------------------------------------

if exist('lb')==1,
    
    nlb=1;
    lbmin=lb;
    incr=0;
    
else
    
incr=(lbmax-lbmin)/(nlb-1);

end;

for i=1:nlb,
        
    
    
    lb(i)=lbmin+(i-1)*incr;

    %Indices des mat�riaux
    %---------------------
    
    %E2(i)=sellmeier2(lb(i),A_cdte,B_cdte,C_cdte,D_cdte,E_cdte);
    
    %E2(i)=sellmeier2b(lb(i),A_d,B_d,C_d,D_d,E_d);
    
    %E2(i)=sellmeierX(lb(i),A_zns,B_zns,C_zns,D_zns,E_zns);
    
    %E2(i)=sellmeier2(lb(i),A_Ge,B_Ge,C_Ge,D_Ge,E_Ge);
    
%     E2(i)=sellmeiergas(lb(i),A_ga,B_ga,C_ga,D_ga,E_ga);
    
% E2(i)=(spline(ig6(:,1),ig6(:,2),lb(i))).^2;
%     E2(i)=sellmeier_si(lb(i),A_si,B_si,C_si,D_si,E_si);
infrasil_data;
E2(i)=(spline(infra_l,infra_n,lb(i)))^2;
    
    EIII(i)=E2(i);
    
%Calcul Vecteur d'onde
%---------------------

k=2*pi/lb(i);
    
%Boucle sur "m" (x)
%------------------

t=1;

for j=1:2*M+1,
    
    m=j-(M+1);
    
    %Etape construction kx
    %---------------------
    
    kx(j)=k*(sqrt(EI)*sin(theta)*cos(phi)-m*(lb(i)/Lbx));
    
%Boucle sur "n" (y)
%------------------

    for h=1:2*N+1,
    
    n=h-(N+1);
    
    %Etape construction ky
    %---------------------
    
    ky(h)=k*(sqrt(EI)*sin(theta)*sin(phi)-n*(lb(i)/Lby));

    %Etape construction kIz 
    %----------------------

    %if sqrt(EI)>sqrt((kx(j)/k)^2+(ky(h)/k)^2)

    kIz(j,h)=sqrt(k^2*EI-(kx(j))^2-(ky(h))^2);

    %elseif sqrt(EI)<sqrt((kx(j)/k)^2+(ky(h)/k)^2)
    
    %kIz(j,h)=-sqrt(-1)*k*sqrt((kx(j)/k)^2+(ky(h)/k)^2-EI);
        
    %end;
    
    %Etape construction kIIIz 
    %------------------------

    %if sqrt(EIII)>sqrt((kx(j)/k)^2+(ky(h)/k)^2)

    kIIIz(j,h)=sqrt(k^2*EIII(i)-(kx(j))^2-(ky(h))^2);

    %elseif sqrt(EIII)<sqrt((kx(j)/k)^2+(ky(h)/k)^2)
    
    %kIIIz(j,h)=-sqrt(-1)*k*sqrt((kx(j)/k)^2+(ky(h)/k)^2-EIII);
        
    %end;
    
    kxtmp(t)=kx(j);
    
    kytmp(t)=ky(h);
    
    kIztmp(t)=kIz(j,h);
    
    kIIIztmp(t)=kIIIz(j,h);
    
    t=t+1;
    
    end;%Fin de la boucle sur "n"

end;%Fin de la boucle sur "m"

%Vecteur kx
%----------

kx_vec=kxtmp; clear kxtmp;

%Matrice kx
%----------

kx_mat=diag(kx_vec)/k;
kxoo=kx_mat(round(MN/2),round(MN/2));

%Vecteur ky
%----------

ky_vec=kytmp; clear kxtmp;

%Matrice ky
%----------

ky_mat=diag(ky_vec)/k;
kyoo=ky_mat(round(MN/2),round(MN/2));

%Vecteur kIz
%-----------

kIz_vec=kIztmp; clear kIztmp;

%Matrice kIz
%-----------

kIz_mat=diag(kIz_vec)/k;

%Vecteur kIIIz
%-------------

kIIIz_vec=kIIIztmp; clear kIIIztmp;   

%Matrice kIIIz
%-------------

kIIIz_mat=diag(kIIIz_vec)/k;   

%Matrice delta
%-------------

delta=zeros(MN,1);
delta(round(MN/2))=1;

for ep=1:1,
    
    for F_c=1:1,    

%Boucle sur "l", le nombre de couches
%------------------------------------
%------------------------------------

%M�thode des matrices S
%----------------------

%Initialisation
%--------------
  
Tuu_l=eye(2*MN);
Rud_l=zeros(2*MN);
Rdu_l=zeros(2*MN);
Tdd_l=eye(2*MN);

%Calcul de F_lp1 initial
%-----------------------

F_lp1=[eye(MN)                           zeros(MN)                        eye(MN)                          zeros(MN)                  
       zeros(MN)                         eye(MN)                          zeros(MN)                        eye(MN)
       kx_mat*ky_mat/kIIIz_mat           (ky_mat^2+kIIIz_mat^2)/kIIIz_mat -kx_mat*ky_mat/kIIIz_mat         -(ky_mat^2+kIIIz_mat^2)/kIIIz_mat
       -(kx_mat^2+kIIIz_mat^2)/kIIIz_mat -kx_mat*ky_mat/kIIIz_mat         (kx_mat^2+kIIIz_mat^2)/kIIIz_mat kx_mat*ky_mat/kIIIz_mat ];
  
X_lp1=[eye(2*(MN))];

for l=1:L,
    
l

%Valeur et vecteurs propres de la matrice Omega
%----------------------------------------------

E=E_mat(E1,E2(i),Fx(l),Fy(l),M,N);
A=A_mat(E1,E2(i),Fx(l),Fy(l),M,N);
%B=B_mat(kx_mat,E,MN);
%D=D_mat(ky_mat,E,MN);

Omega=Omega_mat(E1,E2(i),kx_mat,ky_mat,a,M,N,MN,Fx(l),Fy(l),A,E);

[W,Sigmatmp]=eig(Omega);%'nobalance'); 


    %Matrice F
    %---------
    
        %Matrices V
        %----------
            
            %Matrice Sigma - vecteur sigma
            %-----------------------------
            
            Sigmatmp=diag(sqrt(Sigmatmp));
            
            %Test sur les valeurs propres
            %----------------------------
            
            for j=1:2*N+1,
        
                if (real(Sigmatmp(j))+imag(Sigmatmp(j)))>0
            
                Sigmatmp(j)=Sigmatmp(j);
            
                elseif (real(Sigmatmp(j))+imag(Sigmatmp(j)))<0
            
                Sigmatmp(j)=-Sigmatmp(j);
            
            end;
        
            end;
            
            sigma=Sigmatmp;clear Sigmatmp;
                        
            Sigma=diag(sigma);
                                
            %Matrices Q
            %----------
            
            invA=inv(A);
            
            Q11=kx_mat*ky_mat;
            Q12=a*invA+(1-a)*E-ky_mat^2;
            Q21=kx_mat^2-a*E-(1-a)*invA;
            Q22=-kx_mat*ky_mat;
            
            %Matrices W
            %----------
                                    
            W1=W(1:MN,1:2*MN);
            W2=W(MN+1:2*MN,1:2*MN);clear W;
            
            %Matrices V
            %----------
            
            invSigma=inv(Sigma);
            
            V1=(Q11*W1+Q12*W2)*invSigma;
            V2=(Q21*W1+Q22*W2)*invSigma;clear Q11 Q12 Q21 Q22;clear Sigma;
    
    %Matrices X
    %----------
    
    X_l=X_lp1;
        
    X_lp1=diag(exp(-k*sigma*d(l)));
    
    %Matrices T et F
    %---------------
    
    F_l=F_lp1;
    
    F_lp1=[W2          W2
           W1          W1
           sqrt(-1)*V2 -sqrt(-1)*V2
           sqrt(-1)*V1 -sqrt(-1)*V1];clear W1 W2 V1 V2
                 
    %[F_lp1U,F_lp1S,F_lp1V]=svd(F_lp1); 
          
    %T=F_lp1V*inv(F_lp1S)*F_lp1U'*F_l;clear F_lp1U F_lp1S F_lp1V F_l;
    
    T=F_lp1\F_l;
    
    t11=T(1:2*(MN),1:2*(MN));
    t12=T(1:2*(MN),2*(MN)+1:2*2*(MN));
    t21=T(2*(MN)+1:2*2*(MN),1:2*(MN));
    t22=T(2*(MN)+1:2*2*(MN),2*(MN)+1:2*2*(MN));

    clear T;
    
    
    %[t22U,t22S,t22V]=svd(t22);
    
    %invt22=t22V*inv(t22S)*t22U';clear t22U t22S t22V;
    
    invt22=inv(t22);
    
    %Matrice S
    %---------
    
        %Matrice s
        %---------
          
        s=[t11-t12*invt22*t21  t12*invt22
           -invt22*t21         invt22];clear t11 t12 t21 t22 invt22;
        
            %Matrice s chapeau
            %-----------------
    
            s_chap_g=[eye(2*(MN))   zeros(2*(MN)) 
                      zeros(2*(MN))  X_l];   
                      
            s_chap_d=[X_l               zeros(2*(MN)) 
                      zeros(2*(MN))  eye(2*(MN))];
            
            clear X_l;
                  
            s_chap=s_chap_g*s*s_chap_d;clear s;
            
            tuu=s_chap(1:2*(MN),1:2*(MN));
            rud=s_chap(1:2*(MN),2*(MN)+1:2*2*(MN));
            rdu=s_chap(2*(MN)+1:2*2*(MN),1:2*(MN));
            tdd=s_chap(2*(MN)+1:2*2*(MN),2*(MN)+1:2*2*(MN));
            
            clear s s_chap_g s_chap_d;
            
    Tuu_lm1=Tuu_l;
    Rud_lm1=Rud_l;
    Rdu_lm1=Rdu_l;
    Tdd_lm1=Tdd_l;
    
    %clear Tuu_l Rud_l Rdu_l Tdd_l; 
    
    inveyeRud=inv(eye(2*(MN))-Rud_lm1*rdu);
    inveyerdu=inv(eye(2*(MN))-rdu*Rud_lm1);
    
    Tuu_l=tuu*inveyeRud*Tuu_lm1;
    Rud_l=rud+tuu*Rud_lm1*inveyerdu*tdd;
    Rdu_l=Rdu_lm1+Tdd_lm1*rdu*inveyeRud*Tuu_lm1;       
    Tdd_l=Tdd_lm1*inveyerdu*tdd;  
    
    clear Tuu_lm1 Rud_lm1 Rdu_lm1 Tdd_lm1;
    
    clear tuu rud rdu tdd;
         
end;

%Fin de la boucle � rebourd sur "l"

%Calcul de Sn
%------------

F_l=F_lp1;

F_lp1=[eye(MN)                       zeros(MN)                    eye(MN)                      zeros(MN)                       
       zeros(MN)                     eye(MN)                      zeros(MN)                    eye(MN)  
       kx_mat*ky_mat/kIz_mat         (ky_mat^2+kIz_mat^2)/kIz_mat -kx_mat*ky_mat/kIz_mat       -(ky_mat^2+kIz_mat^2)/kIz_mat                                 
       -(kx_mat^2+kIz_mat^2)/kIz_mat -kx_mat*ky_mat/kIz_mat       (kx_mat^2+kIz_mat^2)/kIz_mat kx_mat*ky_mat/kIz_mat];  
  
    %[F_lp1U,F_lp1S,F_lp1V]=svd(F_lp1);
          
    %T=F_lp1V*inv(F_lp1S)*F_lp1U'*F_l;clear F_lp1U F_lp1S F_lp1V F_l;
    
    T=inv(F_lp1)*F_l;
    
    t11=T(1:2*(MN),1:2*(MN));
    t12=T(1:2*(MN),2*(MN)+1:2*2*(MN));
    t21=T(2*(MN)+1:2*2*(MN),1:2*(MN));
    t22=T(2*(MN)+1:2*2*(MN),2*(MN)+1:2*2*(MN));
    
    clear T;

    %Matrice S
    %---------
    
        %Matrice s
        %---------
          
        %[t22U,t22S,t22V]=svd(t22);
    
        %invt22=t22V*inv(t22S)*t22U';clear t22U t22S t22V;
        
        invt22=inv(t22);
        
        s=[t11-t12*invt22*t21  t12*invt22
           -invt22*t21           invt22];clear t11 t12 t21 t22 invt22;
        
            %Matrice s chapeau
            %-----------------
    
            s_chap_g=[eye(2*(MN))    zeros(2*(MN)) 
                      zeros(2*(MN))  X_lp1];   
                      
            s_chap_d=[X_lp1             zeros(2*(MN)) 
                      zeros(2*(MN))  eye(2*(MN))];
                  
            clear X_lp1;   
                  
            s_chap=s_chap_g*s*s_chap_d;clear s s_chap_g s_chap_d;
            
            tuu=s_chap(1:2*(MN),1:2*(MN));
            rud=s_chap(1:2*(MN),2*(MN)+1:2*2*(MN));
            rdu=s_chap(2*(MN)+1:2*2*(MN),1:2*(MN));
            tdd=s_chap(2*(MN)+1:2*2*(MN),2*(MN)+1:2*2*(MN));
            
            clear s_chap;
            
    Tuu_lm1=Tuu_l;
    Rud_lm1=Rud_l;
    Rdu_lm1=Rdu_l;
    Tdd_lm1=Tdd_l;
    
    inveyeRud=inv(eye(2*(MN))-Rud_lm1*rdu);
    inveyerdu=inv(eye(2*(MN))-rdu*Rud_lm1);
    
    Tuu_l=tuu*inveyeRud*Tuu_lm1;
    Rud_l=rud+tuu*Rud_lm1*inveyerdu*tdd;
    Rdu_l=Rdu_lm1+Tdd_lm1*rdu*inveyeRud*Tuu_lm1;       
    Tdd_l=Tdd_lm1*inveyerdu*tdd;  
    
    
    clear Tuu_lm1 Rud_lm1 Rdu_lm1 Tdd_lm1 tuu rud rdu tdd;
      
%Equation finale
%---------------
%---------------

S=[Tuu_l Rud_l
   Rdu_l Tdd_l];

fintmp=zeros(MN,1);
fintmp(round(MN/2))=1;

fin1=[zeros(MN,1)
      zeros(MN,1)
      ux*fintmp
      uy*fintmp];

%Solutions
%---------
%---------
    
    solut=S*[fin1];clear S;
 
%Resultats
%---------
%---------

    %Amplitudes dans la base  xyz
    %----------------------------

    Rx=solut(1:MN);

    Ry=solut((MN)+1:2*(MN));

    Tx=solut(2*(MN)+1:3*(MN));

    Ty=solut(3*(MN)+1:4*(MN));

    Rz=(-kx_vec'.*Rx-ky_vec'.*Ry)./kIz_vec';

    Tz=(-kx_vec'.*Tx-ky_vec'.*Ty)./kIIIz_vec';

    %Amplitudes dans la base s(TE) p(TM)
    %-----------------------------------
    
%Phi=atan(ky_vec./kx_vec)';

%Rs=cos(Phi).*Ry-sin(Phi).*Rx;

%Rp=(-sqrt(-1)/k).*(cos(Phi).*(kIz_vec'.*Rx-kx_vec'.*Rz)-sin(Phi).*(ky_vec'.*Rz-kIz_vec'.*Ry));

%Ts=cos(Phi).*Ty-sin(Phi).*Tx;

%Tp=(-sqrt(-1)/k).*(cos(Phi).*(kIIIz_vec'.*Tx-kx_vec'.*Tz)-sin(Phi).*(ky_vec'.*Tz-kIIIz_vec'.*Ty));

    %Efficacit�s de diffraction
    %--------------------------
   
    
    %nIc=k*sqrt(EI(i))*cos(theta);
    
    %nIIIc=k*sqrt(EIII)*cos(theta);
    
    %DER_s(i,:) = (Rs.*conj(Rs).*real(kIz_vec/nIc)')';
    
    %DER_p(i,:) = (Rp.*conj(Rp).*real((kIz_vec/EI(i))/nIc)')';
    
    %DET_s(i,:) = (Ts.*conj(Ts).*real(kIIIz_vec/nIc)')'; 
    
    %DET_p(i,:) = (Tp.*conj(Tp).*real((kIIIz_vec/EIII(i))/nIc)')';
    
    %test=1-sum((DER_s(i,:))'+(DER_p(i,:))'+(DET_s(i,:))'+(DET_p(i,:))');

    DER=real(kIz_vec'/(k*sqrt(EI)*cos(theta))).*((abs(Rx)).^2+(abs(Ry)).^2+(abs(Rz)).^2);
    
    DET=real(kIIIz_vec'/(k*sqrt(EI)*cos(theta))).*((abs(Tx)).^2+(abs(Ty)).^2+(abs(Tz)).^2);
   
    %test=1-sum(DER_s(i,:)+DER_p(i,:)+DET_s(i,:)+DET_p(i,:))
   
    test=1-sum(DER+DET)
    
    %dphi_sp(i)=angle(Tp(N+1))-angle(Ts(N+1));
    
    dphi_xy(i)=angle(Ty(round(MN/2)))-angle(Tx(round(MN/2)));
    
    phi_y(i,F_c)=angle(Ty(round(MN/2)));
    
    phi_x(i,F_c)=angle(Tx(round(MN/2)));
    

    
%R�sultats du bouclage principal
%-------------------------------

DER_fin(i,th,ep,F_c,:)=DER(round(MN/2));

DET_fin(i,th,ep,F_c,:)=DET(round(MN/2));

ky_vec_fin(i,ep,F_c,:)=ky_vec;

kx_vec_fin(i,ep,F_c,:)=kx_vec;

kIz_vec_fin(i,ep,F_c,:)=kIz_vec;

kIIIz_vec_fin(i,ep,F_c,:)=kIIIz_vec;

end;
end;
end;
end;

%Fin de la boucle principale sur "i"

%dphi_sp=unwrap(dphi_sp);

%dphi_xy=unwrap(dphi_xy);

%if dphi(nlb/2)<0

%    dphi=dphi+2*pi;
    
%else
    
%    dphi=dphi;
    
%end;

%figure;

%plot(lb,DER(:,N+1));

%hold on;

%plot(lb,DET(:,N+1));

%figure;

%plot(DET_s(:,N+1));

%hold on;

%plot(DET_p(:,N+1));