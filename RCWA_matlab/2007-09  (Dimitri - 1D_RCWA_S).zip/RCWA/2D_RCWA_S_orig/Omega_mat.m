function[Omega]=Omega_mat(E1,E2,kx_mat,ky_mat,a,M,N,MN,Fx,Fy,A,E)


%Matrices E A B D
%----------------

%E=E_mat(E1,E2,Fx,Fy,M,N);
%A=A_mat(E1,E2,Fx,Fy,M,N);
B=B_mat(kx_mat,E,MN);
D=D_mat(ky_mat,E,MN);

%Construction matrice Omega
%--------------------------

invA=inv(A);
invE=inv(E);

Omega=[kx_mat^2+D*(a*E+(1-a)*invA)                       ky_mat*(invE*kx_mat*(a*invA+(1-a)*E)-kx_mat)
       kx_mat*(invE*ky_mat*(a*E+(1-a)*invA)-ky_mat)    ky_mat^2+B*(a*invA+(1-a)*E)];

