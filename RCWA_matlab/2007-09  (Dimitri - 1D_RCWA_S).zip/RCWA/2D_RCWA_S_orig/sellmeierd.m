%Equation de Sellmeier

function[n]=sellmeierd(l,A,B)

l=l*1e-4;

n=sqrt(A+B*1/l^2);