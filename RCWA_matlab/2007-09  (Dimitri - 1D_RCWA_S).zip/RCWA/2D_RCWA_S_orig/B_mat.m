function[Btmp]=B_mat(kx_mat,E,MN)

%Construction matrice B

Btmp=kx_mat*inv(E)*kx_mat-eye(MN);
