%Diamant1
%-------
    
    A_d=1 ;
    
    B_d=0.3306 ; C_d=175.0 ;
    
    D_d= 4.3356 ; E_d=106.0 ;
    
%Diamant2
%-------

T=100;

A=5.64380+7.605e-5*T;

B=5.13865e-10+3.364e-13*T;


for i=1:100,

lb(i)=0.5+i*9.5/100;
    
d1(i)=sellmeier2b(lb(i),A_d,B_d,C_d,D_d,E_d);

d2(i)=sellmeierd(lb(i),A,B);

e(i)=abs(d1(i)-d2(i));

end;



plot(lb,d1); hold on; plot(lb,d2);

figure; plot(lb,e);