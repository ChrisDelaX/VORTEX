%Programme principal
%-------------------
%-------------------


%Gestion de la m�moire
%---------------------
%---------------------

    %Lib�ration 
    %----------

    clear all

    %Lectures des entr�es
    %--------------------
    %--------------------

    Entrees;

    MN=(2*M+1)*(2*N+1);
    
    %Allocation m�moire
    %------------------

    kx_mat=zeros(MN);
    ky_mat=zeros(MN);
    kIz_mat=zeros(MN);
    kIIIz_mat=zeros(MN);
    
    E=zeros(MN);
    A=zeros(MN);

    Omega=zeros(2*MN);
    
    Tuu_l=zeros(2*MN);
    Rud_l=zeros(2*MN);
    Rdu_l=zeros(2*MN);
    Tdd_l=zeros(2*MN);

    F_lp1=zeros(4*MN);
  
    X_lp1=zeros(2*MN);


%Vecteur de polarisation incident
%--------------------------------
%--------------------------------


    ux=cos(psi)*cos(theta)*cos(phi)-sin(psi)*sin(phi);

    uy=cos(psi)*cos(theta)*sin(phi)+sin(psi)*cos(phi);

    uz=-cos(psi)*sin(theta);


%Choix du param�tre de boucle principale "i" et d�but boucle principale
%----------------------------------------------------------------------
%----------------------------------------------------------------------

if exist('lb')==1,
    
    nlb=1;
    lbmin=lb;
    incr=0;
    
else
    
incr=(lbmax-lbmin)/(nlb-1);

end;

for i=1:nlb,
        
    
    
    lb(i)=lbmin+(i-1)*incr;

    %Indices des mat�riaux
    %---------------------
    
    %E2(i)=sellmeier2(lb(i),A_cdte,B_cdte,C_cdte,D_cdte,E_cdte);
    
    E2(i)=sellmeier2b(lb(i),A_d,B_d,C_d,D_d,E_d);
    
    %E2(i)=sellmeierX(lb(i),A_zns,B_zns,C_zns,D_zns,E_zns);
    
    %E2(i)=sellmeier2(lb(i),A_Ge,B_Ge,C_Ge,D_Ge,E_Ge);
    
    EIII(i)=E2(i);
    
%Calcul Vecteur d'onde
%---------------------

k=2*pi/lb(i);
    
%Boucle sur "m" (x)
%------------------

t=1;

for j=1:2*M+1,
    
    m=j-(M+1);
    
    %Etape construction kx
    %---------------------
    
    kx(j)=k*(sqrt(EI)*sin(theta)*cos(phi)-m*(lb(i)/Lbx));
    
%Boucle sur "n" (y)
%------------------

    for h=1:2*N+1,
    
    n=h-(N+1);
    
    %Etape construction ky
    %---------------------
    
    ky(h)=k*(sqrt(EI)*sin(theta)*sin(phi)-n*(lb(i)/Lby));

    %Etape construction kIz 
    %----------------------

    %if sqrt(EI)>sqrt((kx(j)/k)^2+(ky(h)/k)^2)

    kIz(j,h)=sqrt(k^2*EI-(kx(j))^2-(ky(h))^2);

    %elseif sqrt(EI)<sqrt((kx(j)/k)^2+(ky(h)/k)^2)
    
    %kIz(j,h)=-sqrt(-1)*k*sqrt((kx(j)/k)^2+(ky(h)/k)^2-EI);
        
    %end;
    
    %Etape construction kIIIz 
    %------------------------

    %if sqrt(EIII)>sqrt((kx(j)/k)^2+(ky(h)/k)^2)

    kIIIz(j,h)=sqrt(k^2*EIII(i)-(kx(j))^2-(ky(h))^2);

    %elseif sqrt(EIII)<sqrt((kx(j)/k)^2+(ky(h)/k)^2)
    
    %kIIIz(j,h)=-sqrt(-1)*k*sqrt((kx(j)/k)^2+(ky(h)/k)^2-EIII);
        
    %end;
    
    kxtmp(t)=kx(j);
    
    kytmp(t)=ky(h);
    
    kIztmp(t)=kIz(j,h);
    
    kIIIztmp(t)=kIIIz(j,h);
    
    t=t+1;
    
    end;%Fin de la boucle sur "n"

end;%Fin de la boucle sur "m"

%Vecteur kx
%----------

kx_vec=kxtmp; clear kxtmp;

%Matrice kx
%----------

kx_mat=diag(kx_vec)/k;
kxoo=kx_mat(round(MN/2),round(MN/2));

%Vecteur ky
%----------

ky_vec=kytmp; clear kxtmp;

%Matrice ky
%----------

ky_mat=diag(ky_vec)/k;
kyoo=ky_mat(round(MN/2),round(MN/2));

%Vecteur kIz
%-----------

kIz_vec=kIztmp; clear kIztmp;

%Matrice kIz
%-----------

kIz_mat=diag(kIz_vec)/k;

%Vecteur kIIIz
%-------------

kIIIz_vec=kIIIztmp; clear kIIIztmp;   

%Matrice kIIIz
%-------------

kIIIz_mat=diag(kIIIz_vec)/k;   


ky_vec_fin(i,:)=ky_vec;

kx_vec_fin(i,:)=kx_vec;

kIz_vec_fin(i,:)=kIz_vec;

kIIIz_vec_fin(i,:)=kIIIz_vec;

end;

figure;
plot(lb,180/pi*atan(kx_vec_fin(:,round(MN/2)+7)./real(kIz_vec_fin(:,round(MN/2)+1))));
hold on;
plot(lb,180/pi*atan(ky_vec_fin(:,round(MN/2)+1)./real(kIz_vec_fin(:,round(MN/2)+1))));

figure;
plot(lb,180/pi*atan(kx_vec_fin(:,round(MN/2))./real(kIz_vec_fin(:,round(MN/2)))));
hold on;
plot(lb,180/pi*atan(ky_vec_fin(:,round(MN/2))./real(kIz_vec_fin(:,round(MN/2)))));
