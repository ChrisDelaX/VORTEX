%Equation de Sellmeier pour les GASIR

function[n]=sellmeiergas(l,A,B,C,D,E)

%l=l*1e-3;

n=(A+B*l^2+C*l^4+D/l^4+E/l^2)^2;