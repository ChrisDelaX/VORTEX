%Equation de Sellmeier

function[n]=sellmeier2(l,A,B,C,D,E)

%l=l*1e-3;

n=(A+(B*(l^2)/((l^2)-C))+(D*(l^2)/((l^2)-E)));