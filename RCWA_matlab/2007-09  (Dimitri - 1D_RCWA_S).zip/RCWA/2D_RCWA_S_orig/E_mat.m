function[tp_mat]=E_mat(E1,E2,Fx,Fy,M,N)

%Construction matrice eps
%------------------------

%Passage de la permittivit� inverse du r�seau � sa transform�e de Fourier
%------------------------------------------------------------------------


%Construction profil 2D
%----------------------

Fxtmp=Fx*512;
        
Fytmp=Fy*512;

MN=(2*M+1)*(2*N+1);

Etmp=ones(512)*(E1);

Etmp(1:round(Fxtmp),1:round(Fytmp))=E2;

% for i=1:512,
%     
%     for j=1:512,
%     
%             if i<=Fxtmp & j<=Fytmp
%         
%             Etmp(i,j)=E2;
%         
%             else
%                 
%             Etmp(i,j)=E1;
%                 
%             end
%         
%     end
%     
% end


%Transform�e de Fourier 2D
%-------------------------

Etmp=fft2(Etmp)/(512^2);

Etmp=fftshift(Etmp);

%Etmpbis=Etmp(129-2*M:129+2*M,129-2*N:129+2*N);


%Agancement en matrice "Toeplitz"
%--------------------------------

m=-M;

n=-N;

for i=1:MN,
    
    p=-M;
    
    q=-N;
    
    for j=1:MN,    
                        
        tp_mat(i,j)=Etmp(257+(m-p),257+(n-q));
                
        if q<N
            
        q=q+1;
        
        elseif p<M
            
        p=p+1;
        
        q=-N;
            
        end;
     
    end;
    
    if n<N
        
    n=n+1;
    
    elseif m<M    
        
    n=-N;
    
    m=m+1;
    
    end;

end;
    
        
        
        

        

