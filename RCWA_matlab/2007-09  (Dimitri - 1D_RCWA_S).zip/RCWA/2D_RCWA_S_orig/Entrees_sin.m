%Configuration g�n�rale du probl�me
%----------------------------------


%Param�tres de calculs
%---------------------


    %Troncature
    
        %En X (M donc 2M+1 ordres au total)  
    
        M=6;
        
        %En Y (N donc 2N+1 ordres au total)
        
        N=6;
       
    %Param�tre alpha (entre 0 et 1)
    
        a=0.5;
        
    
%Param�tres du r�seau
%--------------------    
    

%Nombre de couches

    L=16;

    
%Pas du r�seau

    %En X

    %Lxmin=;
    %Lxmax=;
    Lbx=0.25;%/cos(pi*40/180);
    
        %Nombre de point d'�chantillonnage
    
        %nLx=;
    
    %En Y
    
    %Lymin=;
    %Lymax=;
    Lby=0.25;
    
        %Nombre de point d'�chantillonnage
    
        %nLy=;

%Epaisseurs

    %dmin(l)=;
    %dmax(l)=;
    
for i=1:L,
        
    %d(i)=1+(i-1)*0.2;
    
 %d(i)=1.-0.2+(i-1)*1/10;    
 d(i)=0.7/L;
 
end;
        
%Permittivit�s
%-------------


    %Permittivit�s milieu ext�rieur incident
    %---------------------------------------
    
    EI=1;
    
    %Permittivit�s milieu ext�rieur �mergent
    %---------------------------------------
    
    
    %Ge
    %--

    T=94;
    
    A_Ge=-6.040e-3*T + 11.05128 ; B_Ge = 9.295e-3*T + 4.00536 ;

    C_Ge = -5.392e-4*T + 0.599034 ; D_Ge = 4.151e-4*T + 0.09145;

    E_Ge = 1.51408*T + 3426.5 ;
    
    %ZnS
    %---
    
    T=84.9;
    
    A_zns=5.608e-5*T + 2.282; B_zns=-8.671e-6*T - 1.563e-2;

    C_zns=5.549e-7*T +2.067e-3; D_zns=2.597e-8*T- 1.714e-4;

    E_zns=-9.798e-10*T + 2.884e-6;

    
    
    %CdTe � 7 K
    %----------
    
    T=77;
    
    A_cdte = -2.373e-4*T + 3.8466; B_cdte = 8.057e-4*T + 3.2215;

    C_cdte = -1.10e-4*T + 0.1866; D_cdte = -2.160e-2*T + 12.718;

    E_cdte = -3.160e1*T + 18753;

    
    %Diamant
    %-------
    
    A_d=1 ;
    
    B_d=0.3306 ; C_d=175.0 ;
    
    D_d= 4.3356 ; E_d=106.0 ;
    
    %EIII=5.76
    
    %Chalco
    %------
    
        %GASIR
        %-----
        
        A_ga=2.5060; B_ga=-1.2137e-4; C_ga=-1.2558e-7;
        D_ga=4.7296e-3; E_ga=7.9356e-2;
    
        
        %IG6
ig6=[3.0				      2.8014
4.0				      2.7945
5.0				      2.7907
6.0                   2.7880
7.0				      2.7854
8.0				      2.7831
9.0				      2.7803
10				      2.7775
11				      2.7747
12				      2.7721];

    
    %Permittivit�s du r�seau
    %-----------------------
    
        %R�seau en relief de surface
        %---------------------------
        
        
            %Permittivit� milieu 1
            
            E1(1)=1;
    
            %Permittivit� milieu 2
            
            %E2(1)=5.76;
            
            %Facteur de remplissage
            
                %En X
            
                %Fxmin=0.1;
                %Fxmax=0.9;
                
                %tmp(1)=8;
                %tmp(2)=16;
                %tmp(3)=32;
                %tmp(4)=64;
                %tmp(5)=128;
                %tmp(6)=256;
                %tmp(7)=512;
                %tmp(8)=1024;
               
                
                %h=d(1);
                
                    %Fx=0.7;%/cos(pi*40/180);;
                    %Fy=0.7;
                
                    for j=1:L,
                        
                        Fx(j)=(1/pi)*acos(2*(j-.5)/(L)-1);
                        Fy(j)=(1/pi)*acos(2*(j-.5)/(L)-1);
                    end;
                    
                    %Fx=fliplr(Fx);
                    
                    %Fy=fliplr(Fy);
                    %for j=1:L,
                    
                    %tmp(j)=j*h/L;    
                        
                    %Fx(j)=(1-tmp(j)/h+h/(2*L));
                    
                    %Fy(j)=Fx(j);
                    
                    %end;
                        
                    %for i=1:1,
                    
                    %Ftmp(i)=0.95+(i-1)*0.2/9
                    
                    %Fx(i,j)=Ftmp(i)*(7/tmp(j));
                    
                    %for i=1:11,
                        
                    %Fx(i)=0.71-0.05+0.1*(i-1)/10;
                    
                    %Nombre de point d'�chantillonnage
    
                    %nFx=9;
    
                    %En Y
    
                    %Fymin=0.1;
                    %Fymax=0.9;
                
                    %Fy(i,j)=Ftmp(i)*(7/tmp(j));
            
                    %Fy(i)=0.71-0.05+0.1*(i-1)/10;
                    %end;
                    
                    %Fx=0.7;
                    %Fy=0.7;
                    
                    %end;
            
                    %end;
                
                    %Nombre de point d'�chantillonnage
    
                    %nFy=9;
            
        %R�seau en volume
        %----------------
        
        
            %Permittivit� moyenne
            
            %epsm(l)=;
            
            %Modulation de permittivit�
            
            %modmin(l)=;
            %modmax(l)=;
            %mod(l)=;
            
                %Nombre de point d'�chantillonnage
    
                %nmod=;
            
                
                
%Incidence
%---------

    %Longueur d'onde
    
    lbmin=0.400;
    lbmax=0.900;
%     lb=10;
    
        %Nombre de point d'�chantillonnage
    
        nlb=16;

    %Angle incidence non conique
    
    thetamin=0;
    %thetamax=45/180*pi;
    theta=pi*0/180;
    
        %Nombre de point d'�chantillonnage
    
        ntheta=1;
    
    %Angle incidence conique

    %phimin=;
    %phimax=;
    phi=0;
    
        %Nombre de point d'�chantillonnage
    
        %nlphi=;
        
    %Angle polarisation
    
    %psimax=;
    %psimin=;�
    psi=pi/4;
    
        %Nombre de point d'�chantillonnage
    
        %nlpsi=;
        
    

    

    
