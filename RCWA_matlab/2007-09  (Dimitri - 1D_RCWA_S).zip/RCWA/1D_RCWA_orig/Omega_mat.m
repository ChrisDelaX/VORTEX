function[Omega]=Omega_mat(kx_mat,ky_mat,a,E,A,B,D)

%Construction matrice Omega l

Omega=[kx_mat^2+D*(a*E+(1-a)*A^(-1))                       ky_mat*(E^(-1)*kx_mat*(a*A^(-1)+(1-a)*E)-kx_mat)
       kx_mat*(E^(-1)*ky_mat*(a*E+(1-a)*A^(-1))-ky_mat)    ky_mat^2+B*(a*A^(-1)+(1-a)*E)];