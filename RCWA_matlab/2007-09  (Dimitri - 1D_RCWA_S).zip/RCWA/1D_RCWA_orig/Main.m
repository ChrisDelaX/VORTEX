%Programme principal
%-------------------
%-------------------

clear all

%Lectures des entr�es
%--------------------

Entrees;

%Vecteur de polarisation incident
%--------------------------------

%ux=cos(psi)*cos(theta)*cos(phi)-sin(psi)*sin(phi);

%uy=cos(psi)*cos(theta)*sin(phi)+sin(psi)*cos(phi);

%uz=-cos(psi)*sin(theta);


%Choix du param�tre de boucle principale "i" et d�but boucle principale
%----------------------------------------------------------------------
%----------------------------------------------------------------------

if exist('lb')==1,
    
    nlb=1;
    lbmin=lb;
    incr=0;
    
else
    
incr=(lbmax-lbmin)/nlb;

end;

for i=1:nlb,
    
    
    lb(i)=lbmin+(i-1)*incr;
    
    E1(i)=sellmeier2(lb(i),A_cdte,B_cdte,C_cdte,D_cdte,E_cdte);
    
    EIII(i)=E1(i);
    
    EI(i)=E1(i);
    
%Calcul Vecteur d'onde
%---------------------

k=2*pi/lb(i);
    
%Boucle sur "j"
%--------------

%Construction ky
%---------------

    ky=k*sqrt(EI(i))*sin(theta)*sin(phi);

for j=1:2*N+1,
    
    jbis=j-(N+1);
    
    %Construction kx_vec
    %-------------------
    
    kx_vec(j)=k*(sqrt(EI(i))*sin(theta)*cos(phi)-jbis*(lb(i)/Lb));
    
       
    %Construction kIz_vec 
    %--------------------
    
    kIz_vec(j)=sqrt(k^2*EI(i)-(kx_vec(j))^2-(ky)^2);

    %Construction kIIIz_vec 
    %----------------------

    kIIIz_vec(j)=sqrt(k^2*EIII(i)-(kx_vec(j))^2-(ky)^2);
    
end;%Fin de la boucle sur "j"

%Matrice kx
%----------

kx_mat=diag(kx_vec)/k;
%kxoo=kx_mat(1,1);

%Matrice ky
%----------

ky_vec=ky*ones(2*N+1,1);
ky_mat=diag(ky_vec)/k;
%kyoo=ky_mat(1,1);

%Matrice Y_I et Z_I
%------------------

Y_I=diag(kIz_vec)/k;

Z_I=diag(kIz_vec)/(k*EI(i));

%Matrice Y_III et Z_III
%----------------------

Y_III=diag(kIIIz_vec)/k;  

Z_III=diag(kIIIz_vec)/(k*EIII(i));   

%Matrice delta
%-------------

delta=zeros(2*N+1,1);
delta(N+1)=1;


%Boucle � rebourd sur "l", le nombre de couches
%----------------------------------------------
%----------------------------------------------


%Initialisation
%--------------

    %Matrices X
    %----------
    
    %XX=zeros(2*(2*N+1),2*(2*N+1),L);
    
    %a_mat=zeros(2*(2*N+1),2*(2*N+1),L);
    
    A_p=[eye(2*N+1)     zeros(2*N+1)
         sqrt(-1)*Y_III zeros(2*N+1)
         zeros(2*N+1)   eye(2*N+1)
         zeros(2*N+1)   sqrt(-1)*Z_III];
     
    Trsf=[eye(2*N+1)   zeros(2*N+1)
          zeros(2*N+1) eye(2*N+1)];
    
for l=1:L,
    
l=L-l+1;

%Valeur et vecteurs propres de la matrice Omega
%----------------------------------------------

E=E_mat(E1(i),E2(l),F(l),N,Lb);
A=A_mat(E1(i),E2(l),F(l),N,Lb);
B=B_mat(kx_mat,E,N);
%D=D_mat(ky_mat,E,N);

OmegaU=OmegaU_mat(kx_mat,ky,E,N);
OmegaS=OmegaS_mat(ky,A,B,N);

[W1,Sigmatmp1]=eig(OmegaU,'nobalance'); 
[W2,Sigmatmp2]=eig(OmegaS,'nobalance');

%Matrice [f1;g1]
%---------------

    %Matrice F
    %---------
    
        %Matrices V
        %----------
            
            %Matrice Sigma - vecteur sigma
            %-----------------------------
            
            sigma1=diag(sqrt(Sigmatmp1));
            sigma2=diag(sqrt(Sigmatmp2));
            
            %Sigmatmpb=Sigmatmp/sqrt(-1)
            
            %Test sur les valeurs propres
            %----------------------------
            
            %for j=1:2*N+1,
        
            %   if (real(Sigmatmp1(j))+imag(Sigmatmp1(j)))>0
            
            %    Sigmatmp1(j)=Sigmatmp1(j);
            
            %    elseif (real(Sigmatmp1(j))+imag(Sigmatmp1(j)))<0
            
            %    Sigmatmp1(j)=-Sigmatmp1(j);
            
            %    end;
        
            %end;
            
            %for j=1:2*N+1,
        
            % if (real(Sigmatmp2(j))+imag(Sigmatmp2(j)))>0
            
            %    Sigmatmp2(j)=Sigmatmp2(j);
            
            %elseif (real(Sigmatmp2(j))+imag(Sigmatmp2(j)))<0
            
            %    Sigmatmp2(j)=-Sigmatmp2(j);
            
            %end;
        
            %end;
            
            Sigma1=diag(sigma1);
            
            Sigma2=diag(sigma2);
           
        V11=inv(kx_mat^2-E)*W1*Sigma1;
        V12=(ky/k)*inv(kx_mat^2-E)*kx_mat*W2;
        V21=(ky/k)*inv(B)*kx_mat*inv(E)*W1;
        V22=inv(B)*W2*Sigma2;
        
        if (ky == 0)
        phibis = zeros(1,2*N+1);
        else
        phibis = atan(ky./kx_vec);
        end
        
        Fc=diag(cos(phibis));%*(ones(2*N+1,1)));
        Fs=diag(sin(phibis));%*(ones(2*N+1,1)));
        
    Vss=Fc*V11;
    Vsp=Fc*V12-Fs*W2;
    Vps=Fs*V11;
    Vpp=Fc*W2+Fs*V12;
    Wss=Fc*W1+Fs*V21;
    Wsp=Fs*V22;
    Wps=Fc*V21-Fs*W1;
    Wpp=Fc*V22;    
    
    %Matrices X
    %----------
    
    X1=diag(exp(-k*sigma1*d(1)));
    X2=diag(exp(-k*sigma2*d(l)));
    
    %Matrices a et b
    %---------------

    XX=[X1            zeros(2*N+1)
        zeros(2*N+1)  X2];
    
    Abis=[Vss Vsp Vss Vsp 
          Wss Wsp -Wss -Wsp
          Wps Wpp -Wps -Wpp
          Vps Vpp Vps Vpp];
    
    [AU,AS,AV]=svd(Abis); 
          
    abtemp=AV*inv(AS)*AU'*A_p;
               
    a_mat=abtemp(1:2*(2*N+1),1:2*(2*N+1));
    
    b=abtemp(2*(2*N+1)+1:4*(2*N+1),1:2*(2*N+1));
    
    [aU,aS,aV]=svd(a_mat);
    
    A_p=Abis*[eye(2*N+1)   zeros(2*N+1)
              zeros(2*N+1) eye(2*N+1)
              XX*b*aV*inv(aS)*aU'*XX];

    %Construction de la matrice de transfert ici pour �viter stockage
    %----------------------------------------------------------------
    
    Trsf=Trsf*aV*inv(aS)*aU'*XX;
           
end;

%Fin de la boucle � rebourd sur "l"


%Equation finale
%---------------
%---------------


fin1=[sin(psi)*delta
      sqrt(-1)*sin(psi)*sqrt(EI(i))*cos(theta)*delta
      -sqrt(-1)*cos(psi)*sqrt(EI(i))*delta
      cos(psi)*cos(theta)*delta];
  
fin2=[-eye(2*N+1)      zeros(2*N+1)         
      sqrt(-1)*Y_I     zeros(2*N+1)         
      zeros(2*N+1)     -eye(2*N+1)               
      zeros(2*N+1)     sqrt(-1)*Z_I];
  
%fin3=A_p;  


%Solutions
%---------
%---------
    
    royal=[fin2, A_p];

    solut=royal\fin1;

    %R�cursion
    %---------

    T_1=solut(2*(2*N+1)+1:4*(2*N+1));

    T=Trsf*T_1;
 
%Resultats
%---------
%---------


Rs=solut(1:2*N+1);

Rp=solut((2*N+1)+1:2*(2*N+1));

Ts=T(1:2*N+1);

Tp=T((2*N+1)+1:2*(2*N+1));

%Rs=(-kx_vec'.*Rs-ky_vec'.*Rp)./kIz_vec';

%Tp=(-kx_vec'.*Ts-ky_vec'.*Tp)./kIIIz_vec';

    %Efficacit�s de diffraction
    %--------------------------
    
    %DER_TE=real(kIz_vec'/(k*sqrt(EI)*cos(theta))).*((abs(Rs)).^2);
    
    nIc=k*sqrt(EI(i))*cos(theta);
    
    %nIIIc=k*sqrt(EIII)*cos(theta);
    
    DER_s(i,:) = (Rs.*conj(Rs).*real(kIz_vec/nIc)')';
    
    DER_p(i,:) = (Rp.*conj(Rp).*real((kIz_vec/EI(i))/nIc)')';
    
    DET_s(i,:) = (Ts.*conj(Ts).*real(kIIIz_vec/nIc)')'; 
    
    DET_p(i,:) = (Tp.*conj(Tp).*real((kIIIz_vec/EIII(i))/nIc)')';
    
    test=1-sum((DER_s(i,:))'+(DER_p(i,:))'+(DET_s(i,:))'+(DET_p(i,:))')

    dphi(i)=angle(Tp(N+1))-angle(Ts(N+1));
    
end;

%Fin de la boucle principale sur "i"

%dphi_out=(phi_TE)-(phi_TM);

figure;

dphi=unwrap(dphi)+2*pi;

plot(lb,dphi);

%figure;

%plot(lb,DER_s(:,N+1));

%hold on;

%plot(lb,DER_p(:,N+1));

figure;

plot(lb,DET_s(:,N+1));

hold on;

plot(lb,DET_p(:,N+1));