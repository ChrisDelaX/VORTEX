function rcwa_fields(field_flag)
% Multi-Layer Grating (Filename rcwa_fields.m)
%
% Calculates reflectance and transmission coefficients using
% Rigorous Coupled Wave Analysis (RCWA) for conical or planar
% (TE, TM) diffraction from a multi-layer structure on a substrate.
% Layers may be either homogeneous or binary gratings and may be
% combined in any order.
% Allows complex refractive index.
%
%***********************************************
%
% Diana M. Chambers
%
%***********************************************
% Assumptions:
% 1. Simple, binary grating
% 1a. All gratings must have the same period
% 2. Coordinate system:
% x=0 at rising edge of a grating ridge,
% runs perpendicular to grating
% z=0 at top of grating, runs thru grating into substrate
% 3. The matrix A has real eigenvalues;
% A must be Hermitian (or symmetric)
%
%------------------------------------------------------------------------------
%
% Input file format
%
% GUI Mode:
% This software assumes interface through the GUI "rcwa.m"
% Data input is handled in the GUI.
%
% Batch Mode:
% When Run! - RCWA Only is selected a popup window prompts the user for
% a file name. This file should contain the names of input parameter
% files to be batched, each on a separate line.
% The input parameter file format is as follows:
% 
% The file is ASCII format arranged by lines. The first line is a
% character string to define the column headings: Parameter,
% Min, Max, Increment, Algorithm (reference to index function).
% These headings are ignored when reading the file.
% The second line is blank.
% The following 11 lines contain system parameters in the column format
% given above. The parameters listed are wavelength, theta, phi, psi,
% grating period, number of positive orders, number of negative orders,
% incident media index (real), exiting media index (real and imaginary) and
% number of layers.
% % Layer parameters follow with each layer preceded by a blank line and a
% line with a character string to specify either grating or homogeneous.
% Parameters defined for a grating layer are thickness, grating offset,
% ridge width, refractive index of ridge (real and imaginary) and
% refractive index of the groove (real and imaginary).
% Parameters for a homogeneous layer are thickness and refractive
% index (real and imaginary).
%
% Example input file:
%
%PARAMETER MIN MAX INCREMENT ALGORITHM
%
%lambda 2.060000e+000 2.060000e+000 0.000000e+000
%theta 0.000000e+000 0.000000e+000 0.000000e+000
%phi 0.000000e+000 0.000000e+000 0.000000e+000
%psi 9.000000e+001 9.000000e+001 0.000000e+000
%grating_period 4.000000e+000 4.000000e+000 0.000000e+000
%num_orders_pos 1.000000e+001 1.000000e+001 0.000000e+000
%num_orders_neg 1.000000e+001 1.000000e+001 0.000000e+000
%Re_index_I 1.500000e+000 1.500000e+000 0.000000e+000 Linear
%Re_index_II 1.500000e+000 1.500000e+000 0.000000e+000 Linear
%Im_index_II 0.000000e+000 0.000000e+000 0.000000e+000 Linear
%num_layers 2
%
% GRATING_LAYER
%thickness 1.000000e+000 1.000000e+000 0.000000e+000
%grating_offset 1.889000e+000 1.889000e+000 0.000000e+000
%ridge_width 2.000000e+000 2.000000e+000 0.000000e+000
%Re_index_ridge 2.000000e+000 2.000000e+000 0.000000e+000 Linear 
%Im_index_ridge 0.000000e+000 0.000000e+000 0.000000e+000 Linear
%Re_index_groove 1.500000e+000 1.500000e+000 0.000000e+000 Linear
%Im_index_groove 0.000000e+000 0.000000e+000 0.000000e+000 Linear
%
% HOMOGENEOUS_LAYER
%thickness 4.400000e+000 4.400000e+000 0.000000e+000
%Re_uniform_index 1.500000e+000 1.500000e+000 0.000000e+000 Linear
%Im_uniform_index 0.000000e+000 0.000000e+000 0.000000e+000 Linear
%
%
% Diffraction efficiencies will be calculated and stored in the output file
% for each set of input parameters.
% There is no inherent limit to the number of data sets or layers.
%
% Variable descriptions are found below.
%
%------------------------------------------------------------------------------
%
% Output file format
%
% All variables are output using the '%g' format in a fprintf function.
%
% Two output files are generated. Both files will contain one output line for
% each set of input parameters.
%
% For output_mode = 1, the first file contains only information about the +1
% order, preceded by basic parameters:
% lambda_0, theta_0, grating_period, num_orders, DE1, DE_R(+1), and DE_T(+1)
% where: DE1 is total reflected and transmitted energy in the +1 order and
% DE_R and DE_T are the individual components.
%
% For output_mode = 2, the first file contains only 0 order DE_R & DE_T values
%
% For output_mode = 3, the first file is the same as for output_mode = 2 with
% the addition of the phase of the transmitted 0 order.
%
% The second file contains all orders up to where +/- are symmetric.
% The orders are interleaved according to the formst:
% lambda_0, theta_0, grating_period, DE1, DE_R(0), DE_T(0), DE_R(+1), DE_T(+1),
% DE_R(-1), DE_T(-1), DE_R(+2), DE_T(+2), DE_R(-2), DE_T(-2) . . . 
%
% Modifications to the output file format can be made in the fprintf
% statements at the end of the file.
%
% Output file names are chosen by the user in GUI mode. For batch mode, the
% file names are created by using the input parameter file name and replacing
% the '.dat' extension by either '.1' or '.0' for one file, dependent on
% output mode option, and '.all' for the second file.
%
%
% Field matrix output file format:
%
% One file is created for each pertinent field component. The files are
% formatted and tab delimited. The first row begins with a tab, then contains
% the z position of each column. The first column of subsequent rows contains
% the x position of that row. The remaining elements in each row contain the
% field matrix values.
%
%------------------------------------------------------------------------------
%
% Variable Definitions
%
% lambda_0 Free space wavelength (microns)
% theta Incident angle, rotation about y-axis (degrees)
% (Range of theta uses theta_min, theta_max, theta_step)
% phi_0 Incident angle, rotation about z-axis (degrees)
% psi_0 Angle of electric field wrt plane of incidence, 0=TM, 90=TE
% Re(index_I) Real part of Refractive index in Region I, incident region
% Im(index_I) Imaginary part of Refractive index in Region I, incident
% region
% Re(index_II) Real part of Refractive index in Region II, substrate
% Im(index_II) Imaginary part of Refractive index in Region II, substrate
% grating_period Period of grating (microns)
% num_layers Number of layers, grating and homogeneous combined
% num_orders_pos Number of positive orders retained in calculation
% num_orders_neg Number of negative orders retained in calculation
%
% layer_id Distinguishes grating (=1) from uniform (=2) layer
% thickness Thickness of uniform or grating layer (microns)
% Re(uniform_index) Real part of Refractive index of uniform layer 
% Im(uniform_index) Imaginary part of Refractive index of uniform layer
% grating_offset Offset from x=0 of rising edge of grating (microns)
% ridge_width Width of grating ridge (microns)
% Re(index_ridge) Real part of Refractive index of ridges of grating
% Im(index_ridge) Imaginary part of Refractive index of ridges of grating
% Re(index_groove) Real part of Refractive index of grooves of grating
% Im(index_groove) Imaginary part of Refractive index of grooves of grating
%
% dif_pol Diffraction/polarization 1=TE, 2=TM, 3=Conical
% Emat_offset Offset into permittivity matrix
% E_val Eigenvalues
% E_vec Eigenvectors
% E_prod Product of eigenvalues and eigenvectors
%
% incident Matrix representing incident E/H fields
% convert_T Accum. conversion factor to recover transmitted energies;
% result of enhanced transmittance matrix technique
% fou_harmoncs Fourier harmonics for relative permittivity
% rec_fou_harmonics Reciprocal fourier harmonics
% E Relative permittivity matrix
% rec_E Reciprocal relative permittivity matrix
%
%
%------------------------------------------------------------------------------
%------------------------------------------------------------------------------
%
% Determine run mode, if ==1 -> GUI, if ==2 -> batch
%
% Run Mode option
h_menu_runmode = findobj(0, 'Tag', 'RunMode');
runmodemenulist = get(h_menu_runmode,'UserData');
run_mode = runmodemenulist(length(runmodemenulist));
if (run_mode == 2) % Batch mode
% Get name of file containing list of file names to batch
[infile,pathname] = uigetfile ('*.*', 'Open Input File', 100, 100);
[inf_list, message] = eval(['fopen ( ''' pathname infile ''', ''r'')']);
if inf_list == -1 
error(message)
end
file_name = fscanf(inf_list, '%s\n',1);
Read_input_file(pathname, file_name)
end % Check for batch mode
another_case = 1;
while (another_case)
%
% Get data from GUI
%
h_menu_sysparams = findobj(0, 'Tag', 'SysParams');
sys_param_list = get(h_menu_sysparams, 'UserData');
grating_period_min = sys_param_list(1);
grating_period_max = sys_param_list(2);
grating_period_incr = sys_param_list(3);
lambda_min = sys_param_list(4);
lambda_max = sys_param_list(5);
lambda_incr = sys_param_list(6);
num_orders_pos_min = sys_param_list(7);
num_orders_pos_max = sys_param_list(8);
num_orders_pos_incr = sys_param_list(9);
num_orders_neg_min = sys_param_list(10);
num_orders_neg_max = sys_param_list(11);
num_orders_neg_incr = sys_param_list(12);
dif_pol = sys_param_list(13);
theta_min = sys_param_list(14);
theta_max = sys_param_list(15);
theta_incr = sys_param_list(16);
phi_min = sys_param_list(17);
phi_max = sys_param_list(18);
phi_incr = sys_param_list(19);
psi_min = sys_param_list(20);
psi_max = sys_param_list(21);
psi_incr = sys_param_list(22);
Re_index_I_c0 = sys_param_list(23);
Re_index_I_c1 = sys_param_list(24); 
Re_index_I_c2 = sys_param_list(25);
inc_algor = sys_param_list(26);
Re_index_II_c0 = sys_param_list(27);
Re_index_II_c1 = sys_param_list(28);
Re_index_II_c2 = sys_param_list(29);
exitre_algor = sys_param_list(30);
Im_index_II_c0 = sys_param_list(31);
Im_index_II_c1 = sys_param_list(32);
Im_index_II_c2 = sys_param_list(33);
exitim_algor = sys_param_list(34);
h_menu_displayer = findobj(0, 'Tag', 'DispLayers');
disp_layer_list = get(h_menu_displayer, 'UserData');
num_layers = disp_layer_list(1);
ostart = 2;
oend = 1+num_layers;
layer_id = disp_layer_list(ostart:oend);
ostart = ostart+num_layers;
oend = oend+num_layers;
thickness_min = disp_layer_list(ostart:oend);
ostart = ostart+num_layers;
oend = oend+num_layers;
thickness_max = disp_layer_list(ostart:oend);
ostart = ostart+num_layers;
oend = oend+num_layers;
thickness_incr = disp_layer_list(ostart:oend);
ostart = ostart+num_layers;
oend = oend+num_layers;
grating_off_min = disp_layer_list(ostart:oend);
ostart = ostart+num_layers;
oend = oend+num_layers;
grating_off_max = disp_layer_list(ostart:oend);
ostart = ostart+num_layers;
oend = oend+num_layers;
grating_off_incr = disp_layer_list(ostart:oend);
ostart = ostart+num_layers;
oend = oend+num_layers;
ridge_width_min = disp_layer_list(ostart:oend);
ostart = ostart+num_layers;
oend = oend+num_layers; 
ridge_width_max = disp_layer_list(ostart:oend);
ostart = ostart+num_layers;
oend = oend+num_layers;
ridge_width_incr = disp_layer_list(ostart:oend);
ostart = ostart+num_layers;
oend = oend+num_layers;
Re_uniform_index_c0 = disp_layer_list(ostart:oend);
ostart = ostart+num_layers;
oend = oend+num_layers;
Re_uniform_index_c1 = disp_layer_list(ostart:oend);
ostart = ostart+num_layers;
oend = oend+num_layers;
Re_uniform_index_c2 = disp_layer_list(ostart:oend);
ostart = ostart+num_layers;
oend = oend+num_layers;
uindexre_algor = disp_layer_list(ostart:oend);
ostart = ostart+num_layers;
oend = oend+num_layers;
Im_uniform_index_c0 = disp_layer_list(ostart:oend);
ostart = ostart+num_layers;
oend = oend+num_layers;
Im_uniform_index_c1 = disp_layer_list(ostart:oend);
ostart = ostart+num_layers;
oend = oend+num_layers;
Im_uniform_index_c2 = disp_layer_list(ostart:oend);
ostart = ostart+num_layers;
oend = oend+num_layers;
uindexim_algor = disp_layer_list(ostart:oend);
ostart = ostart+num_layers;
oend = oend+num_layers;
Re_index_ridge_c0 = disp_layer_list(ostart:oend);
ostart = ostart+num_layers;
oend = oend+num_layers;
Re_index_ridge_c1 = disp_layer_list(ostart:oend);
ostart = ostart+num_layers;
oend = oend+num_layers;
Re_index_ridge_c2 = disp_layer_list(ostart:oend);
ostart = ostart+num_layers;
oend = oend+num_layers;
rdindexre_algor = disp_layer_list(ostart:oend); 
ostart = ostart+num_layers;
oend = oend+num_layers;
Im_index_ridge_c0 = disp_layer_list(ostart:oend);
ostart = ostart+num_layers;
oend = oend+num_layers;
Im_index_ridge_c1 = disp_layer_list(ostart:oend);
ostart = ostart+num_layers;
oend = oend+num_layers;
Im_index_ridge_c2 = disp_layer_list(ostart:oend);
ostart = ostart+num_layers;
oend = oend+num_layers;
rdindexim_algor = disp_layer_list(ostart:oend);
ostart = ostart+num_layers;
oend = oend+num_layers;
Re_index_groove_c0 = disp_layer_list(ostart:oend);
ostart = ostart+num_layers;
oend = oend+num_layers;
Re_index_groove_c1 = disp_layer_list(ostart:oend);
ostart = ostart+num_layers;
oend = oend+num_layers;
Re_index_groove_c2 = disp_layer_list(ostart:oend);
ostart = ostart+num_layers;
oend = oend+num_layers;
grindexre_algor = disp_layer_list(ostart:oend);
ostart = ostart+num_layers;
oend = oend+num_layers;
Im_index_groove_c0 = disp_layer_list(ostart:oend);
ostart = ostart+num_layers;
oend = oend+num_layers;
Im_index_groove_c1 = disp_layer_list(ostart:oend);
ostart = ostart+num_layers;
oend = oend+num_layers;
Im_index_groove_c2 = disp_layer_list(ostart:oend);
ostart = ostart+num_layers;
oend = oend+num_layers;
grindexim_algor = disp_layer_list(ostart:oend);
ostart = ostart+num_layers;
oend = oend+num_layers;
disp_layer = disp_layer_list(ostart);
if (disp_layer < 1) 
disp_layer = 1;
end
if (disp_layer > num_layers)
disp_layer = num_layers;
end
% Output option
h_menu_output = findobj(0, 'Tag', 'OutputOption');
outputmenulist = get(h_menu_output,'UserData');
output_mode = outputmenulist(length(outputmenulist));
%
% Set proper offsets into permittivity matrix
%
num_gratings = 0;
num_uniform = 0;
for nl=1:num_layers
if layer_id(nl) == 1;
num_gratings = num_gratings+1;
Emat_offset(nl) = num_gratings;
else
num_uniform = num_uniform+1;
Gmat_offset(nl) = num_uniform;
end
end
if strcmp(lower(field_flag), 'calc_fields')
h_menu_fieldspecs = findobj(0, 'Tag', 'FieldSpecs');
field_spec_list = get(h_menu_fieldspecs, 'UserData');
dist_before = field_spec_list(1);
dist_after = field_spec_list(2);
z_resolution = field_spec_list(3);
dist_along = field_spec_list(4);
x_resolution = field_spec_list(5);
dist_parallel = field_spec_list(6);
y_resolution = field_spec_list(7);
z_max = field_spec_list(8);
z_min = field_spec_list(9);
x_max = field_spec_list(10); 
x_min = field_spec_list(11);
y_max = field_spec_list(12);
y_min = field_spec_list(13);
z_out = field_spec_list(14:length(field_spec_list));
end
h_menu_layers = findobj(0, 'Tag', 'Layers');
%------------------------------------------------------------------------------
%
% Get output file names from user (output_mode == 1), or
% Set up automatic file names (output_mode == 0,1 and/or run_mode == 2)
%
if (run_mode == 1) % GUI mode
h_menu_load = findobj(0, 'Tag', 'LoadMenu');
file_name = get(h_menu_load,'UserData');
if (output_mode == 1) % +1 order output
DefaultFilename = MakeName(file_name,'.dat','.1');
MessageTextOutFile = '+1 order file name';
elseif (output_mode == 2) % 0 order output (wiregrid)
DefaultFilename = MakeName(file_name,'.dat','.0');
MessageTextOutFile = '0 order file name (wiregrid)';
elseif (output_mode == 3) % 0 order output (waveplate)
DefaultFilename = MakeName(file_name,'.dat','.0');
MessageTextOutFile = '0 order file name (waveplate)';
end
[outfile, path_outf] = uiputfile( DefaultFilename, MessageTextOutFile);
[outf, message] = eval(['fopen (''' path_outf outfile ''', ''w'')']);
if outf == -1
error(message)
end
DefaultFilename = MakeName(file_name,'.dat','.all');
[outfile2, path_outf2] = uiputfile( DefaultFilename, ...
'Name of file of all orders');
[outf2, message] = eval(['fopen (''' path_outf2 outfile2 ''', ''w'')']);
if outf2 == -1
error(message)
end
else % Batch mode 
if (output_mode == 1) % +1 order output
appendstring = '.1';
elseif (output_mode == 2) % 0 order output (wiregrid)
appendstring = '.0';
elseif (output_mode == 3) % 0 order output (waveplate)
appendstring = '.0';
end
file_out = MakeName(file_name,'.dat',appendstring)
[outf, message] = eval(['fopen ( ''' pathname file_out ''', ''w'')']);
if outf == -1
error(message)
end
file_out2 = MakeName(file_name,'.dat','.all')
[outf2, message] = eval(['fopen ( ''' pathname file_out2 ''', ''w'')']);
if outf2 == -1
error(message)
end
end
if strcmp(lower(field_flag), 'calc_fields')
switch dif_pol
case 1 % TE
[Eyfield_out, path_outf] = ...
uiputfile( 'Eyfield.out', 'Name of Ey field output file')
[Eyfld_outf, message] = ...
eval(['fopen (''' path_outf Eyfield_out ''', ''w'')']);
if Eyfld_outf == -1
error(message)
end
[Eyfield_0_out, path_outf] = ...
uiputfile( 'Eyfield_0.out', 'Name of Ey field output file')
[Eyfld_0_outf, message] = ...
eval(['fopen (''' path_outf Eyfield_0_out ''', ''w'')']);
if Eyfld_0_outf == -1
error(message)
end
[Eyfield_1_out, path_outf] = ...
uiputfile( 'Eyfield_1.out', 'Name of Ey field output file')
[Eyfld_1_outf, message] = ...
eval(['fopen (''' path_outf Eyfield_1_out ''', ''w'')']); 
if Eyfld_1_outf == -1
error(message)
end
[Hxfield_out, path_outf] = ...
uiputfile( 'Hxfield.out', 'Name of Hx field output file')
[Hxfld_outf, message] = ...
eval(['fopen (''' path_outf Hxfield_out ''', ''w'')']);
if Hxfld_outf == -1
error(message)
end
case 2 % TM
[Hyfield_out, path_outf] = ...
uiputfile( 'Hyfield.out', 'Name of Hy field output file')
[Hyfld_outf, message] = ...
eval(['fopen (''' path_outf Hyfield_out ''', ''w'')']);
if Hyfld_outf == -1
error(message)
end
[Exfield_out, path_outf] = ...
uiputfile( 'Exfield.out', 'Name of Ex field output file')
[Exfld_outf, message] = ...
eval(['fopen (''' path_outf Exfield_out ''', ''w'')']);
if Exfld_outf == -1
error(message)
end
case 3 % Conical
[Eyfield_out, path_outf] = ...
uiputfile( 'Eyfield.out', 'Name of Ey field output file')
[Eyfld_outf, message] = ...
eval(['fopen (''' path_outf Eyfield_out ''', ''w'')']);
if Eyfld_outf == -1
error(message)
end
[Hxfield_out, path_outf] = ...
uiputfile( 'Hxfield.out', 'Name of Hx field output file')
[Hxfld_outf, message] = ...
eval(['fopen (''' path_outf Hxfield_out ''', ''w'')']);
if Hxfld_outf == -1
error(message)
end
[Hyfield_out, path_outf] = ...
uiputfile( 'Hyfield.out', 'Name of Hy field output file')
[Hyfld_outf, message] = ...
eval(['fopen (''' path_outf Hyfield_out ''', ''w'')']);
if Hyfld_outf == -1
error(message)
end
[Exfield_out, path_outf] = ...
uiputfile( 'Exfield.out', 'Name of Ex field output file')
[Exfld_outf, message] = ...
eval(['fopen (''' path_outf Exfield_out ''', ''w'')']);
if Exfld_outf == -1
error(message)
end
end % End switch on dif_pol
end % End if calc_fields
%
% Set up headers in output files
%
if (output_mode == 1)
fprintf(outf,...
'lambda\ttheta\tphi\tpsi\tgrating_period\tnum_orders\tnum_layers\t');
for ii = 1:num_layers
fprintf(outf,'thickness_%g\t',ii);
end
for ii = 1:num_layers
fprintf(outf,'grating_offset_%g\t',ii);
end
for ii = 1:num_layers
fprintf(outf,'ridge_width_%g\t',ii);
end
fprintf(outf,'DE1\tDE_R1\tDE_T1\tConsv_Energy\tOrder_of_Consv\n');
else %if (output_mode == 2) | (output_mode ==3)
fprintf(outf,'IGOR\nWAVES/D ');
fprintf(outf,'%s, %s',MakeName(file_name,'.dat','_R'),...
MakeName(file_name,'.dat','_T') );
if (output_mode == 2)
fprintf(outf,'\n');
else 
phasewavename = MakeName(file_name,'.dat','_Tp');
endIgorstring = [ 'X Unwrap 2.0, ' phasewavename ];
fprintf(outf,', %s\n',phasewavename );
end
fprintf(outf,'BEGIN\n');
end
fprintf(outf2,...
'lambda\ttheta\tphi\tpsi\tgrating_period\tnum_orders\tnum_layers\t');
for ii = 1:num_layers
fprintf(outf2,'thickness_%g\t',ii);
end
for ii = 1:num_layers
fprintf(outf2,'grating_offset_%g\t',ii);
end
for ii = 1:num_layers
fprintf(outf2,'ridge_width_%g\t',ii);
end
fprintf(outf2,'DE1\tDE_R0\tDE_T0\t');
for ix=1:min(num_orders_pos_max, num_orders_neg_max)
fprintf(outf2,'DE_R%g\tDE_T%g\tDE_R_%g\tDE_T_%g\t',...
ix,ix,ix,ix);
end
fprintf(outf2,'Consv_Energy \tOrder_of_Consv\tphase_1\tphase0\tphase1\n');
%------------------------------------------------------------------------------
%
% Start a timer
%
tic
%------------------------------------------------------------------------------
%
% Set up number of cases
% NOTE: Should execute minimum number of cases spec'd by input
%
num_cases = inf;
if ( theta_incr ~= 0)
temp = fix( ((theta_max - theta_min)/theta_incr) ) + 1;
num_cases = min(temp, num_cases); 
end
if ( phi_incr ~= 0)
temp = fix( ((phi_max - phi_min)/phi_incr) ) + 1;
num_cases = min(temp, num_cases);
end
if ( psi_incr ~= 0 )
temp = fix( ((psi_max - psi_min)/psi_incr) ) + 1;
num_cases = min(temp, num_cases);
end
if ( grating_period_incr ~= 0 )
temp = fix( ((grating_period_max - ...
grating_period_min)/grating_period_incr) ) + 1;
num_cases = min(temp, num_cases);
end
if ( lambda_incr ~= 0 )
temp = fix( ((lambda_max - lambda_min)/lambda_incr) ) + 1;
num_cases = min(temp, num_cases);
end
if ( num_orders_pos_incr ~= 0 )
temp = fix( ((num_orders_pos_max - ...
num_orders_pos_min)/num_orders_pos_incr) ) + 1;
num_cases = min(temp, num_cases);
end
if ( num_orders_neg_incr ~= 0 )
temp = fix( ((num_orders_neg_max - ...
num_orders_neg_min)/num_orders_neg_incr) ) + 1;
num_cases = min(temp, num_cases);
end
if ( inc_algor == 1 ) %linear
if (Re_index_I_c2 ~= 0)
temp = fix( ((Re_index_I_c1 - Re_index_I_c0)/Re_index_I_c2) ) + 1;
num_cases = min(temp, num_cases);
end
end
if ( exitre_algor == 1 ) %linear
if (Re_index_II_c2 ~= 0)
temp = fix( ((Re_index_II_c1 - Re_index_II_c0)/Re_index_II_c2) ) + 1;
num_cases = min(temp, num_cases);
end
end 
if ( exitim_algor == 1 ) %linear
if (Im_index_II_c2 ~= 0)
temp = fix( ((Im_index_II_c1 - Im_index_II_c0)/RIm_index_II_c2) ) + 1;
num_cases = min(temp, num_cases);
end
end
for nl = 1:num_layers
if ( thickness_incr(nl) ~= 0)
temp = fix( ( (thickness_max(nl) - ...
thickness_min(nl))/thickness_incr(nl)) ) + 1;
num_cases = min(temp, num_cases);
end
if ( grating_off_incr(nl) ~= 0)
temp = fix( ((grating_off_max(nl) - ...
grating_off_min(nl))/grating_off_incr(nl)) ) + 1;
num_cases = min(temp, num_cases);
end
if ( ridge_width_incr(nl) ~= 0 )
temp = fix( ((ridge_width_max(nl) - ...
ridge_width_min(nl))/ridge_width_incr(nl)) +.001 ) + 1;
num_cases = min(temp, num_cases);
end
if (layer_id(nl) == 1) % grating
if ( rdindexre_algor(nl) == 1 ) % linear
if (Re_index_ridge_c2(nl) ~= 0)
temp = fix( ((Re_index_ridge_c1(nl) - ...
Re_index_ridge_c0(nl))/Re_index_ridge_c2(nl)) ) + 1;
num_cases = min(temp, num_cases);
end
end
if ( rdindexim_algor(nl) == 1 ) % linear
if (Im_index_ridge_c2(nl) ~= 0)
temp = fix( ((Im_index_ridge_c1(nl) - ...
Im_index_ridge_c0(nl))/Im_index_ridge_c2(nl)) ) + 1;
num_cases = min(temp, num_cases);
end
end
if ( grindexre_algor(nl) == 1 ) % linear
if (Re_index_groove_c2(nl) ~= 0)
temp = fix( ((Re_index_groove_c1(nl) - ... 
Re_index_groove_c0(nl))/Re_index_groove_c2(nl)) ) + 1;
num_cases = min(temp, num_cases);
end
end
if ( grindexim_algor(nl) == 1 ) % linear
if (Im_index_groove_c2(nl) ~= 0)
temp = fix( ((Im_index_groove_c1(nl) - ...
Im_index_groove_c0(nl))/Im_index_groove_c2(nl)) ) + 1;
num_cases = min(temp, num_cases);
end
end
elseif (layer_id(nl) == 2) % uniform
if ( uindexre_algor(nl) == 1 ) % linear
if (Re_uniform_index_c2(nl) ~= 0)
temp = fix( ((Re_uniform_index_c1(nl) - ...
Re_uniform_index_c0(nl))/ ...
Re_uniform_index_c2(nl)) ) + 1;
num_cases = min(temp, num_cases);
end
end
if ( uindexim_algor(nl) == 1 ) % linear
if (Im_uniform_index_c2(nl) ~= 0)
temp = fix( ((Im_uniform_index_c1(nl) - ...
Im_uniform_index_c0(nl))/ ...
Im_uniform_index_c2(nl)) ) + 1;
num_cases = min(temp, num_cases);
end
end
end % Grating vs. Uniform layer
end % Cycle through layers
if ( num_cases == inf)
num_cases = 1;
end
% Outer loop for multiple cases
%
for ncase=1:1:num_cases
%------------------------------------------------------------------------------ 
%
% Constants
%
theta_0 = (theta_min+theta_incr*(ncase-1))*pi/180;
phi_0 = (phi_min+phi_incr*(ncase-1))*pi/180;
psi_0 = (psi_min+psi_incr*(ncase-1))*pi/180;
grating_period = (grating_period_min + grating_period_incr*(ncase-1));
lambda_0 = (lambda_min + lambda_incr*(ncase-1));
num_orders_pos = (num_orders_pos_min + num_orders_pos_incr*(ncase-1));
num_orders_neg = (num_orders_neg_min + num_orders_neg_incr*(ncase-1));
if (inc_algor == 1) % linear
Re_index_I = (Re_index_I_c0 + Re_index_I_c2*(ncase-1));
elseif (inc_algor == 2) % quadratic
Re_index_I = Re_index_I_c0 + Re_index_I_c1*lambda_0 + ...
Re_index_I_c2*lambda_0*lambda_0;
end
if (exitre_algor == 1) % linear
Re_index_II = (Re_index_II_c0 + Re_index_II_c2*(ncase-1));
elseif (exitre_algor == 2) % quadratic
Re_index_II = Re_index_II_c0 + Re_index_II_c1*lambda_0 + ...
Re_index_II_c2*lambda_0*lambda_0;
end
if (exitim_algor == 1) % linear
Im_index_II = (Im_index_II_c0 + Im_index_II_c2*(ncase-1));
elseif (exitre_algor == 2) % quadratic
Im_index_II = Im_index_II_c0 + Im_index_II_c1*lambda_0 + ...
Im_index_II_c2*lambda_0*lambda_0;
end
index_I = Re_index_I;
index_II = Re_index_II + i*Im_index_II;
n = -num_orders_neg:num_orders_pos;
num_orders = num_orders_neg + num_orders_pos + 1;
two_n = -num_orders:num_orders;
k0 = 2*pi/lambda_0;
mu_0 = (4*pi)*1e-7;
epsilon_0 = 8.85e-12;
Zee0 = sqrt(mu_0/epsilon_0);
I = eye(num_orders);
zero = zeros(num_orders); 
for nl = 1:num_layers
thickness(nl) = thickness_min(nl) + thickness_incr(nl)*(ncase-1);
grating_offset(nl) = grating_off_min(nl) + grating_off_incr(nl)*(ncase-1);
ridge_width(nl) = ridge_width_min(nl) + ridge_width_incr(nl)*(ncase-1);
if (layer_id(nl) == 1) % grating
if (rdindexre_algor(nl) == 1) % linear
Re_index_ridge = (Re_index_ridge_c0(nl) + ...
Re_index_ridge_c2(nl)*(ncase-1));
elseif (rdindexre_algor(nl) == 2) % quadratic
Re_index_ridge = Re_index_ridge_c0(nl) + ...
Re_index_ridge_c1(nl)*lambda_0 + ...
Re_index_ridge_c2(nl)*lambda_0*lambda_0;
end
if (rdindexim_algor(nl) == 1) % linear
Im_index_ridge = (Im_index_ridge_c0(nl) + ...
Im_index_ridge_c2(nl)*(ncase-1));
elseif (rdindexim_algor(nl) == 2) % quadratic
Im_index_ridge = Im_index_ridge_c0(nl) + ...
Im_index_ridge_c1(nl)*lambda_0 + ...
Im_index_ridge_c2(nl)*lambda_0*lambda_0;
end
if (grindexre_algor(nl) == 1) % linear
Re_index_groove = (Re_index_groove_c0(nl) + ...
Re_index_groove_c2(nl)*(ncase-1));
elseif (grindexre_algor(nl) == 2) % quadratic
Re_index_groove = Re_index_groove_c0(nl) + ...
Re_index_groove_c1(nl)*lambda_0 + ...
Re_index_groove_c2(nl)*lambda_0*lambda_0;
end
if (grindexim_algor(nl) == 1) % linear
Im_index_groove = (Im_index_groove_c0(nl) + ...
Im_index_groove_c2(nl)*(ncase-1));
elseif (grindexim_algor(nl) == 2) % quadratic
Im_index_groove = Im_index_groove_c0(nl) + ...
Im_index_groove_c1(nl)*lambda_0 + ...
Im_index_groove_c2(nl)*lambda_0*lambda_0;
end
index_ridge(nl) = Re_index_ridge + i*Im_index_ridge;
index_groove(nl) = Re_index_groove + i*Im_index_groove; 
elseif (layer_id(nl) == 2) % uniform
if (uindexre_algor(nl) == 1) % linear
Re_uniform_index = (Re_uniform_index_c0(nl) + ...
Re_uniform_index_c2(nl)*(ncase-1));
elseif (uindexre_algor(nl) == 2) % quadratic
Re_uniform_index = Re_uniform_index_c0(nl) + ...
Re_uniform_index_c1(nl)*lambda_0 + ...
Re_uniform_index_c2(nl)*lambda_0*lambda_0;
end
if (uindexim_algor(nl) == 1) % linear
Im_uniform_index = (Im_uniform_index_c0(nl) + ...
Im_uniform_index_c2(nl)*(ncase-1));
elseif (rdindexim_algor(nl) == 2) % quadratic
Im_uniform_index = Im_uniform_index_c0(nl) + ...
Im_uniform_index_c1(nl)*lambda_0 + ...
Im_uniform_index_c2(nl)*lambda_0*lambda_0;
end
uniform_index(nl) = Re_uniform_index + i*Im_uniform_index;
end % Grating vs. Uniform layer
end
if (ncase == 1 | num_orders_pos_incr ~= 0 | num_orders_neg_incr ~=0)
fou_harmonics = zeros(1,2*num_orders);
rec_fou_harmonics = zeros(1,2*num_orders+1);
E = zeros(num_orders,num_orders,num_gratings);
rec_E = zeros(num_orders,num_orders,num_gratings);
W = zeros(num_orders,num_orders,num_gratings);
Q2 = zeros(num_orders,num_orders,num_gratings);
Q = zeros(num_orders,num_orders,num_gratings);
V = zeros(num_orders,num_orders,num_gratings);
Gamma_arg = zeros(1,num_orders);
Gamma = zeros(num_orders,num_orders,num_uniform);
E_vec = zeros(num_layers);
E_val = zeros(num_layers);
E_prod = zeros(num_layers);
if (dif_pol == 3) % Conical
ai_X = zeros(2*num_orders,2*num_orders,num_layers);
b_ai_X = zeros(2*num_orders,2*num_orders,num_layers);
EbainvE = zeros(2*num_orders,2*num_orders,num_layers);
convert_T = zeros(2*num_orders,2*num_orders,num_layers); 
else % TE or TM
ai_X = zeros(num_orders,num_orders,num_layers);
b_ai_X = zeros(num_orders,num_orders,num_layers);
EbainvE = zeros(num_orders,num_orders,num_layers);
convert_T = zeros(num_orders,num_orders,num_layers);
end
end
%------------------------------------------------------------------------------
%
% Variable initialization
%
num_integ_pts = 1000; % provides sufficient accuracy
integ_spacing = grating_period/num_integ_pts;
%------------------------------------------------------------------------------
%
% Arrays - allocate memory
%
phi_i = zeros(1,num_orders);
X = zeros(num_orders);
G = zeros(num_orders);
ainv = zeros(num_orders);
exp_func = zeros(num_orders);
%------------------------------------------------------------------------------
% Calculate fourier harmonics by integration
for nl=1:num_layers
if ( layer_id(nl) == 1 ) % A grating layer
if (grating_period_incr ~= 0 |...
grating_off_incr(nl) ~= 0 | ridge_width_incr(nl) ~= 0 |...
num_orders_pos_incr ~= 0 | num_orders_neg_incr ~=0 | ...
Re_index_ridge_c2(nl) ~= 0 | Im_index_ridge_c2(nl) ~= 0 | ...
Re_index_groove_c2(nl) ~= 0 | Im_index_groove_c2(nl) ~= 0 | ...
ncase == 1)
while ( grating_offset(nl) > grating_period) 
grating_offset(nl) = grating_offset(nl) - grating_period;
end
groove_width = grating_period - ridge_width(nl);
if (grating_offset(nl) > groove_width)
y1_index = index_ridge(nl);
x1 = 0:integ_spacing:(grating_offset(nl) - groove_width);
y2_index = index_groove(nl);
x2 = (grating_offset(nl) - ...
groove_width):integ_spacing:grating_offset(nl);
y3_index = index_ridge(nl);
x3 = grating_offset(nl):integ_spacing:grating_period;
else
y1_index = index_groove(nl);
x1 = 0:integ_spacing:grating_offset(nl);
y2_index = index_ridge(nl);
x2 = grating_offset(nl):integ_spacing:(grating_offset(nl) + ...
ridge_width(nl));
y3_index = index_groove(nl);
x3 = (grating_offset(nl) + ...
ridge_width(nl)):integ_spacing:grating_period;
end
for ii = 1:2*num_orders
y1 = (y1_index^2)*...
exp(-j*(ii-(num_orders+1))*(2*pi/grating_period)*x1);
y2 = (y2_index^2)*...
exp(-j*(ii-(num_orders+1))*(2*pi/grating_period)*x2);
y3 = (y3_index^2)*...
exp(-j*(ii-(num_orders+1))*(2*pi/grating_period)*x3);
if (length(x1) > 1)
section1 = trapz(x1,y1);
else
section1 = 0;
end
if (length(x2) > 1)
section2 = trapz(x2,y2);
else
section2 = 0; 
end
if (length(x3) > 1)
section3 = trapz(x3,y3);
else
section3 = 0;
end
fou_harmonics(ii) = ...
(1/grating_period)*(section1 + section2 + section3);
end
for ii = 1:num_orders
E(ii,:,Emat_offset(nl)) = ...
fou_harmonics( ii - (1:num_orders) + (num_orders+1) );
end
if (dif_pol ~= 1) % True for TM or Conical
% Calculate reciprocal fourier harmonics by integration
%
for ii = 1:2*num_orders
y1 = (1/y1_index^2)*...
exp(-j*(ii-(num_orders+1))*(2*pi/grating_period)*x1);
y2 = (1/y2_index^2)*...
exp(-j*(ii-(num_orders+1))*(2*pi/grating_period)*x2);
y3 = (1/y3_index^2)*...
exp(-j*(ii-(num_orders+1))*(2*pi/grating_period)*x3);
if (length(x1) > 1)
section1 = trapz(x1,y1);
else
section1 = 0;
end
if (length(x2) > 1)
section2 = trapz(x2,y2);
else
section2 = 0;
end
if (length(x3) > 1)
section3 = trapz(x3,y3);
else
section3 = 0;
end 
rec_fou_harmonics(ii) = ...
(1/grating_period)*(section1+section2+section3);
end
for ii = 1:num_orders
rec_E(ii,:,Emat_offset(nl)) = ...
rec_fou_harmonics( ii - (1:num_orders) + (num_orders+1) );
end
end % End loop for not TE (TM or Conical)
end % End loop for increment or first case
end % End loop for layer type
end % End loop for num_layers
kx = zeros (1, num_orders);
ky = zeros (1, num_orders);
kIz = zeros (1, num_orders);
kIIz = zeros (1, num_orders);
fou_harmonics = zeros(1,2*num_orders);
exp_func = zeros(num_orders);
if (dif_pol == 3) % Conical
convert_T = [ I zero; zero I];
incident = zeros(1,4*num_orders);
else
convert_T = I; % TE/TM
incident = zeros(1,2*num_orders);
end
%------------------------------------------------------------------------------
%
% System Calculations
%
% Set up matrix Kx2 - diagonal matrix of wavenumber, including Floquet condition
kx = k0*(index_I*sin(theta_0)*cos(phi_0) - n*(lambda_0/grating_period));
kx2 = kx.^2;
kx_k0 = kx/k0;
kx_k0_2 = kx_k0.^2;
Kx = diag(kx_k0);
Kx2 = diag(kx_k0_2); 
ky = k0*index_I*sin(theta_0)*sin(phi_0);
ky_k0 = ky/k0;
ky2 = ky^2;
ky_k0_2 = ky_k0^2;
ky2I = ky2*I;
index_I_2 = index_I^2;
index_II_2 = index_II^2;
if (ky == 0)
phi_i = zeros(1,num_orders);
else
phi_i = atan(ky./kx);
end
Fc = diag(cos(phi_i));
Fs = diag(sin(phi_i));
% Set up matrices Y - diagonal with elements (k/k0)
%
for ino = 1:num_orders
if (sqrt(kx2(ino) + ky2) < k0*index_I )
kIz(ino) = sqrt( (k0*index_I)^2 - kx2(ino) - ky2 );
else
kIz(ino) = -j*sqrt( (kx2(ino) + ky2) - (k0*index_I)^2 );
end
end
for ino = 1:num_orders
if (sqrt(kx2(ino) + ky2) < k0*index_II )
kIIz(ino) = sqrt( (k0*index_II)^2 - kx2(ino) - ky2 );
else
kIIz(ino) = -j*sqrt( (kx2(ino) + ky2) - (k0*index_II)^2 );
end
end
% kIz = conj(k0*sqrt(index_I_2 - kx_k0_2 - ky_k0_2));
% kIIz = conj(k0*sqrt(index_II_2 - kx_k0_2 - ky_k0_2));
kIz_k0 = kIz/k0;
kIIz_k0 = kIIz/k0;

YI = diag(kIz_k0);
YII = diag(kIIz_k0);
ZI = diag(kIz_k0/index_I_2);
ZII = diag(kIIz_k0/index_II_2);
if (dif_pol == 1) % TE
incident(num_orders_neg+1) = 1;
incident(num_orders + num_orders_neg + 1) = j*index_I*cos(theta_0);
f_g = [ I; j*YII ];
elseif (dif_pol == 2) % TM
incident(num_orders_neg+1) = 1;
incident(num_orders + num_orders_neg + 1) = j*cos(theta_0)/index_I;
f_g = [ I; j*ZII ];
else % Conical
incident(num_orders_neg+1) = sin(psi_0);
incident(num_orders + num_orders_neg + 1) = ...
j*index_I*sin(psi_0)*cos(theta_0);
incident(2*num_orders + num_orders_neg + 1) = -j*index_I*cos(psi_0);
incident(3*num_orders + num_orders_neg + 1) = cos(psi_0)*cos(theta_0);
f_g = [ I zero; j*YII zero; zero I; zero j*ZII];
end
%------------------------------------------------------------------------------
%------------------------------------------------------------------------------
%
% Loop for layer calculations
%
for nl = num_layers:-1:1
if ( layer_id(nl) == 1 ) % A grating layer
%------------------------------------------------------------------------------
%
% Grating Calculations
% Calculate the matrices W, Q and V
%
% W1 is eigenvector matrix of [ky^2*I + (Kx2-E)]
% Q1 is diagonal matrix, positive square roots of eigenvalues of Kx2-E
% 
if (dif_pol == 1) % TE
A = Kx2 - E(:,:,Emat_offset(nl));
[W(:,:,nl),Q2] = eig(A);
Q(:,:,nl) = sqrt(Q2);
V(:,:,nl)=W(:,:,nl)*Q(:,:,nl);
E_vec = W(:,:,nl);
E_val = Q(:,:,nl);
E_prod = V(:,:,nl);
temp = [E_vec E_vec;E_prod -E_prod];
exp_func = diag(exp(-k0*diag(E_val)*thickness(nl)));
elseif (dif_pol == 2) % TM
recEinv = inv(rec_E(:,:,Emat_offset(nl)));
Einv = inv(E(:,:,Emat_offset(nl)));
EB = recEinv*(Kx*Einv*Kx-I);
[W(:,:,nl),Q2] = eig(EB);
Q(:,:,nl) = sqrt(Q2);
V(:,:,nl)=rec_E(:,:,Emat_offset(nl))*W(:,:,nl)*Q(:,:,nl);
E_vec = W(:,:,nl);
E_val = Q(:,:,nl);
E_prod = V(:,:,nl);
temp = [E_vec E_vec;E_prod -E_prod];
exp_func = diag(exp(-k0*diag(E_val)*thickness(nl)));
else % Conical
A = Kx2 - E(:,:,Emat_offset(nl));
temp = ky2I + A;
[W1(:,:,nl),Q12] = eig(temp);
Q1(:,:,nl) = sqrt(Q12);
Einv = inv(E(:,:,Emat_offset(nl)));
recEinv = inv(rec_E(:,:,Emat_offset(nl)));
B = (Kx*Einv*Kx-I);
temp = ky2I + B*E(:,:,Emat_offset(nl));
[W2(:,:,nl),Q22] = eig(temp);
Q2(:,:,nl) = sqrt(Q22);
Ainv = inv(A);
Binv = inv(B);
V11(:,:,nl) = Ainv*W1(:,:,nl)*Q1(:,:,nl);
V12(:,:,nl) = (ky_k0)*Ainv*Kx*W2(:,:,nl);
V21(:,:,nl) = (ky_k0)*Binv*Kx*Einv*W1(:,:,nl);
V22(:,:,nl) = Binv*W2(:,:,nl)*Q2(:,:,nl);
Vss(:,:,nl) = Fc*V11(:,:,nl);
Wss(:,:,nl) = Fc*W1(:,:,nl) + Fs*V21(:,:,nl);
Vsp(:,:,nl) = Fc*V12(:,:,nl) - Fs*W2(:,:,nl);
Wsp(:,:,nl) = Fs*V22(:,:,nl);
Wpp(:,:,nl) = Fc*V22(:,:,nl);
Vpp(:,:,nl) = Fc*W2(:,:,nl) + Fs*V12(:,:,nl);
Wps(:,:,nl) = Fc*V21(:,:,nl) - Fs*W1(:,:,nl);
Vps(:,:,nl) = Fs*V11(:,:,nl);
X1 = diag(exp(-k0*diag(Q1(:,:,nl))*thickness(nl)));
X2 = diag(exp(-k0*diag(Q2(:,:,nl))*thickness(nl)));
X = [X1 zero; zero X2];
exp_func =X;
temp = [Vss(:,:,nl) Vsp(:,:,nl) Vss(:,:,nl) Vsp(:,:,nl);...
Wss(:,:,nl) Wsp(:,:,nl) -Wss(:,:,nl) -Wsp(:,:,nl);...
Wps(:,:,nl) Wpp(:,:,nl) -Wps(:,:,nl) -Wpp(:,:,nl);...
Vps(:,:,nl) Vpp(:,:,nl) Vps(:,:,nl) Vpp(:,:,nl)];
end % Polarization dependence for a grating layer
else % A uniform layer
%------------------------------------------------------------------------------
%
% Uniform Calculations
if (dif_pol == 1) % TE
n_2 = uniform_index(nl)^2;
for ino = 1:num_orders
if (sqrt(kx_k0_2(ino) + ky_k0_2) < uniform_index(nl) )
Gamma_arg(ino) = sqrt( n_2 - kx_k0_2(ino) - ky_k0_2 );
else
Gamma_arg(ino) = -j*sqrt( (kx_k0_2(ino) + ky_k0_2) - n_2 ); 
end
end
Gamma(:,:,Gmat_offset(nl)) = diag(j*Gamma_arg);
E_vec =I;
E_val = Gamma(:,:,Gmat_offset(nl));
E_prod = Gamma(:,:,Gmat_offset(nl));
temp = [E_vec E_vec;E_prod -E_prod];
exp_func = diag(exp(-k0*diag(E_val)*thickness(nl)));
elseif (dif_pol == 2)
n_2 = uniform_index(nl)^2;
for ino = 1:num_orders
if (sqrt(kx_k0_2(ino) + ky_k0_2) < uniform_index(nl) )
Gamma_arg(ino) = sqrt( n_2 - kx_k0_2(ino) - ky_k0_2 );
else
Gamma_arg(ino) = -j*sqrt( (kx_k0_2(ino) + ky_k0_2) - n_2 );
end
end
Gamma(:,:,Gmat_offset(nl)) = diag(j*Gamma_arg);
E_vec =I; % TM
E_val = Gamma(:,:,Gmat_offset(nl));
E_prod = Gamma(:,:,Gmat_offset(nl))/(uniform_index(nl)^2);
temp = [E_vec E_vec;E_prod -E_prod];
exp_func = diag(exp(-k0*diag(E_val)*thickness(nl)));
else % Conical
n_2 = uniform_index(nl)^2;
for ino = 1:num_orders
if (sqrt(kx_k0_2(ino) + ky_k0_2) < uniform_index(nl) )
Gamma_arg(ino) = sqrt( n_2 - kx_k0_2(ino) - ky_k0_2 );
else
Gamma_arg(ino) = -j*sqrt( (kx_k0_2(ino) + ky_k0_2) - n_2 );
end
end
Gamma(:,:,Gmat_offset(nl)) = diag(j*Gamma_arg);
G = diag(exp(-k0*diag(Gamma(:,:,Gmat_offset(nl)))*thickness(nl)));
exp_func = [G zero; zero G]; 
Fsg(:,:,Gmat_offset(nl)) = Fs*Gamma(:,:,Gmat_offset(nl));
Fsgn(:,:,Gmat_offset(nl)) = Fsg(:,:,Gmat_offset(nl))/n_2;
Fcg(:,:,Gmat_offset(nl)) = Fc*Gamma(:,:,Gmat_offset(nl));
Fcgn(:,:,Gmat_offset(nl)) = Fcg(:,:,Gmat_offset(nl))/n_2;
temp = ...
[Fc Fsgn(:,:,Gmat_offset(nl)) Fc -Fsgn(:,:,Gmat_offset(nl));...
Fcg(:,:,Gmat_offset(nl)) -Fs -Fcg(:,:,Gmat_offset(nl)) -Fs;...
-Fsg(:,:,Gmat_offset(nl)) -Fc Fsg(:,:,Gmat_offset(nl)) -Fc;...
Fs -Fcgn(:,:,Gmat_offset(nl)) Fs Fcgn(:,:,Gmat_offset(nl))];
end % Polarization dependence for uniform layer
end % Grating vs. Uniform layer
% Solve the system of equations to get reflection and transmission
% coefficients
%
% Combine the reflectance and transmission equations through c+ and c-,
% apply techniques from enhanced transmittance approach,
% rearrange so the system can be solved using LU or QR methods.
[tU,tS,tV] = svd(temp);
t_inv = tV*inv(tS)*tU';
a_b = t_inv*f_g;
if (dif_pol == 3) % Conical
a = a_b( 1:2*num_orders , : );
b = a_b( 2*num_orders+1:size(a_b) , : );
else % TE/TM
a = a_b( 1:num_orders , : );
b = a_b( num_orders+1:size(a_b) , : );
end
[aU,aS,aV] = svd(a);
ainv = aV*inv(aS)*aU';
ai_X(:,:,nl) = ainv*exp_func;
b_ai_X(:,:,nl) = b*ai_X(:,:,nl);
EbainvE = exp_func*b_ai_X(:,:,nl);

if (dif_pol == 3) % Conical
f_g = temp*[I zero; zero I; EbainvE];
else % TE/TM
f_g = [E_vec*(I + EbainvE) ; E_prod*(I - EbainvE)];
end
% Accumulate conversion back to T so don't have to save values for each layer
convert_T = convert_T*ai_X(:,:,nl); % Loop runs backwards -> +1
end %---End loop for layer calculations
% Calculate Reflection/Transmission coefficients
%
if (dif_pol == 1) % TE
transfer = [ -1*I E_vec*(I + EbainvE) ; j*YI E_prod*(I - EbainvE) ];
R_T1 = transfer\incident.';
R = R_T1( 1:num_orders );
T1 = R_T1( num_orders+1:size(R_T1) );
T = convert_T*T1;
% Calculate Diffraction Efficiencies
%
DE_R = real((R.*conj(R).*real(kIz_k0/(index_I*cos(theta_0)))')');
DE_T = real((T.*conj(T).*real(kIIz_k0/(index_I*cos(theta_0)))')');
elseif (dif_pol == 2) % TM
transfer = [ -1*I E_vec*(I + EbainvE) ; j*ZI E_prod*(I - EbainvE) ];
R_T1 = transfer\incident.';
R = R_T1( 1:num_orders );
T1 = R_T1( num_orders+1:size(R_T1) );
T = convert_T*T1;
% Calculate Diffraction Efficiencies
%
DE_R = (R.*conj(R).*real(kIz_k0/(index_I*cos(theta_0)))')';
DE_T = (T.*conj(T).*(real(kIIz_k0/index_II_2))'/(cos(theta_0)/index_I))';

else % Conical
transfer = [ -I zero; j*YI zero; zero -I; zero j*ZI];
transfer( : , 2*num_orders+1:4*num_orders) = f_g;
R_TL = transfer\incident.';
Rs = R_TL( 1:num_orders );
Rp = R_TL( num_orders+1:2*num_orders );
T1 = R_TL( 2*num_orders+1:size(R_TL) );
T = convert_T*T1;
Ts = T(1:num_orders);
Tp = T(num_orders+1:size(T));
% Calculate Diffraction Efficiencies
%
if (theta_0 == 90.*pi/180.)
DE_R = zeros(1,num_orders);
DE_R(num_orders_neg+1) = 1;
DE_R
DE_T = zeros(1,num_orders)
disp('This is a canned answer')
else
nIcos = index_I*cos(theta_0);
DE_R = (Rs.*conj(Rs).*real(kIz_k0/nIcos)')' + ...
(Rp.*conj(Rp).*real((kIz_k0/index_I_2)/nIcos)')';
DE_T = (Ts.*conj(Ts).*real(kIIz_k0/nIcos)')' + ...
(Tp.*conj(Tp).*real((kIIz_k0/index_II_2)/nIcos)')';
end
end % Polarization dependence for R/T coefficients and DE
DE1 = DE_R(num_orders_neg+2) + DE_T(num_orders_neg+2);
Consv_Energy = sum(DE_R') + sum(DE_T');
Order_of_Consv = Consv_Energy - 1
%------------------------------------------------------------------------------
%
% Write output file
%
% Write selected output to the first file 
if (output_mode == 1) % +1 order output
fprintf(outf,'%g\t', lambda_0, theta_0*180/pi, phi_0*180/pi, ...
psi_0*180/pi, grating_period, ...
num_orders, num_layers, thickness, grating_offset, ...
ridge_width, DE1, DE_R(num_orders_neg+2), ...
DE_T(num_orders_neg+2), Consv_Energy, Order_of_Consv);
elseif (output_mode == 2) % 0 order output (wiregrid)
fprintf(outf,'%15e\t', DE_R(num_orders_neg+1),DE_T(num_orders_neg+1));
elseif (output_mode == 3) % 0 order output (waveplate)
fprintf(outf,'%15e\t', DE_R(num_orders_neg+1),DE_T(num_orders_neg+1), ...
angle(T(num_orders_neg+1))/pi );
end %
fprintf(outf,'\n');
% Second file contains all orders up to where +/- are symmetric
fprintf(outf2,'%g\t', lambda_0, theta_0*180/pi, phi_0*180/pi, ...
psi_0*180/pi, grating_period, ...
num_orders, num_layers, thickness, grating_offset, ...
ridge_width, DE1, DE_R(num_orders_neg+1), ...
DE_T(num_orders_neg+1));
for ix=1:min(num_orders_pos, num_orders_neg)
fprintf(outf2,'%g\t%g\t%g\t%g\t', DE_R((num_orders_neg+1)+ix), ...
DE_T((num_orders_neg+1)+ix),...
DE_R((num_orders_neg+1)-ix), ...
DE_T((num_orders_neg+1)-ix));
end
fprintf(outf2,'%g\t%g\t%g\t%g\t%g\n', Consv_Energy, Order_of_Consv,...
angle(T(num_orders_neg))/pi,...
angle(T(num_orders_neg+1))/pi,...
angle(T(num_orders_neg+2))/pi);
end % End - Number of cases (incidence angles) to run
if (run_mode == 1) % GUI mode
another_case = 0;
else % batch mode
if (feof(inf_list))
another_case = 0;
else
if (output_mode == 2)
fprintf(outf,'END\n '); 
elseif (output_mode == 3)
fprintf(outf,'END\n ');
% fprintf(outf,'END\n%s\n ',endIgorstring);
end
fclose(outf);
fclose(outf2);
toc
file_name = fscanf(inf_list, '%s\n',1);
Read_input_file(pathname, file_name)
if (output_mode == 1) % +1 order output
appendstring = '.1';
elseif (output_mode == 2) % 0 order output (wiregrid)
appendstring = '.0';
elseif (output_mode == 3) % 0 order output (waveplate)
appendstring = '.0';
end
file_out = MakeName(file_name,'.dat',appendstring);
[outf, message] = eval(['fopen ( ''' pathname file_out ''', ''w'')']);
if outf == -1
error(message)
end
file_out2 = MakeName(file_name,'.dat','.all');
[outf2, message] = eval(['fopen ( ''' pathname file_out2 ''', ''w'')']);
if outf2 == -1
error(message)
end
another_case = 1;
end % feof on list file
end % GUI vs. batch mode
end % End - Check on another_case
%------------------------------------------------------------------------------
%
% Close files
%
if (output_mode == 2)
fprintf(outf,'END\n '); 
elseif (output_mode == 3)
fprintf(outf,'END\n ');
% fprintf(outf,'END\n%s\n ',endIgorstring);
end
fclose(outf);
fclose(outf2);
if (run_mode == 2) % Batch mode
fclose(inf_list);
end
%------------------------------------------------------------------------------
%
% Field Calculations
%
if strcmp(lower(field_flag), 'calc_fields')
% Calculate constants
z_min = -1*dist_before;
x_min = 0;
x_max = dist_along;
y_min = 0;
y_max = dist_parallel;
cpsi = cos(psi_0);
spsi = sin(psi_0);
cphi = cos(phi_0);
sphi = sin(phi_0);
ctheta = cos(theta_0);
stheta = sin(theta_0);
ord_0 = num_orders_neg+1;
ord_1 = num_orders_neg+2;
% Calculate fields in incident region
zI = z_min:z_resolution:0;
x = x_min:x_resolution:x_max; % Generate x pts
z_out = zI; % Array for file output

switch dif_pol
case 1 % TE
% Preallocate arrays for fields
Ey_I_field = zeros(length(x),length(zI));
Ey_0_I_field = zeros(length(x),length(zI));
Ey_1_I_field = zeros(length(x),length(zI));
Hx_I_field = zeros(length(x),length(zI));
[xl,zl] = meshgrid(x,zI);
% Calculate each field point
for zl =1:1:length(zI)
for xl = 1:1:length(x)
Ey_I_field(xl,zl) = exp(-i*k0*index_I*(x(xl)*stheta + ...
zI(zl)*ctheta)) ...
+ R'*exp(-j*(kx*x(xl) - kIz*zI(zl)))';
Ey_0_I_field(xl,zl) = exp(-i*k0*index_I*(x(xl)*stheta + ...
zI(zl)*ctheta)) + ...
R(ord_0)*exp(-j*(kx(ord_0)*x(xl) - ...
kIz(ord_0)*zI(zl)));
Ey_1_I_field(xl,zl) = R(ord_1)*exp(-j*(kx(ord_1)*x(xl) - ...
kIz(ord_1)*zI(zl)));
Hx_I_field(xl,zl) = (1/(k0*Zee0))*(k0*index_I*ctheta.*...
exp(-i*k0*index_I*(x(xl)*stheta + ...
zI(zl)*ctheta)) ...
+ (-1*kIz).*R'*exp(-i*(kx*x(xl) - ...
kIz*zI(zl)))');
end % x loop
end % z loop
% Store in matrix for complete field description
Ey_field = Ey_I_field(1:length(x), 1:length(zI));
Ey_0_field = Ey_0_I_field(1:length(x), 1:length(zI));
Ey_1_field = Ey_1_I_field(1:length(x), 1:length(zI));
Hx_field = Hx_I_field(1:length(x), 1:length(zI));
case 2 % TM
% Preallocate arrays for fields
Hy_I_field = zeros(length(x),length(zI));
Ex_I_field = zeros(length(x),length(zI));
% Calculate each field point
for zl = 1:1:length(zI)
for xl = 1:1:length(x)
Hy_I_field(xl,zl) = exp(-i*k0*index_I*(x(xl)*stheta + ... 
zI(zl)*ctheta)) ...
+ R'*exp(-j*(kx*x(xl) - kIz*zI(zl)))';
Ex_I_field(xl,zl) = (Zee0/k0/index_I_2)*...
(-1*k0*index_I*ctheta.*...
exp(-i*k0*index_I*(x(xl)*stheta + ...
zI(zl)*ctheta)) ...
+ kIz.*R'*exp(-i*(kx*x(xl) - ...
kIz*zI(zl)))');
end % x loop
end % z loop
% Store in matrix for complete field description
Hy_field = Hy_I_field(1:length(x), 1:length(zI));
Ex_field = Ex_I_field(1:length(x), 1:length(zI));
case 3 % Conical
% Preallocate arrays for fields
Ey_I_field = zeros(length(x),length(zI));
Hx_I_field = zeros(length(x),length(zI));
Hy_I_field = zeros(length(x),length(zI));
Ex_I_field = zeros(length(x),length(zI));
% Calculate each field point
for zl = 1:1:length(zI)
for xl = 1:1:length(x)
y = 0;
ux = cpsi*ctheta*cphi - spsi*sphi;
uy = cpsi*ctheta*sphi + spsi*cphi;
Rx = Rp.*ctheta*cphi + Rs.*sphi;
Ry = Rp.*(ctheta*sphi) + Rs.*cphi;
Ey_I_field(xl,zl) = ...
uy.*exp(-i*k0*index_I*(x(xl)*stheta*cphi + ...
y*stheta*sphi + ...
zI(zl)*ctheta)) + ...
Ry'*exp(-i*(kx*x(xl) + ky*y - kIz*zI(zl)))';
Hx_I_field(xl,zl) = ...
(1/(k0*Zee0)).*(uy*k0*index_I*ctheta.*...
exp(-i*k0*index_I*(x(xl)*stheta*cphi + ...
y*stheta*sphi + zI(zl)*ctheta)) ...
+ (-1*kIz.*Ry'*exp(-i*(kx*x(xl) + ky*y - ...
kIz*zI(zl)))'));
Hy_I_field(xl,zl) = ...
(-1/(k0*Zee0)).*(ux*k0*index_I*ctheta.*... 
exp(-i*k0*index_I*(x(xl)*stheta*cphi + ...
y*stheta*sphi + zI(zl)*ctheta)) ...
+ kIz.*Rx'*exp(-i*(kx*x(xl) + ky*y - ...
kIz*zI(zl)))');
Ex_I_field(xl,zl) = ...
ux.*exp(-i*k0*index_I*(x(xl)*stheta*cphi + ...
y*stheta*sphi + ...
zI(zl)*ctheta)) + ...
Rx'*exp(-i*(kx*x(xl) + ky*y - kIz*zI(zl)))';
end % x loop
end % z loop
% Store in matrix for complete field description
Ey_field = Ey_I_field(1:length(x), 1:length(zI));
Hx_field = Hx_I_field(1:length(x), 1:length(zI));
Hy_field = Hy_I_field(1:length(x), 1:length(zI));
Ex_field = Ex_I_field(1:length(x), 1:length(zI));
end % Polarization switch for incident region
D_lm1 = 0;
Tconv = T1;
for nl = 1:1:num_layers
D_l = D_lm1 + thickness(nl);
z = (D_lm1+z_resolution):z_resolution:D_l; % Generate z pts
zmDlm1 = z - D_lm1;
zmDl = z - D_l;
start = length(z_out)+1;
z_out(start:(start+length(z)-1)) = z; % Array for file output
% Preallocate arrays for fields
switch dif_pol
case 1 % TE
Ey_layer = zeros(length(x),length(z));
Ey_0_layer = zeros(length(x),length(z));
Ey_1_layer = zeros(length(x),length(z));
Hx_layer = zeros(length(x),length(z));
case 2 % TM
Hy_layer = zeros(length(x),length(z));
Ex_layer = zeros(length(x),length(z));
case 3 % Conical 
Ey_layer = zeros(length(x),length(z));
Hx_layer = zeros(length(x),length(z));
Hy_layer = zeros(length(x),length(z));
Ex_layer = zeros(length(x),length(z));
end
if ( layer_id(nl) == 1 ) % A grating layer
if (dif_pol ~= 3) % TE/TM
c_p_m = [ I ; b_ai_X(:,:,nl)] * Tconv;
c_plus = c_p_m(1:num_orders , : );
c_minus = c_p_m(num_orders+1:size(c_p_m) , : );
else % Conical
c_p_m = [ I zero; zero I; b_ai_X(:,:,nl)] * Tconv;
c1_plus = c_p_m(1:num_orders , : );
c2_plus = c_p_m(num_orders+1:2*num_orders , : );
c1_minus = c_p_m(2*num_orders+1:3*num_orders , : );
c2_minus = c_p_m(3*num_orders+1:size(c_p_m) , : );
end
switch dif_pol
case 1 % TE
for zl = 1:1:length(z)
cplus_exp = c_plus.*exp(-k0*diag(Q(:,:,nl))*zmDlm1(zl));
cminus_exp = c_minus.*exp(k0*diag(Q(:,:,nl))*zmDl(zl));
S_harmonic = W(:,:,nl)*(cplus_exp + cminus_exp);
U_harmonic = V(:,:,nl)*(-cplus_exp + cminus_exp);
for xl = 1:1:length(x)
xexp = exp(-i*kx*x(xl));
Ey_layer(xl,zl) = S_harmonic' * xexp';
Ey_0_layer(xl,zl) = S_harmonic(ord_0) * xexp(ord_0);
Ey_1_layer(xl,zl) = S_harmonic(ord_1) * xexp(ord_1);
Hx_layer(xl,zl) = (-i/Zee0)*U_harmonic' * xexp';
end % x loop
% Temporary output of fields
if (zl == 1)
disp( ' Beginning of layer');nl
Ey_m2 = S_harmonic(ord_0-2) * xexp(ord_0-2)
Ey_m1 = S_harmonic(ord_0-1) * xexp(ord_0-1)
Ey_0 = S_harmonic(ord_0) * xexp(ord_0)
Ey_p1 = S_harmonic(ord_0+1) * xexp(ord_0+1) 
Ey_p2 = S_harmonic(ord_0+2) * xexp(ord_0+2)
end
end % z loop
case 2 % TM
for zl = 1:1:length(z)
cplus_exp = c_plus.*exp(-k0*diag(Q(:,:,nl))*zmDlm1(zl));
cminus_exp = c_minus.*exp(k0*diag(Q(:,:,nl))*zmDl(zl));
S_harmonic = V(:,:,nl)*(-cplus_exp + cminus_exp);
U_harmonic = W(:,:,nl)*(cplus_exp + cminus_exp);
for xl = 1:1:length(x)
xexp = exp(-i*kx*x(xl));
Hy_layer(xl,zl) = U_harmonic' * xexp';
Ex_layer(xl,zl) = (i*Zee0)*S_harmonic' * xexp';
end % x loop
end % z loop
case 3 % Conical
for zl = 1:1:length(z)
c1plus_exp = c1_plus.*exp(-k0*diag(Q1(:,:,nl))*zmDlm1(zl));
c2plus_exp = c2_plus.*exp(-k0*diag(Q2(:,:,nl))*zmDlm1(zl));
c1minus_exp = c1_minus.*exp(k0*diag(Q1(:,:,nl))*zmDl(zl));
c2minus_exp = c2_minus.*exp(k0*diag(Q2(:,:,nl))*zmDl(zl));
Sx_harmonic = W2(:,:,nl)*(c2plus_exp + c2minus_exp);
Ux_harmonic = W1(:,:,nl)*(-c1plus_exp + c1minus_exp);
Sy_harmonic = V11(:,:,nl)*(c1plus_exp + c1minus_exp) + ...
V12(:,:,nl)*(c2plus_exp + c2minus_exp);
Uy_harmonic = V21(:,:,nl)*(c1plus_exp + c1minus_exp) + ...
V22(:,:,nl)*(c2plus_exp + c2minus_exp);
for xl = 1:1:length(x)
xexp = exp(-i*kx*x(xl));
xyexp = exp(-i*(kx*x(xl) + ky*y));
Ey_layer(xl,zl) = Sy_harmonic' * xyexp';
Hx_layer(xl,zl) = (-i/Zee0)*Ux_harmonic' * xyexp';
Hy_layer(xl,zl) = (-i/Zee0)*Uy_harmonic' * xyexp';
Ex_layer(xl,zl) = Sx_harmonic' * xyexp';
end % x loop
end % z loop
end % Polarization switch for grating layers

else % A uniform layer
if (dif_pol ~= 3) % TE/TM
p_q = [ I ; b_ai_X(:,:,nl)] * Tconv;
p = p_q(1:num_orders , : );
q = p_q(num_orders+1:size(p_q) , : );
else % Conical
p_q = [ I zero; zero I; b_ai_X(:,:,nl)] * Tconv;
p1_plus = p_q(1:num_orders , : );
p2_plus = p_q(num_orders+1:2*num_orders , : );
q1_minus = p_q(2*num_orders+1:3*num_orders , : );
q2_minus = p_q(3*num_orders+1:size(c_p_m) , : );
end
switch dif_pol
case 1 % TE
for zl = 1:1:length(zmDl)
p_exp = p.* ...
exp(-k0*diag(Gamma(:,:,Gmat_offset(nl)))*zmDlm1(zl));
q_exp = q.* ...
exp(k0*diag(Gamma(:,:,Gmat_offset(nl)))*zmDl(zl));
S_harmonic = (p_exp + q_exp);
U_harmonic = Gamma(:,:,Gmat_offset(nl))*(-p_exp + q_exp);
for xl = 1:1:length(x)
xexp = exp(-i*kx*x(xl));
Ey_layer(xl,zl) = S_harmonic' * xexp';
Ey_0_layer(xl,zl) = S_harmonic(ord_0) * xexp(ord_0);
Ey_1_layer(xl,zl) = S_harmonic(ord_1) * xexp(ord_1);
Hx_layer(xl,zl) = (-i/Zee0) * U_harmonic' * xexp';
end % x loop
end % z loop
case 2 % TM
for zl = 1:1:length(zmDl)
p_exp = p.* ...
exp(-k0*diag(Gamma(:,:,nGmat_offset(nl)))*zmDlm1(zl));
q_exp = q.* ...
exp(k0*diag(Gamma(:,:,Gmat_offset(nl)))*zmDl(zl));
S_harmonic = Gamma(:,:,Gmat_offset(nl))*(-p_exp + q_exp);
U_harmonic = (p_exp + q_exp);
for xl = 1:1:length(x)
xexp = exp(-i*kx*x(xl)); 
Ey_layer(xl,zl) = S_harmonic' * xexp';
Hx_layer(xl,zl) = (-i/Zee0) * U_harmonic' * xexp';
end % x loop
end % z loop
end % Polarization switch for uniform layers
end % Grating vs. Uniform layer
switch dif_pol
case 1 %TE
Ey_field = [ Ey_field Ey_layer(1:length(x), 1:length(z)) ];
Ey_0_field = [ Ey_0_field Ey_0_layer(1:length(x), 1:length(z)) ];
Ey_1_field = [ Ey_1_field Ey_1_layer(1:length(x), 1:length(z)) ];
Hx_field = [ Hx_field Hx_layer(1:length(x), 1:length(z)) ];
case 2 % TM
Hy_field = [ Hy_field Hy_layer(1:length(x), 1:length(z)) ];
Ex_field = [ Ex_field Ex_layer(1:length(x), 1:length(z)) ];
case 3
Ey_field = [ Ey_field Ey_layer(1:length(x), 1:length(z)) ];
Hx_field = [ Hx_field Hx_layer(1:length(x), 1:length(z)) ];
Hy_field = [ Hy_field Hy_layer(1:length(x), 1:length(z)) ];
Ex_field = [ Ex_field Ex_layer(1:length(x), 1:length(z)) ];
end % Polarization switch for filling output matrix
D_lm1 = D_l;
Tconv = ai_X(:,:,nl) * Tconv;
end % number of layers loop
% Calculate fields in exiting region
z_max = D_l + dist_after;
zII = (D_l+z_resolution):z_resolution:z_max;
switch dif_pol
case 1 % TE
% Preallocate arrays for fields
Ey_II_field = zeros(length(x),length(zII));
Ey_0_II_field = zeros(length(x),length(zII));
Ey_1_II_field = zeros(length(x),length(zII)); 
Hx_II_field = zeros(length(x),length(zII));
% Calculate each field point
for zl = 1:1:length(zII)
for xl = 1:1:length(x)
Ey_II_field(xl,zl) = ...
T'*exp(-j*(kx*x(xl) + kIIz*(zII(zl) - D_l)))';
Ey_0_II_field(xl,zl) = ...
T(ord_0)*exp(-j*(kx(ord_0)*x(xl) + ...
kIIz(ord_0)*(zII(zl) - D_l)));
Ey_1_II_field(xl,zl) = ...
T(ord_1)*exp(-j*(kx(ord_1)*x(xl) + ...
kIIz(ord_1)*(zII(zl) - D_l)));
Hx_II_field(xl,zl) = ...
(1/(k0*Zee0))*(kIIz.*T'*exp(-j*(kx*x(xl) + ...
kIIz*(zII(zl) - D_l)))');
end % x loop
end % z loop
% Store to complete field matrix
Ey_field = [ Ey_field Ey_II_field(1:length(x), 1:length(zII)) ];
Ey_0_field = [ Ey_0_field Ey_0_II_field(1:length(x), 1:length(zII)) ];
Ey_1_field = [ Ey_1_field Ey_1_II_field(1:length(x), 1:length(zII)) ];
Hx_field = [ Hx_field Hx_II_field(1:length(x), 1:length(zII)) ];
case 2 % TM
% Preallocate arrays for fields
Hy_II_field= zeros(length(x),length(zII));
Ex_II_field = zeros(length(x),length(zII));
% Calculate each field point
for zl = 1:1:length(zII)
for xl = 1:1:length(x)
Hy_II_field(xl,zl) = ...
T'*exp(-j*(kx*x(xl) + kIIz*(zII(zl) - D_l)))';
Ex_II_field(xl,zl) = ...
(Zee0/k0/index_II_2)*...
(-1*kIIz.*T'* exp(-j*(kx*x(xl) + kIIz*(zII(zl) - D_l)))');
end % x loop
end % z loop
% Store to complete field matrix
Hy_field = [ Hy_field Hy_II_field(1:length(x), 1:length(zII)) ];
Ex_field = [ Ex_field Ex_II_field(1:length(x), 1:length(zII)) ];
case 3 % Conical 
% Preallocate arrays for fields
Ey_II_field = zeros(length(x),length(zII));
Hx_II_field = zeros(length(x),length(zII));
Hy_II_field= zeros(length(x),length(zII));
Ex_II_field= zeros(length(x),length(zII));
% Calculate each field point
for zl = 1:1:length(zII)
for xl = 1:1:length(x)
ux = cpsi*ctheta*cphi - spsi*sphi;
uy = cpsi*ctheta*sphi + spsi*cphi;
Tx = Tp.*ctheta*cphi + Ts.*sphi;
Ty = Tp.*ctheta*sphi + Ts.*cphi;
Ey_II_field(xl,zl) = ...
Ty'*exp(-j*(kx*x(xl) + ky*y + kIIz*(zII(zl) - D_l)))';
Hx_II_field(xl,zl) = ...
(1/(k0*Zee0)).*(kIIz.*Ty'*exp(-j*(kx*x(xl) + ...
ky*y + kIIz*(zII(zl) - D_l)))');
Hy_II_field(xl,zl) = ...
(-1/(k0*Zee0)).*(kIIz.*Tx'*exp(-j*(kx*x(xl) + ...
ky*y + kIIz*(zII(zl) - D_l)))');
Ex_II_field(xl,zl) = ...
Tx'*exp(-j*(kx*x(xl) + ky*y + kIIz*(zII(zl) - D_l)))';
end % x loop
end % z loop
% Store to complete field matrix
Ey_field = [ Ey_field Ey_II_field(1:length(x), 1:length(zII)) ];
Hx_field = [ Hx_field Hx_II_field(1:length(x), 1:length(zII)) ];
Hy_field = [ Hy_field Hy_II_field(1:length(x), 1:length(zII)) ];
Ex_field = [ Ex_field Ex_II_field(1:length(x), 1:length(zII)) ];
% Temporary switch from field to phase
Ey_field = angle(Ey_field);
Hx_field = angle(Hx_field);
Hy_field = angle(Hy_field);
Ex_field = angle(Ex_field);
end % Polarization switch for exiting field calculations
start = length(z_out)+1;
z_out(start:(start+length(zII)-1)) = zII;
if (dif_pol == 1) %TE
Ey_field_list = [ Ey_field ]; 
h_menu_Ey = findobj(0, 'Tag', 'EyField');
set(h_menu_Ey, 'UserData', Ey_field_list);
Ey_0_field_list = [ Ey_0_field ];
h_menu_Ey_0 = findobj(0, 'Tag', 'EyField_0');
set(h_menu_Ey_0, 'UserData', Ey_0_field_list);
Ey_1_field_list = [ Ey_1_field ];
h_menu_Ey_1 = findobj(0, 'Tag', 'EyField_1');
set(h_menu_Ey_1, 'UserData', Ey_1_field_list);
Hx_field_list = [ Hx_field ];
h_menu_Hx = findobj(0, 'Tag', 'HxField');
set(h_menu_Hx, 'UserData', Hx_field_list);
% Write field matrices in ASCII format
fprintf(Eyfld_outf, '\t%g',z_out);
fprintf(Eyfld_outf, '\n');
for xl = 1:1:length(x)
fprintf(Eyfld_outf, '%g\t', x(xl), Ey_field(xl,:));
fprintf(Eyfld_outf, '\n');
end
save Ey_field;
fprintf(Eyfld_0_outf, '\t%g',z_out);
fprintf(Eyfld_0_outf, '\n');
for xl = 1:1:length(x)
fprintf(Eyfld_0_outf, '%g\t', x(xl), Ey_0_field(xl,:));
fprintf(Eyfld_0_outf, '\n');
end
fprintf(Eyfld_1_outf, '\t%g',z_out);
fprintf(Eyfld_1_outf, '\n');
for xl = 1:1:length(x)
fprintf(Eyfld_1_outf, '%g\t', x(xl), Ey_1_field(xl,:));
fprintf(Eyfld_1_outf, '\n');
end
fprintf(Hxfld_outf, '\t%g',z_out); 
fprintf(Hxfld_outf, '\n');
for xl = 1:1:length(x)
fprintf(Hxfld_outf, '%g\t', x(xl), Hx_field(xl,:));
fprintf(Hxfld_outf, '\n');
end
fclose(Eyfld_outf);
fclose(Eyfld_0_outf);
fclose(Eyfld_1_outf);
fclose(Hxfld_outf);
elseif (dif_pol == 2) % TM
Hy_field_list = [ Hy_field ];
h_menu_Hy = findobj(0, 'Tag', 'HyField');
set(h_menu_Hy, 'UserData', Hy_field_list);
Ex_field_list = [ Ex_field ];
h_menu_Ex = findobj(0, 'Tag', 'ExField');
set(h_menu_Ex, 'UserData', Ex_field_list);
% Write field matrices in ASCII format
fprintf(Hyfld_outf, '\t%g',z_out);
fprintf(Hyfld_outf, '\n');
for xl = 1:1:length(x)
fprintf(Hyfld_outf, '%g\t', x(xl), Hy_field(xl,:));
fprintf(Hyfld_outf, '\n');
end
fprintf(Exfld_outf, '\t%g',z_out);
fprintf(Exfld_outf, '\n');
for xl = 1:1:length(x)
fprintf(Exfld_outf, '%g\t', x(xl), Ex_field(xl,:));
fprintf(Exfld_outf, '\n');
end
fclose(Hyfld_outf);
fclose(Exfld_outf);
else % Conical
Ey_field_list = [ Ey_field ];
h_menu_Ey = findobj(0, 'Tag', 'EyField'); 
set(h_menu_Ey, 'UserData', Ey_field_list);
Hx_field_list = [ Hx_field ];
h_menu_Hx = findobj(0, 'Tag', 'HxField');
set(h_menu_Hx, 'UserData', Hx_field_list);
Hy_field_list = [ Hy_field ];
h_menu_Hy = findobj(0, 'Tag', 'HyField');
set(h_menu_Hy, 'UserData', Hy_field_list);
Ex_field_list = [ Ex_field ];
h_menu_Ex = findobj(0, 'Tag', 'ExField');
set(h_menu_Ex, 'UserData', Ex_field_list);
% Write field matrices in ASCII format
fprintf(Eyfld_outf, '\t%g',z_out);
fprintf(Eyfld_outf, '\n');
for xl = 1:1:length(x)
fprintf(Eyfld_outf, '%g\t', x(xl), Ey_field(xl,:));
fprintf(Eyfld_outf, '\n');
end
fprintf(Hxfld_outf, '\t%g',z_out);
fprintf(Hxfld_outf, '\n');
for xl = 1:1:length(x)
fprintf(Hxfld_outf, '%g\t', x(xl), Hx_field(xl,:));
fprintf(Hxfld_outf, '\n');
end
fprintf(Hyfld_outf, '\t%g',z_out);
fprintf(Hyfld_outf, '\n');
for xl = 1:1:length(x)
fprintf(Hyfld_outf, '%g\t', x(xl), Hy_field(xl,:));
fprintf(Hyfld_outf, '\n');
end
fprintf(Exfld_outf, '\t%g',z_out);
fprintf(Exfld_outf, '\n');
for xl = 1:1:length(x)
fprintf(Exfld_outf, '%g\t', x(xl), Ex_field(xl,:));
fprintf(Exfld_outf, '\n');
end
fclose(Eyfld_outf); 
fclose(Hxfld_outf);
fclose(Hyfld_outf);
fclose(Exfld_outf);
end
field_spec_list = [ dist_before dist_after z_resolution ...
dist_along x_resolution dist_parallel y_resolution ...
z_max z_min x_max x_min y_max y_min z_out];
set(h_menu_fieldspecs, 'UserData', field_spec_list);
%
% Grating Display Calculations
%
cum_thick = 0.0;
num_index = ceil(((x_max - x_min)/grating_period)*2.)+2;
xg = zeros(num_index, num_layers);
zg = zeros(num_index, num_layers);
for nl = 1:1:num_layers
index = 1;
xg(index,nl) = 0.0;
if ( layer_id(nl) == 1 ) % A grating layer
groove_width = grating_period - ridge_width(nl);
if (grating_offset(nl) == 0)
zg(index,nl) = cum_thick + thickness(nl);
index = index + 1;
elseif ((grating_offset(nl) > 0) & (grating_offset(nl) < groove_width))
zg(index,nl) = cum_thick;
index = index + 1;
xg(index,nl) = xg(index-1,nl) + grating_offset(nl);
zg(index,nl) = cum_thick + thickness(nl);
index = index + 1;
elseif ((grating_offset(nl) > 0) & (grating_offset(nl) > groove_width))
zg(index,nl) = cum_thick + thickness(nl);
index = index + 1;
xg(index,nl) = xg(index-1,nl)+(grating_offset(nl) - groove_width);
zg(index,nl) = cum_thick
index = index + 1; 
xg(index,nl) = xg(index-1,nl) + groove_width;
zg(index,nl) = cum_thick + thickness(nl);
index = index + 1;
end
x_start = xg(index-1);
for gl = x_start:grating_period:x_max
if (xg(index-1) + ridge_width(nl) < x_max)
xg(index,nl) = xg(index-1,nl)+ridge_width(nl);
zg(index,nl) = cum_thick;
index = index + 1;
if (xg(index-1) + groove_width < x_max)
xg(index,nl) = xg(index-1,nl) + groove_width;
zg(index,nl) = cum_thick + thickness(nl);
index = index + 1;
else
xg(index,nl) = x_max;
zg(index,nl) = cum_thick + thickness(nl);
index = index + 1;
gl = x_max;
if (index > num_index)
index = num_index;
end
xg(num_index,nl) = xg(index,nl);
zg(num_index,nl) = zg(index,nl);
end
else
xg(index,nl) = x_max;
zg(index,nl) = cum_thick;
gl = x_max;
xg(num_index,nl) = xg(index,nl);
zg(num_index,nl) = zg(index,nl);
end % 'for' loop over x range
end % 'for' loop over x range
else % a uniform layer
% play games to get all rows of xg to be same length
% xg(1:num_index,nl) = (x_min + ((1:num_index)-1)*(grating_period/2))';
% zg(1:num_index,nl) = cum_thick + thickness(nl);
end % grating vs. uniform layer
cum_thick = cum_thick + thickness(nl);
end % number of layers 
layer_plot_list = [ xg zg];
set(h_menu_layers, 'UserData', layer_plot_list);
end % Calculate fields
%------------------------------------------------------------------------------
%
% Stop the stopwatch and get the time
%
toc
% The end
