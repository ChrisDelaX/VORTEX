%Configuration g�n�rale du probl�me
%----------------------------------


%Param�tres de calculs
%---------------------


    %Troncature
    
        %En X (M donc 2M+1 ordres au total)  
    
        N=8;
        
    
%Param�tres du r�seau
%--------------------    
    

%Nombre de couches

    L=1;

    
%Pas du r�seau

    %En X

    %Lxmin=;
    %Lxmax=;
    Lb=1;
    
        %Nombre de point d'�chantillonnage
    
        %nLx=;
   
%Epaisseurs

    %dmin(l)=;
    %dmax(l)=;
    for i=1:10,
        
    d(i)=2;
    
    end;
        
%Permittivit�s
%-------------


    %Permittivit�s milieu ext�rieur incident
    
    %EI=7.29;
    
    %Permittivit�s milieu ext�rieur �mergent
    
    %CdTe � 7 K
    %----------
    
    T=77;
    
    A_cdte = -2.373e-4*T + 3.8466; B_cdte = 8.057e-4*T + 3.2215;

    C_cdte = -1.10e-4*T + 0.1866; D_cdte = -2.160e-2*T + 12.718;

    E_cdte = -3.160e1*T + 18753;
    
    %EIII=7.29;
    
    
    %Permittivit�s du r�seau
    %-----------------------
    
        %R�seau en relief de surface
        %---------------------------
        
        
            %Permittivit� milieu 1
            
            for i=1:10,

            E2(i)=1;
            
            end;
            
            %Permittivit� milieu 2
            
            %for i=1:10,

            %E2(i)=1;
            
            %end;
            
            %Facteur de remplissage
            
                %En X
            
                %Fxmin=;
                %Fxmax=;
                for i=1:10,

                F(i)=0.75;
            
                end;
            
                    %Nombre de point d'�chantillonnage
    
                    %nFx=;

            
        %R�seau en volume
        %----------------
        
        
            %Permittivit� moyenne
            
            %epsm(l)=;
            
            %Modulation de permittivit�
            
            %modmin(l)=;
            %modmax(l)=;
            %mod(l)=;
            
                %Nombre de point d'�chantillonnage
    
                %nmod=;
            
                
                
%Incidence
%---------

    %Longueur d'onde
    
    lbmin=6;
    lbmax=8;
    %lb=2e-6;
    
        %Nombre de point d'�chantillonnage
    
        nlb=50;

    %Angle incidence non conique
    
    %thetamin=;
    %thetamax=;
    theta=0;
    
        %Nombre de point d'�chantillonnage
    
        %ntheta=;
    
    %Angle incidence conique

    %phimin=;
    %phimax=;
    phi=0;
    
        %Nombre de point d'�chantillonnage
    
        %nlphi=;
        
    %Angle polarisation
    
    %psimax=;
    %psimin=;
    psi=pi/4;
    
        %Nombre de point d'�chantillonnage
    
        %nlpsi=;
        
    

    

    
