function[tp_mat]=E_mat(E1,E2,F,N,Lb)

%Construction matrice eps

%Passage de la permittivit� du r�seau � sa transform�e de Fourier

pts_int=1000;

pas=Lb/pts_int;

y1_per=E1;

x1=0:pas:F*Lb;

y2_per=E2;

x2=F*Lb:pas:Lb;


for i=1:2*(2*N+1),
    
    y1 = (y1_per)*exp(-sqrt(-1)*(i-((2*N+1)+1))*(2*pi/Lb)*x1);
    y2 = (y2_per)*exp(-sqrt(-1)*(i-((2*N+1)+1))*(2*pi/Lb)*x2);
    
    section1=trapz(x1,y1);
    section2=trapz(x2,y2);
    
    tp_vec(i)=(1/Lb)*(section1+section2);
    
end;


for i=1:2*N+1,
    
tp_mat(i,:)=tp_vec( i - (1:2*N+1) + (2*N+1+1) );

end;
    
