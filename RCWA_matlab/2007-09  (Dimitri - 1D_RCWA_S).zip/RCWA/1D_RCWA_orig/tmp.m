for i=1:MN,
        
                if (real(Dbb(i))+imag(Dbb(i)))>0
            
                Dbb(i)=Dbb(i);
            
                elseif (real(Dbb(i))+imag(Dbb(i)))<0
            
                Dbb(i)=-Dbb(i);
            
                end;
        
            end;