function[tp_mat]=E_mat(E1,E2,F,N,Lb)

%Construction matrice eps

%Passage de la permittivit� du r�seau � sa transform�e de Fourier

pts_int=1024;

pas=Lb/pts_int;


