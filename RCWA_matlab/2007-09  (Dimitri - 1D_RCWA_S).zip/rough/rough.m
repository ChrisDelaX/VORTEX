clear all

eps1=5.6465;
eps2=1;
L=0.9e-6;
h=1.141e-6;
F=0.33;
thetai=1.1427;
lb=14e-6;

theta=thetai;

k0=2*pi/lb*sqrt(eps1)*sin(thetai);
k=2*pi/lb*sqrt(eps1)*sin(theta);

k1=sqrt(eps1)*2*pi/lb;
k2=sqrt(eps2)*2*pi/lb;


q0=sqrt(k1^2-k0^2);
q=sqrt(k1^2-k^2);
q0p=sqrt(k2^2-k0^2);
qp=sqrt(k2^2-k^2);

rte=(q0-q0p)/(q0+q0p);
rtm=(eps2*q-eps1*qp)/(eps2*q+eps1*qp);

bte=2*(eps2-eps1)*q0*q0p*k0^2/(q0p+q0)^2;
btm=2*(eps2-eps1)*q0/(eps1*q0p+eps2*q0)^2*(sqrt(-1)*(eps2-eps1)/(eps2+eps1)*(eps1*q0p^2+eps2*k0^2)*k0+4*eps1*eps2/(eps1+eps2)*k0^2*q0p-eps1*eps2*k0^2*q0p);

%hm=F*L*h^2;
%hm=h^2*F*L+2*h^2*F^3*L-3*(F*h)^2*L;
%hm=0;%10e-14;

X=(1-F)*h;Y=F*h;
hm=Y^2*(1-F)*L+X^2*F*L;

phiTE=atan(imag(rte+bte*hm)/real(rte+bte*hm));
phiTM=atan(imag(rtm+btm*hm)/real(rtm+btm*hm));


dphi=phiTE-phiTM
dphib=mod(phiTE-phiTM,2*pi)