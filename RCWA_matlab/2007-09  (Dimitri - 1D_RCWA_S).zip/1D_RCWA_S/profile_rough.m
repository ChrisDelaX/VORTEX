% Simulations du nano-roughness
%------------------------------

%r=roughness=5 nm par exemple
%----------------------------
for i=1:1024,
t(i)=tt(floor(1+(i)*Lb/(1024*r)));end;

L=L_wo_R+2;%2 couches suppl�mentaire pour tenir compte du pseudo A/R
        for l=1:L,
            if l==1%COUCHE 1
                d_l(l)=d_R;%AR    
                Ftmp1=(1-Fa)/2*1024;
                Ftmp2=(1+Fa)/2*1024;
                for i=1:1024,
                        if i<=Ftmp1
                            if t(i)=1    
                                prof_inv(l,i)=1/E1;   
                                prof(l,i)=E1;
                            else
                                prof_inv(l,i)=1/E2;   
                                prof(l,i)=E2;
                            end;
                        elseif i<=Ftmp2
                        prof_inv(l,i)=1/E2;%AR         
                        prof(l,i)=E2;%AR               
                        else
                            if t(i)=1
                                prof_inv(l,i)=1/E1;   
                                prof(l,i)=E1;
                            else
                                prof_inv(l,i)=1/E2;   
                                prof(l,i)=E2;
                            end;
                        end;     
			     end;
             elseif l==L%COUCHE L
                d_l(l)=d_R;
                if (L-2)==1    
                pas=0;%indiff�rent
                Fb=Fa;   
                end;  
                Ftmp1=(1-Fb)/2*1024;
                Ftmp2=(1+Fb))/2*1024;
                for i=1:1024,
                        if i<=Ftmp1
                        prof_inv(l,i)=1/E1;%AR   
                        prof(l,i)=E1;%AR
                        elseif i<=Ftmp2
                            if t(i)=1
                                prof_inv(l,i)=1/E1;   
                                prof(l,i)=E1;
                            else
                                prof_inv(l,i)=1/E2;   
                                prof(l,i)=E2;
                            end;           
                        else
                        prof_inv(l,i)=1/E1;%AR    
                        prof(l,i)=E1;%AR
                        end;     
			     end;
                         
             else%COUCHES INTERMEDIAIRES
                d_l(l)=d/(L-2);
                if (L-2)==1    
                pas=0;%indiff�rent
                Fb=Fa;   
                else
                pas=(Fa-Fb)/(L-2-1);
                end;  
                Ftmp1=(1-(Fb+(l-1)*pas)+(cos(rand*pi)*r))/2*1024;
                Ftmp2=(1+(Fb+(l-1)*pas)+(cos(rand*pi)*r))/2*1024;
                for i=1:1024,
                        if i<=Ftmp1
                        prof_inv(l,i)=1/E1;   
                        prof(l,i)=E1;
                        elseif i<=Ftmp2
                        prof_inv(l,i)=1/E2;       
                        prof(l,i)=E2;              
                        else
                        prof_inv(l,i)=1/E1;    
                        prof(l,i)=E1;
                        end;     
			     end;     
             end;
         end;