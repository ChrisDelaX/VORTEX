%Scan3

        switch scan3
            case 1
                for h=1:mesh3,
                Lb_t(h)=Lbmin+h*(Lbmax-Lbmin)/mesh3;
                Lb=Lb_t(h);
                Scan4;
                end;
            case 2
                for h=1:mesh3,
                d_t(h)=dmin+h*(dmax-dmin)/mesh3;
                d=d_t(h);
                Scan4;
                end;
            case 3
                for h=1:mesh3,
                Fa_t(h)=Famin+h*(Famax-Famin)/mesh3;
                Fa=Fa_t(h);
                profile;%changement indice de profil => recalcul du profil
                Scan4;
                end;
            case 4
                for h=1:mesh3,
                Fb_t(h)=Fbmin+h*(Fbmax-Fbmin)/mesh3;
                Fb=Fb_t(h);
                profile;%changement indice de profil => recalcul du profil
                Scan4;
                end;
            case 5
                for h=1:mesh3,
                theta_t(h)=thetamin+h*(thetamax-thetamin)/mesh3;
                theta=theta_t(h);
                Scan4;
                end;
            case 6
                for h=1:mesh3,
                phi_t(h)=phimin+h*(phimax-phimin)/mesh3;
                phi=phi_t(h);
                Scan4;
                end;
            case 7
                for h=1:mesh3,
                psi_t(h)=psimin+h*(psimax-psimin)/mesh3;
                psi=psi_t(h);
                Scan4;
                end;
            case 8
                for h=1:mesh3,
                lb_t(h)=lbmin+h*(lbmax-lbmin)/mesh3;
                lb=lb_t(h);
                Material;%changement de longueur d'onde => dispersion mat�riaux
                profile;%changement indice de profil => recalcul du profil
                Scan4;
                end;
            case 9
                for h=1:mesh3,
                d_AR_t(h)=d_AR_min+h*(d_AR_max-d_AR_min)/mesh3;
                d_AR=d_AR_t(h);
                Scan4;
                end;    
            otherwise
                h=1;
                Scan4;
            end;