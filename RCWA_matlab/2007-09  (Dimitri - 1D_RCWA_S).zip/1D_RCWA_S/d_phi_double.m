function[dphi]=d_phi_double(theta)

global EI_choice EI_t EIII_choice EIII EI E1_choice E2_choice  E_AR_choice lb nlb lbmax lbmin E_man

% for ib=1:nlb,
%                 lb_t(ib)=lbmin+ib*(lbmax-lbmin)/nlb;
%                 lb=lb_t(ib)  ;       

% material;

nti=sqrt(EIII./EI);

%theta=x0;
phi_s=2*atan((sqrt((sin(theta))^2-nti.^2))/(nti^2*cos(theta)));
phi_p=2*atan((sqrt((sin(theta))^2-nti.^2))/(cos(theta)));
% dphi=2*atan((sqrt((sin(theta))^2-nti.^2))/(nti^2*cos(theta)))-2*atan((sqrt((sin(theta))^2-nti.^2))/(cos(theta)));
%nul_phase_fin(ib,tb)=((4*dphi(ib)-pi).^2)/4;
%end;
dphi(1)=phi_s;
dphi(2)=phi_p;