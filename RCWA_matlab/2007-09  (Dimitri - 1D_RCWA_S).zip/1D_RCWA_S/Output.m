%Sauvegarde des r�sultats dans RAM
%---------------------------------

%Efficacit�s dans la base s, p
%-----------------------------

DER_s_fin(ib,jb,h,kb,mb,:)=DER_s;
%save(DER_s_fin,'E:\RCWA_01_05\Scan_4QZOG_diamond_YF3_Lb_d_dAR_lb\DER_s_fin.mat');
DER_p_fin(ib,jb,h,kb,mb,:)=DER_p;
%save(DER_s_fin,'E:\RCWA_01_05\Scan_4QZOG_diamond_YF3_Lb_d_dAR_lb\DER_p_fin.mat');
DET_s_fin(ib,jb,h,kb,mb,:)=DET_s;
%save(DER_s_fin,'E:\RCWA_01_05\Scan_4QZOG_diamond_YF3_Lb_d_dAR_lb\DET_s_fin.mat');
DET_p_fin(ib,jb,h,kb,mb,:)=DET_p;
%save(DER_s_fin,'E:\RCWA_01_05\Scan_4QZOG_diamond_YF3_Lb_d_dAR_lb\DET_p_fin.mat');

%D�phasage entre s et p
%----------------------

%transmission

dphi_sp_T_fin(ib,jb,h,kb,mb)=dphi_sp_T;
%save(DER_s_fin,'E:\RCWA_01_05\Scan_4QZOG_diamond_YF3_Lb_d_dAR_lb\dphi_sp_T_fin.mat');

%r�flexion

dphi_sp_R_fin(ib,jb,h,kb,mb)=dphi_sp_R;


EI_fin(ib,jb,h,kb,mb)=EI;
phi_s_R_fin(ib,jb,h,kb,mb)=phi_s_R;
phi_p_R_fin(ib,jb,h,kb,mb)=phi_p_R;
%save(DER_s_fin,'E:\RCWA_01_05\Scan_4QZOG_diamond_YF3_Lb_d_dAR_lb\dphi_sp_R_fin.mat');

