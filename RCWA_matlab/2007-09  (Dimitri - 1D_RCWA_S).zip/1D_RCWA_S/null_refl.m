function[null_res_sp]=null(x0)

global EI_choice EIII_choice E1_choice E2_choice E1_2lay_choice E2_2lay_choice lbmin lbmax theta phi psi E_AR_choice L_wo_AR ar E_man N nlb F tmp1 tmp2 tmp3 tmp4 tmp5 Fa

% EI_choice=varargin(1);
% EIII_choice=varargin(2);
% E1_choice=varargin(3);
% E2_choice=varargin(4);
% lbmin=varargin(5);
% lbmax=varargin(6);
% theta=varargin(7);
% phi=varargin(8);
% psi=varargin(9);
% E_AR_choice=varargin(10);
% L_wo_AR=varargin(11);
% ar=varargin(12);
% E_man=varargin(13);
% N=varargin(14);

%x0=[Lb,d,Fa,d_AR]

Lb=abs(x0(1));
d=abs(x0(2));
%F=abs(x0(2));
Fa=abs(x0(3));
%Fb=abs(x0(4));
% d_1lay=abs(x0(2));
% d_2lay=abs(x0(3));
% d=abs(x0(2));
% d_R=abs(x0(3));
d_AR=abs(x0(4));
% d_1lay=d_R*d;
% d_2lay=(1-d_R)*d;


x0tmp=x0

for ib=1:nlb,
                lb_t(ib)=lbmin+ib*(lbmax-lbmin)/nlb;
                lb=lb_t(ib);          

%Dispersion mat�riaux
%--------------------

material;

%Profile
%-------
    
profile;
                
Main;%Output;

temp1(ib)=2*DET_s(N+1);
temp2(ib)=2*DET_p(N+1);
temp4(ib)=2*DER_s(N+1);
temp5(ib)=2*DER_p(N+1);
%prof
%E1
%E2
temp3(ib)=mod(dphi_sp_R,2*pi);

q(ib)=(temp4(ib)./temp5(ib));

nul_phase_fin(ib)=(temp3(ib)-pi).^2;

nul_res_sp_b(ib)=(((1+sqrt(q(ib))).^2)./((1-sqrt(q(ib))).^2+nul_phase_fin(ib).*sqrt(q(ib)))).^(-1);
%nul_res_sp_b(ib)=nul_phase_fin(ib)/4;
end;

tmp1=(temp1);
tmp2=(temp2);
tmp3=(temp3);
tmp4=(temp4);
tmp5=(temp5);

% null_res_sp=mean(nul_res_sp_b)+mean(temp1(:).*0.005.*temp4(:).*0.995+temp2(:).*0.005.*temp5(:).*0.995);

null_res_sp=mean(nul_res_sp_b);
% null_res_sp=(nul_res_sp_b(6)+nul_res_sp_b(27))/2+(temp1(6)*0.005*temp4(6)*0.995+temp1(27)*0.005*temp4(27)*0.995)/2+(temp2(6)*0.005*temp5(6)*0.995+temp2(27)*0.005*temp5(27)*0.995)/2;
% % 
% figure;plot(lb_t,nul_res_sp_b,'color',[0 0 0],'Linewidth',2);hold on;plot(lb_t,temp1(:).*0.005.*temp4(:).*0.995+temp2(:).*0.005.*temp5(:).*0.995,'color',[0 0 0],'Linewidth',2,'Linestyle',':');
% xlabel('Wavelength (microns)');ylabel('Null depth/ghost');title('ZOG APS');axis square;set(gca,'YScale','log');

% tmp1=mean(temp1);
% tmp2=mean(temp2);
% tmp3=mean(temp3);
% tmp4=mean(temp4);
% tmp5=mean(temp5);


