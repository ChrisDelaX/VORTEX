%Scan5 -***- scan final et �x�cution du noyau RCWA "Main" suivi de "Output" !!!

        switch scan5
            case 1
                for mb=1:mesh5,
                Lb_t(mb)=Lbmin+kb*(Lbmax-Lbmin)/mesh5;
                Lb=Lb_t(mb);
                %EXECUTION NOYAU MAIN et OUTPUT
                Main;Output;
                end;
            case 2
                for mb=1:mesh5,
                d_t(mb)=dmin+mb*(dmax-dmin)/mesh5;
                d=d_t(mb);
                %EXECUTION NOYAU MAIN et OUTPUT
                Main;Output;
                end;
            case 3
                for mb=1:mesh5,
                Fa_t(mb)=Famin+mb*(Famax-Famin)/mesh5;
                Fa=Fa_t(mb);
                profile;%changement indice de profil => recalcul du profil
                %EXECUTION NOYAU MAIN et OUTPUT
                Main;Output;
                end;
            case 4
                for mb=1:mesh5,
                Fb_t(mb)=Fbmin+mb*(Fbmax-Fbmin)/mesh5;
                Fb=Fb_t(mb);
                profile;%changement indice de profil => recalcul du profil
                %EXECUTION NOYAU MAIN et OUTPUT
                Main;Output;
                end;
            case 5
                for mb=1:mesh5,
                theta_t(mb)=thetamin+mb*(thetamax-thetamin)/mesh5;
                theta=theta_t(mb);
                %EXECUTION NOYAU MAIN et OUTPUT
                Main;Output;
                end;
            case 6
                for mb=1:mesh5,
                phi_t(mb)=phimin+mb*(phimax-phimin)/mesh5;
                phi=phi_t(mb);
                %EXECUTION NOYAU MAIN et OUTPUT
                Main;Output;
                end;
            case 7
                for mb=1:mesh5,
                psi_t(mb)=psimin+mb*(psimax-psimin)/mesh5;
                psi=psi_t(mb);
                %EXECUTION NOYAU MAIN et OUTPUT
                Main;Output;
                end;
            case 8
                for mb=1:mesh5,
                lb_t(mb)=lbmin+mb*(lbmax-lbmin)/mesh5;
                lb=lb_t(mb);
                Material;%changement de longueur d'onde => dispersion mat�riaux
                profile;%changement indice de profil => recalcul du profil
                %EXECUTION NOYAU MAIN et OUTPUT
                Main;Output;
                end;
            case 9
                for mb=1:mesh5,
                d_AR_t(mb)=d_AR_min+mb*(d_AR_max-d_AR_min)/mesh5;
                d_AR=d_AR_t(mb);
                %EXECUTION NOYAU MAIN et OUTPUT
                Main;Output;
                end;  
            otherwise
                mb=1;
                Material;%changement de longueur d'onde => dispersion mat�riaux
                profile;%changement indice de profil => recalcul du profil
                %EXECUTION NOYAU MAIN et OUTPUT
                Main;Output;
            end;