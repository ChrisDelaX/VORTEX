%Scan4

        switch scan4
            case 1
                for kb=1:mesh4,
                Lb_t(kb)=Lbmin+kb*(Lbmax-Lbmin)/mesh4;
                Lb=Lb_t(kb);
                Scan5;
                end;
            case 2
                for kb=1:mesh4,
                d_t(kb)=dmin+kb*(dmax-dmin)/mesh4;
                d=d_t(kb);
                Scan5;
                end;
            case 3
                for kb=1:mesh4,
                Fa_t(kb)=Famin+kb*(Famax-Famin)/mesh4;
                Fa=Fa_t(kb);
                profile;%changement indice de profil => recalcul du profil
                Scan5;
                end;
            case 4
                for kb=1:mesh4,
                Fb_t(kb)=Fbmin+kb*(Fbmax-Fbmin)/mesh4;
                Fb=Fb_t(kb);
                profile;%changement indice de profil => recalcul du profil
                Scan5;
                end;
            case 5
                for kb=1:mesh4,
                theta_t(kb)=thetamin+kb*(thetamax-thetamin)/mesh4;
                theta=theta_t(kb);
                Scan5;
                end;
            case 6
                for kb=1:mesh4,
                phi_t(kb)=phimin+kb*(phimax-phimin)/mesh4;
                phi=phi_t(kb);
                Scan5;
                end;
            case 7
                for kb=1:mesh4,
                psi_t(kb)=psimin+kb*(psimax-psimin)/mesh4;
                psi=psi_t(kb);
                Scan5;
                end;
            case 8
                for kb=1:mesh4,
                lb_t(kb)=lbmin+kb*(lbmax-lbmin)/mesh4;
                lb=lb_t(kb);
                Material;%changement de longueur d'onde => dispersion mat�riaux
                profile;%changement indice de profil => recalcul du profil
                Scan5;
                end;
            case 9
                for kb=1:mesh4,
                d_AR_t(kb)=d_AR_min+kb*(d_AR_max-d_AR_min)/mesh4;
                d_AR=d_AR_t(kb);
                Scan5;
                end;    
            otherwise
                kb=1;
                Scan5;
            end;