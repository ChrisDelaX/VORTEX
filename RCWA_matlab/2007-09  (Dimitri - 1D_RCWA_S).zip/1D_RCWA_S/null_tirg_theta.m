function[res_fin]=null_tirg(x0)

global EI_choice EIII_choice E1_choice E2_choice lbmin lbmax psi E_AR_choice L_wo_AR ar E_man N nlb tmp1 tmp2 tmp3 tmp4 tmp5 phi d Fa Lb%Lb d  theta 

% EI_choice=varargin(1);
% EIII_choice=varargin(2);
% E1_choice=varargin(3);
% E2_choice=varargin(4);
% lbmin=varargin(5);
% lbmax=varargin(6);
% theta=varargin(7);
% phi=varargin(8);
% psi=varargin(9);
% E_AR_choice=varargin(10);
% L_wo_AR=varargin(11);
% ar=varargin(12);
% E_man=varargin(13);
% N=varargin(14);

%x0=[Lb,d,Fa,theta]

 
%Fb=abs(x0(4));
Lb_a=abs(x0(1));Lb=Lb_a;
d_a=abs(x0(2));d=d_a;
% Fa_a=abs(x0(3));Fa=Fa_a;
theta_a=abs(x0(3));

x0tmp=x0

for tb=1:11,
    %div=0;
    div=pi*5/(60*180);
theta_tmp(tb)=theta_a-5*div/10+(tb-1)*div/10;
theta=theta_tmp(tb);
%phi=abs(x0(5));

%Fb=Fa+2*d*tan(pi*1/180)/Lb



for ib=1:nlb,
                lb_t(ib)=lbmin+ib*(lbmax-lbmin)/nlb;
                lb=lb_t(ib);          

%Dispersion mat�riaux
%--------------------

material;

%Profile
%-------
 

profile;
                
Main;%Output;
temp1_a(ib)=2*DET_s(N+1);
temp2_a(ib)=2*DET_p(N+1);
temp4_a(ib)=2*DER_s(N+1);
temp5_a(ib)=2*DER_p(N+1);
%E1
%E2
temp3_a(ib)=mod(dphi_sp_R,2*pi);

q(ib)=(temp4_a(ib)./temp5_a(ib));

nul_phase_fin(ib)=(2*(temp3_a(ib))-pi).^2;

nul_res_sp_b(ib,tb)=(((1+sqrt(q(ib))).^2)./((1-sqrt(q(ib))).^2+nul_phase_fin(ib).*sqrt(q(ib)))).^(-1);

% Lb_b=abs(x0(4));Lb=Lb_b;
% d_b=abs(x0(5));d=d_b;
% Fa_b=abs(x0(6));Fa=Fa_b;
% profile;
%                 
% Main;%Output;
% temp1_b(ib)=2*DET_s(N+1);
% temp2_b(ib)=2*DET_p(N+1);
% temp4_b(ib)=2*DER_s(N+1);
% temp5_b(ib)=2*DER_p(N+1);
% %E1
% %E2
% temp3_b(ib)=mod(dphi_sp_R,2*pi);
% 
% q_b(ib)=(temp4_b(ib)./temp5_b(ib));

% phib_s(ib)=(phi_s_R);
% 
% phib_p(ib)=(phi_p_R);

% nul_phase_fin(ib)=((temp3_a(ib)+temp3_b(ib))-pi).^2;
% q(ib)=q_a(ib)*q_b(ib);
% nul_res_sp_b(ib,tb)=(((1+sqrt(q(ib))).^2)./((1-sqrt(q(ib))).^2+nul_phase_fin(ib).*sqrt(q(ib)))).^(-1);
%nul_res_sp_b(ib)=nul_phase_fin(ib)/4;

end;
% save phib_s phib_s;
% save phib_p phib_p;

null_res_sp_tmp=mean(nul_res_sp_b,1);
% figure;plot(lb_t,nul_res_sp_b,'color',[0 0 0],'Linewidth',2);
% xlabel('Wavelength (microns)');ylabel('Null depth/ghost');title('ZOG APS');axis square;set(gca,'YScale','log');
%figure;
end;
null_res_sp_tab=ones(11);
for tb=1:11,
    null_res_sp_tab(:,tb)=(null_res_sp_tmp)';
end;

s=10;

x(1:s+1)=(-(s/2):((s/2)))/s;
y(1:s+1)=(-(s/2):((s/2)))/s;

[X,Y]=meshgrid(x,y);

[theta,rho]=cart2pol(X,Y);

mask=rho<=0.51;

res=mask.*null_res_sp_tab;

res_fin=sum(sum(res))/sum(sum(mask));

%plot(lb_t,nul_res_sp_b);

% tmp1=mean(temp1);
% tmp2=mean(temp2);
% tmp3=mean(temp3);
% tmp4=mean(temp4);
% tmp5=mean(temp5);
