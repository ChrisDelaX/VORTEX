clear all

load phiphi

y=ones(1000);

% Lb_tmp=0.9;

% d_t= 1.1750
%     1.1803
%     1.1855
%     1.1908
%     1.1961
%     1.2013
%     1.2066
%     1.2118
%     1.2171
%     1.2224
%     1.2276
%     1.2329
%     1.2382
%     1.2434
%     1.2487
%     1.2539
%     1.2592
%     1.2645
%     1.2697
%     1.2750
% F_tmp=0.2778;
% theta=1.1396;
z=9
% F_tmpmin=0.250;F_tmpmax=0.3;
% for k=1:2,
for i=1:500,
    i
    for j=1:500,
%         inda=21;
%         indb=11;
%         while inda>20,            
            indtea=uint8(1+uint8(round(2*randn(1)+z)));
            indtma=uint8(1+uint8(round(2*randn(1)+z)));
            indteb=uint8(1+uint8(round(2*randn(1)+z)));
            indtmb=uint8(1+uint8(round(2*randn(1)+z)));
            %end;
%         while indb>10,
%             indb=uint8(1+uint8(round(1*randn(1)+5)));end;
            
%         prout(i,j)=inda;
        ytea(i,j,:)=phiphi(indtea,1,:);
        ytma(i,j,:)=phiphi(indtma,2,:);
        yteb(i,j,:)=phiphi(indteb,1,:);
        ytmb(i,j,:)=phiphi(indtmb,2,:);
    end;
end;
% end;

reste=ytea+yteb;restm=ytma+ytmb;res=reste-restm;null=(res-pi).^2/4;mnull=mean(mean(mean(null)))


