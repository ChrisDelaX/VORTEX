%Scan2

        switch scan2
            case 1
                for jb=1:mesh2,
                Lb_t(jb)=Lbmin+jb*(Lbmax-Lbmin)/mesh2;
                Lb=Lb_t(jb);
                Scan3;
                end;
            case 2
                for jb=1:mesh2,
                d_t(jb)=dmin+jb*(dmax-dmin)/mesh2;
                d=d_t(jb);
                Scan3;
                end;
            case 3
                for jb=1:mesh2,
                Fa_t(jb)=Famin+jb*(Famax-Famin)/mesh2;
                Fa=Fa_t(jb);
                profile;%changement indice de profil => recalcul du profil
                Scan3;
                end;
            case 4
                for jb=1:mesh2,
                Fb_t(jb)=Fbmin+jb*(Fbmax-Fbmin)/mesh2;
                Fb=Fb_t(jb);
                profile;%changement indice de profil => recalcul du profil
                Scan3;
                end;
            case 5
                for jb=1:mesh2,
                theta_t(jb)=thetamin+jb*(thetamax-thetamin)/mesh2;
                theta=theta_t(jb);
                Scan3;
                end;
            case 6
                for jb=1:mesh2,
                phi_t(jb)=phimin+jb*(phimax-phimin)/mesh2;
                phi=phi_t(jb);
                Scan3;
                end;
            case 7
                for jb=1:mesh2,
                psi_t(jb)=psimin+jb*(psimax-psimin)/mesh2;
                psi=psi_t(jb);
                Scan3;
                end;
            case 8
                for jb=1:mesh2,
                lb_t(jb)=lbmin+jb*(lbmax-lbmin)/mesh2;
                lb=lb_t(jb);
                Material;%changement de longueur d'onde => dispersion mat�riaux
                profile;%changement indice de profil => recalcul du profil
                Scan3;
                end;
            case 9
                for jb=1:mesh2,
                d_AR_t(jb)=d_AR_min+jb*(d_AR_max-d_AR_min)/mesh2;
                d_AR=d_AR_t(jb);
                Scan3;
                end;    
            otherwise
                jb=1;
                Scan3;
            end;