% function[x0,null_res_sp]=null_new(x0,parameters)
function[null_res_sp]=null_new(x0)

global WW E_man sig prof N Lb_tmp d_tmp d_AR_tmp d_AR1_tmp d_AR2_tmp d_arret_tmp F_tmp EI_choice EI EIII_choice EIII E1_choice E2_choice E_AR_choice E_AR1_choice E_AR2_choice E_arret_choice p L_tmp lb_t lb lbmin lbmax nlb theta phi psi tmp1 tmp2 tmp3 tmp4 tmp5 
  

%Lb_tmp=abs(x0(1));F_tmp=1-0.112/Lb_tmp;
% x0

% Lb_tmp=abs(x0(1));d_tmp=abs(x0(2));F_tmp=1-0.08/Lb_tmp;%F_tmp=1-0.08/Lb_tmp;%F_tmp=abs(x0(3));%d_AR_tmp=abs(x0(4));

% Lb_tmp=abs(x0(1));F_tmp=abs(x0(2));d_tmp=abs(x0(3));d_AR_tmp=abs(x0(4));

% Lb_tmp=abs(x0(1));d_tmp=abs(x0(1));%d_AR_tmp=abs(x0(3));

% Lb_tmp=abs(x0(1))+abs(x0(2));F_tmp=abs(x0(1))/(abs(x0(1))+abs(x0(2)));d_tmp=abs(x0(3));d_AR_tmp=abs(x0(4));
% d_tmp=abs(x0(1));

 Lb_tmp=abs(x0(1));d_tmp=abs(x0(2));%F_tmp=abs(x0(3));%d_AR_tmp=abs(x0(3));
% F_tmp=abs(x0(1));%Lb_tmp=abs(x0(2));

% F_tmp=abs(x0(1));d_tmp=abs(x0(2));d_AR_tmp=abs(x0(3));

% d_arret_tmp=abs(x0(5));

x0tmp=x0
sig=ones(2*(2*N+1),nlb);

for ib=1:nlb,
                lb_t(ib)=lbmin+(ib-1)*(lbmax-lbmin)/(nlb-1);
                lb=lb_t(ib);          

%Dispersion mat�riaux
%--------------------
Material_new;
EI=EI_tmp;
EIII=EIII_tmp;
%Fabrication profile
%-------------------
profile_new;

%Core RCWA principal
%-------------------
Main;
sig(:,ib)=(Sigmatmp);
% WW(:,:,ib)=W;
temp1(ib)=2*DET_s(N+1);
temp2(ib)=2*DET_p(N+1);
temp4(ib)=2*DER_s(N+1);
temp5(ib)=2*DER_p(N+1);

temp3(ib)=mod(dphi_sp_T,2*pi);
% temp3(ib)=dphi_sp_T

q(ib)=(temp1(ib)./temp2(ib));
% q(ib)=1;
nul_phase_fin(ib)=(temp3(ib)-pi).^2;

%resultat du nulling avec phase et amplitude mismatch
%----------------------------------------------------
% nul_res_sp_b(ib)=nul_phase_fin(ib)/4;
nul_res_sp_b(ib)=(((1+sqrt(q(ib))).^2)./((1-sqrt(q(ib))).^2+nul_phase_fin(ib).*sqrt(q(ib)))).^(-1);

%resultat du nulling avec phase mismatch only
%--------------------------------------------
%nul_res_sp_b(ib)=nul_phase_fin(ib)/4;

end;

tmp1=(temp1);
tmp2=(temp2);
tmp3=(temp3);
tmp4=(temp4);
tmp5=(temp5);

% null_res_sp=mean(nul_res_sp_b)+(mean(temp1(:).*0.01.*temp4(:).*0.99+temp2(:).*0.01.*temp5(:).*0.99))/2;%+(mean(temp4+temp5))/2;

 null_res_sp=mean(nul_res_sp_b);

% null_res_sp=(0.5*nul_res_sp_b(1)+nul_res_sp_b(8)+0.5*nul_res_sp_b(15)+0.5*nul_res_sp_b(21)+nul_res_sp_b(28)+0.5*nul_res_sp_b(32))/4;

% null_res_sp=mean(nul_res_sp_b(3))/2+mean(nul_res_sp_b(9))/2;
% 
% 1/mean(nul_res_sp_b(4:37))
% 1/mean(nul_res_sp_b(64:95))
% null_res_sp=((mean(nul_res_sp_b(3:13)))); 

% null_res_sp=((mean(nul_res_sp_b(5:25))))%+mean(nul_res_sp_b(21:30))))/2;
%null_res_sp=((nul_res_sp_b(7))+(nul_res_sp_b(28)))/2;
% % 
% figure;plot(lb_t,nul_res_sp_b,'color',[0 0 0],'Linewidth',2);hold on;plot(lb_t,temp1(:).*0.005.*temp4(:).*0.995+temp2(:).*0.005.*temp5(:).*0.995,'color',[0 0 0],'Linewidth',2,'Linestyle',':');
% xlabel('Wavelength (microns)');ylabel('Null depth/ghost');title('ZOG APS');axis square;set(gca,'YScale','log');
% figure;plot(lb_t,tmp1,lb_t,tmp2); figure;plot(lb_t,tmp3);


