

%1: profil rectangulaire simple 
        %   -> 1 couche (L=1)         
        L=1;
        Lb=0.9;
        F=0.2778;
        d=1.2;
        E1=E1_tmp;
        E2=E2_tmp; 
        d_tmp=d/(L);
        for l=1:L,
        d_l(l)=d_tmp;
        ec=1024/32;
        Ftmp=round(F*(ec));
            for i=1:ec,
                tic=round(Ftmp+randn(1))
                for j=1:ec,
                    if j<=tic
                    prof_inv(l,(i-1)*32+j)=1/E2(l);   
                    prof(l,(i-1)*32+j)=E2(l);
                    else
                    prof_inv(l,(i-1)*32+j)=1/E1(l);   
                    prof(l,(i-1)*32+j)=E1(l);
                    end;
                end;
            end;
        end;
                        
                
                
         
                