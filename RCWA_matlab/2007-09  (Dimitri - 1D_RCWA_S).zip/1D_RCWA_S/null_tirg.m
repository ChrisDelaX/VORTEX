% function[x0,null_res_sp]=null_tirg(x0,parameters)
function[null_res_sp]=null_tirg(x0)

global sig prof N Lb_tmp d_tmp d_AR_tmp d_arret_tmp F_tmp EI_choice ind EI EIII_choice EIII E1_choice E2_choice E_AR_choice E_arret_choice p L_tmp lb_t lb lbmin lbmax nlb theta phi psi tmp1 tmp2 tmp3 tmp3b tmp4 tmp5 
  


% EI_choice=varargin(1);
% EIII_choice=varargin(2);
% E1_choice=varargin(3);
% E2_choice=varargin(4);
% lbmin=varargin(5);
% lbmax=varargin(6);
% theta=varargin(7);
% phi=varargin(8);
% psi=varargin(9);
% E_AR_choice=varargin(10);
% L_wo_AR=varargin(11);
% ar=varargin(12);
% E_man=varargin(13);
% N=varargin(14);

%x0=[Lb,d,Fa,theta]

% theta=abs(x0(1));
% d_tmp=abs(x0(1));
% d_tmp=abs(x0(1));theta=abs(x0(2));
% Lb_tmp=x0(1);d_tmp=abs(x0(2));F_tmp=abs(x0(3));theta=abs(x0(4));
% Lb_tmp=abs(x0(1));d_tmp=abs(x0(2));theta=abs(x0(3));

Lb_tmp=abs(x0(1));F_tmp=abs(x0(2));theta=abs(x0(3));
% F_tmp=abs(x0(1));theta=abs(x0(2));
% F_tmp=abs(x0(1));d_tmp=abs(x0(2));theta=abs(x0(3));
% theta=abs(x0(1));

%Fb=abs(x0(4));
  %Fa=abs(x0(3));
%   d_AR=abs(x0(4));
%phi=abs(x0(5))

%Fb=Fa+2*d*tan(pi*1/180)/Lb

x0

for ib=1:nlb,
    
    if nlb==1,
        
        lb=lbmin;
    else
        
                lb_t(ib)=lbmin+(ib-1)*(lbmax-lbmin)/(nlb-1);
                lb=lb_t(ib);          
    end;
%Dispersion mat�riaux
%--------------------

Material_new;
EI=EI_tmp;
EIII=EIII_tmp;ind(ib)=EI;
% E1_tmp(ib)=EI;E2_tmp(ib)=E2;

%Profile
%-------
    
profile_new;
                
Main;%Output;
temp1(ib)=2*DET_s(N+1);
temp2(ib)=2*DET_p(N+1);
temp4(ib)=2*DER_s(N+1);
temp5(ib)=2*DER_p(N+1);
%E1
%E2
% phiTE(ib)=mod(phi_s_R,pi)
% phiTM(ib)=mod(phi_p_R,pi)
phiTE(ib)=phi_s_R;
phiTM(ib)=phi_p_R;
phi_sp(:,ib)=d_phi_double(theta);
% temp3(ib)=mod(dphi_sp_R,pi);
% temp3(ib)=-temp3(ib)+pi;
temp3(ib)=phiTE(ib)-phiTM(ib);
temp3_b(ib)=phi_sp(1,ib)-phi_sp(2,ib);
% q(ib)=(temp4(ib)./temp5(ib));
% temp3_b(ib)=d_phi_double(theta);
% phase(ib)=2*temp3(ib)+2*temp3_b(ib);
% nul_phase_fin(ib)=(2*temp3(ib)+2*temp3_b(ib)-pi).^2;
% nul_phase_fin(ib)=(2*temp3(ib)-pi).^2;
delta(ib)=temp3(ib);
psi(ib)=atan(temp4(ib)./temp5(ib));

% nul_res_sp_b(ib)=(((1+sqrt(q(ib))).^2)./((1-sqrt(q(ib))).^2+nul_phase_fin(ib).*sqrt(q(ib)))).^(-1);
% nul_res_sp_b(ib)=nul_phase_fin(ib)/4;

end;
% save phib_s phib_s;
% save phib_p phib_p;
%  null_res_sp=var(phase)/4;

% null_res_sp=temp3_b+temp3

% null_res_sp(1,:)=phiTE(:)'+phi_sp(1,:);
% null_res_sp(2,:)=phiTM(:)'+phi_sp(2,:);

% null_res_sp=phi_p_T-phi_s_T;

% null_res_sp=mean(nul_res_sp_b);
% null_res_sp=max(nul_res_sp_b);

% figure;
% subplot(2,2,2)
% plot(lb_t,nul_res_sp_b,'color',[0 0 0],'Linewidth',2);
% 
% xlabel('Wavelength (microns)');ylabel('Null depth/ghost');title('ZOG APS');axis square;set(gca,'YScale','log');
% figure;
% plot(nul_res_sp_b)
%   plot(lb_t,nul_res_sp_b);
% 
tmp1=mean(temp1)
tmp2=mean(temp2)

temp3=mod(-temp3,pi)

hold on;plot(lb_t,temp3); 
tmp3=mean(temp3)
tmp4=mean(temp4)
tmp5=mean(temp5)
% tmp1=(temp1);
% tmp2=(temp2);
% % tmp3=(temp3);tmp3b=(temp3_b);
% tmp4=(temp4);
% tmp5=(temp5);
