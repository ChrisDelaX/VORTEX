T=100;    

switch EI_choice
        case 1
            EI=1;
        case 2
            T_cdte=T; A_cdte = -2.973e-4*T_cdte + 3.8466; B_cdte = 8.057e-4*T_cdte + 3.2215; C_cdte = -1.10e-4*T_cdte + 0.1866; D_cdte = -2.160e-2*T_cdte + 12.718; E_cdte = -3.160e1*T_cdte + 18753;
            EI=sellmeier_cdte_ge(lb,A_cdte,B_cdte,C_cdte,D_cdte,E_cdte);
        case 3
            A_d=1 ; B_d=0.3306 ; C_d=175.0 ; D_d= 4.3356 ; E_d=106.0 ; 
            EI=sellmeier_diamant(lb,A_d,B_d,C_d,D_d,E_d);
        case 4
            T_Ge=T; A_Ge=-6.040e-3*T_Ge + 11.05128 ; B_Ge = 9.295e-3*T_Ge + 4.00536 ; C_Ge = -5.392e-4*T_Ge + 0.599034 ; D_Ge = 4.151e-4*T_Ge + 0.09145; E_Ge = 1.51408*T_Ge + 3426.5 ;
            EI=sellmeier_cdte_ge(lb,A_Ge,B_Ge,C_Ge,D_Ge,E_Ge);;
        case 5
            T_si=T; A_si=1.600e-4*T_si+3.431; B_si=-2.643e-2; C_si=4.324e-3; D_si=-3.194e-4; E_si=8.835e-6;
            EI=sellmeier_Si(lb,A_si,B_si,C_si,D_si,E_si);
        case 6
            T_ZnSe=T; A_ZnSe = 1; B_ZnSe = 4.46395; C_ZnSe = 0.20108^2; D_ZnSe = 0.46132; E_ZnSe = 0.39211^2; F_ZnSe = 2.88289 ; G_ZnSe = 47.04759^2 ;
            EI=sellmeier_ZnSe(lb,A_ZnSe,B_ZnSe,C_ZnSe,D_ZnSe,E_ZnSe,F_ZnSe,G_ZnSe);
        case 7
            YF3_data;
            EI=(spline(YF3_l,YF3_n,lb)+sqrt(-1)*(spline(YF3_l,YF3_k,lb)))^2;
        case 8
            EI=E_man^2;  
        case 9
            asga_data;
            EI=(spline(asga_l,asga_n,lb)-sqrt(-1)*(spline(asga_l,asga_k,lb)))^2;
        case 10
            K1_n_laf32=1.91731106;L1_n_laf32=9.78600358e-3;K2_n_laf32=2.24019825e-1;L2_n_laf32=3.86141473e-2;
            K3_n_laf32=1.22087075;L3_n_laf32=8.46431265e1;
            EI=sellmeier_n_laf32(lb,K1_n_laf32,L1_n_laf32,K2_n_laf32,L2_n_laf32,K3_n_laf32,L3_n_laf32);
        case 11
            GASIR_2;
            EI=(spline(GAS2_l,GAS2_n,lb)+sqrt(-1)*(spline(GAS2_l,GAS2_k,lb)))^2;
        case 12
            GASIR_1;
            EI=(spline(GAS2_l,GAS2_n,lb)+sqrt(-1)*(spline(GAS2_l,GAS2_k,lb)))^2;
        case 13
            inp;
            EI=(spline(l_inp,n_inp,lb)+sqrt(-1)*(spline(l_inp,k_inp,lb)))^2;
    end;
    
    switch EIII_choice
        case 1
            EIII=1;
        case 2
            T_cdte=T; A_cdte = -2.973e-4*T_cdte + 3.8466; B_cdte = 8.057e-4*T_cdte + 3.2215; C_cdte = -1.10e-4*T_cdte + 0.1866; D_cdte = -2.160e-2*T_cdte + 12.718; E_cdte = -3.160e1*T_cdte + 18753;
            EIII=sellmeier_cdte_ge(lb,A_cdte,B_cdte,C_cdte,D_cdte,E_cdte);
        case 3
            A_d=1 ; B_d=0.3306 ; C_d=175.0 ; D_d= 4.3356 ; E_d=106.0 ; 
            EIII=sellmeier_diamant(lb,A_d,B_d,C_d,D_d,E_d);
        case 4
            T_Ge=T; A_Ge=-6.040e-3*T_Ge + 11.05128 ; B_Ge = 9.295e-3*T_Ge + 4.00536 ; C_Ge = -5.392e-4*T_Ge + 0.599034 ; D_Ge = 4.151e-4*T_Ge + 0.09145; E_Ge = 1.51408*T_Ge + 3426.5 ;
            EIII=sellmeier_cdte_ge(lb,A_Ge,B_Ge,C_Ge,D_Ge,E_Ge);;
        case 5
            T_si=T; A_si=1.600e-4*T_si+3.431; B_si=-2.643e-2; C_si=4.324e-3; D_si=-3.194e-4; E_si=8.835e-6;
            EIII=sellmeier_Si(lb,A_si,B_si,C_si,D_si,E_si);
        case 6
            T_ZnSe=T; A_ZnSe = 1; B_ZnSe = 4.46395; C_ZnSe = 0.20108^2; D_ZnSe = 0.46132; E_ZnSe = 0.39211^2; F_ZnSe = 2.88289 ; G_ZnSe = 47.04759^2 ;
            EIII=sellmeier_ZnSe(lb,A_ZnSe,B_ZnSe,C_ZnSe,D_ZnSe,E_ZnSe,F_ZnSe,G_ZnSe);
        case 7
            YF3_data;
            EIII=(spline(YF3_l,YF3_n,lb)+sqrt(-1)*(spline(YF3_l,YF3_k,lb)))^2;
        case 8
            EIII=E_man^2;  
        case 9
            asga_data;
            EIII=(spline(asga_l,asga_n,lb)+sqrt(-1)*(spline(asga_l,asga_k,lb)))^2;
        case 10
            K1_n_laf32=1.91731106;L1_n_laf32=9.78600358e-3;K2_n_laf32=2.24019825e-1;L2_n_laf32=3.86141473e-2;
            K3_n_laf32=1.22087075;L3_n_laf32=8.46431265e1;
            EIII=sellmeier_n_laf32(lb,K1_n_laf32,L1_n_laf32,K2_n_laf32,L2_n_laf32,K3_n_laf32,L3_n_laf32);
        case 11
            GASIR_2;
            EIII=(spline(GAS2_l,GAS2_n,lb)+sqrt(-1)*(spline(GAS2_l,GAS2_k,lb)))^2;
        case 12
            GASIR_1;
            EIII=(spline(GAS2_l,GAS2_n,lb)+sqrt(-1)*(spline(GAS2_l,GAS2_k,lb)))^2;
        case 13
            inp;
            EIII=(spline(l_inp,n_inp,lb)+sqrt(-1)*(spline(l_inp,k_inp,lb)))^2;
            
    end;
    
    switch E1_choice
        case 1
            E1=1;
        case 2
            T_cdte=T; A_cdte = -2.973e-4*T_cdte + 3.8466; B_cdte = 8.057e-4*T_cdte + 3.2215; C_cdte = -1.10e-4*T_cdte + 0.1866; D_cdte = -2.160e-2*T_cdte + 12.718; E_cdte = -3.160e1*T_cdte + 18753;
            E1=sellmeier_cdte_ge(lb,A_cdte,B_cdte,C_cdte,D_cdte,E_cdte);
        case 3
            A_d=1 ; B_d=0.3306 ; C_d=175.0 ; D_d= 4.3356 ; E_d=106.0 ; 
            E1=sellmeier_diamant(lb,A_d,B_d,C_d,D_d,E_d);
        case 4
            T_Ge=T; A_Ge=-6.040e-3*T_Ge + 11.05128 ; B_Ge = 9.295e-3*T_Ge + 4.00536 ; C_Ge = -5.392e-4*T_Ge + 0.599034 ; D_Ge = 4.151e-4*T_Ge + 0.09145; E_Ge = 1.51408*T_Ge + 3426.5 ;
            E1=sellmeier_cdte_ge(lb,A_Ge,B_Ge,C_Ge,D_Ge,E_Ge);;
        case 5
            T_si=T; A_si=1.600e-4*T_si+3.431; B_si=-2.643e-2; C_si=4.324e-3; D_si=-3.194e-4; E_si=8.835e-6;
            E1=sellmeier_Si(lb,A_si,B_si,C_si,D_si,E_si);
        case 6
            T_ZnSe=T; A_ZnSe = 1; B_ZnSe = 4.46395; C_ZnSe = 0.20108^2; D_ZnSe = 0.46132; E_ZnSe = 0.39211^2; F_ZnSe = 2.88289 ; G_ZnSe = 47.04759^2 ;
            E1=sellmeier_ZnSe(lb,A_ZnSe,B_ZnSe,C_ZnSe,D_ZnSe,E_ZnSe,F_ZnSe,G_ZnSe);
        case 7
            YF3_data;
            E1=(spline(YF3_l,YF3_n,lb)+sqrt(-1)*(spline(YF3_l,YF3_k,lb)))^2;
        case 8
            E1=E_man^2;
        case 9
            asga_data;
            E1=(spline(asga_l,asga_n,lb)+sqrt(-1)*(spline(asga_l,asga_k,lb)))^2;
        case 10
            K1_n_laf32=1.91731106;L1_n_laf32=9.78600358e-3;K2_n_laf32=2.24019825e-1;L2_n_laf32=3.86141473e-2;
            K3_n_laf32=1.22087075;L3_n_laf32=8.46431265e1;
            E1=sellmeier_n_laf32(lb,K1_n_laf32,L1_n_laf32,K2_n_laf32,L2_n_laf32,K3_n_laf32,L3_n_laf32);
        case 11
            GASIR_2;
            E1=(spline(GAS2_l,GAS2_n,lb)+sqrt(-1)*(spline(GAS2_l,GAS2_k,lb)))^2;
        case 12
            GASIR_1;
            E1=(spline(GAS2_l,GAS2_n,lb)+sqrt(-1)*(spline(GAS2_l,GAS2_k,lb)))^2;
        case 13
            inp;
            E1=(spline(l_inp,n_inp,lb)+sqrt(-1)*(spline(l_inp,k_inp,lb)))^2;
    end;
    
    switch E2_choice
        case 1
            E2=1;
        case 2
            T_cdte=T; A_cdte = -2.973e-4*T_cdte + 3.8466; B_cdte = 8.057e-4*T_cdte + 3.2215; C_cdte = -1.10e-4*T_cdte + 0.1866; D_cdte = -2.160e-2*T_cdte + 12.718; E_cdte = -3.160e1*T_cdte + 18753;
            E2=sellmeier_cdte_ge(lb,A_cdte,B_cdte,C_cdte,D_cdte,E_cdte);
        case 3
            A_d=1 ; B_d=0.3306 ; C_d=175.0 ; D_d= 4.3356 ; E_d=106.0 ; 
            E2=sellmeier_diamant(lb,A_d,B_d,C_d,D_d,E_d);
        case 4
            T_Ge=T; A_Ge=-6.040e-3*T_Ge + 11.05128 ; B_Ge = 9.295e-3*T_Ge + 4.00536 ; C_Ge = -5.392e-4*T_Ge + 0.599034 ; D_Ge = 4.151e-4*T_Ge + 0.09145; E_Ge = 1.51408*T_Ge + 3426.5 ;
            E2=sellmeier_cdte_ge(lb,A_Ge,B_Ge,C_Ge,D_Ge,E_Ge);;
        case 5
            T_si=T; A_si=1.600e-4*T_si+3.431; B_si=-2.643e-2; C_si=4.324e-3; D_si=-3.194e-4; E_si=8.835e-6;
            E2=sellmeier_Si(lb,A_si,B_si,C_si,D_si,E_si);
        case 6
            T_ZnSe=T; A_ZnSe = 1; B_ZnSe = 4.46395; C_ZnSe = 0.20108^2; D_ZnSe = 0.46132; E_ZnSe = 0.39211^2; F_ZnSe = 2.88289 ; G_ZnSe = 47.04759^2 ;
            E2=sellmeier_ZnSe(lb,A_ZnSe,B_ZnSe,C_ZnSe,D_ZnSe,E_ZnSe,F_ZnSe,G_ZnSe);
        case 7
            YF3_data;
            E2=(spline(YF3_l,YF3_n,lb)+sqrt(-1)*(spline(YF3_l,YF3_k,lb)))^2;
        case 8
            E2=E_man^2;  
        case 9
            asga_data;
            E2=(spline(asga_l,asga_n,lb)+sqrt(-1)*(spline(asga_l,asga_k,lb)))^2;
            
        case 10
            K1_n_laf32=1.91731106;L1_n_laf32=9.78600358e-3;K2_n_laf32=2.24019825e-1;L2_n_laf32=3.86141473e-2;
            K3_n_laf32=1.22087075;L3_n_laf32=8.46431265e1;
            E2=sellmeier_n_laf32(lb,K1_n_laf32,L1_n_laf32,K2_n_laf32,L2_n_laf32,K3_n_laf32,L3_n_laf32);
        case 11
            GASIR_2;
            E2=(spline(GAS2_l,GAS2_n,lb)+sqrt(-1)*(spline(GAS2_l,GAS2_k,lb)))^2;
        case 12
            GASIR_1;
            E2=(spline(GAS2_l,GAS2_n,lb)+sqrt(-1)*(spline(GAS2_l,GAS2_k,lb)))^2;
        case 13
            inp;
            E2=(spline(l_inp,n_inp,lb)+sqrt(-1)*(spline(l_inp,k_inp,lb)))^2;
    end; 
    
    switch E1_2lay_choice
        case 1
            E1_2lay=1;
        case 2
            T_cdte=T; A_cdte = -2.973e-4*T_cdte + 3.8466; B_cdte = 8.057e-4*T_cdte + 3.2215; C_cdte = -1.10e-4*T_cdte + 0.1866; D_cdte = -2.160e-2*T_cdte + 12.718; E_cdte = -3.160e1*T_cdte + 18753;
            E1_2lay=sellmeier_cdte_ge(lb,A_cdte,B_cdte,C_cdte,D_cdte,E_cdte);
        case 3
            A_d=1 ; B_d=0.3306 ; C_d=175.0 ; D_d= 4.3356 ; E_d=106.0 ; 
            E1_2lay=sellmeier_diamant(lb,A_d,B_d,C_d,D_d,E_d);
        case 4
            T_Ge=T; A_Ge=-6.040e-3*T_Ge + 11.05128 ; B_Ge = 9.295e-3*T_Ge + 4.00536 ; C_Ge = -5.392e-4*T_Ge + 0.599034 ; D_Ge = 4.151e-4*T_Ge + 0.09145; E_Ge = 1.51408*T_Ge + 3426.5 ;
            E1_2lay=sellmeier_cdte_ge(lb,A_Ge,B_Ge,C_Ge,D_Ge,E_Ge);;
        case 5
            T_si=T; A_si=1.600e-4*T_si+3.431; B_si=-2.643e-2; C_si=4.324e-3; D_si=-3.194e-4; E_si=8.835e-6;
            E1_2lay=sellmeier_Si(lb,A_si,B_si,C_si,D_si,E_si);
        case 6
            T_ZnSe=T; A_ZnSe = 1; B_ZnSe = 4.46395; C_ZnSe = 0.20108^2; D_ZnSe = 0.46132; E_ZnSe = 0.39211^2; F_ZnSe = 2.88289 ; G_ZnSe = 47.04759^2 ;
            E1_2lay=sellmeier_ZnSe(lb,A_ZnSe,B_ZnSe,C_ZnSe,D_ZnSe,E_ZnSe,F_ZnSe,G_ZnSe);
        case 7
            YF3_data;
            E1_2lay=(spline(YF3_l,YF3_n,lb)+sqrt(-1)*(spline(YF3_l,YF3_k,lb)))^2;
        case 8
            E1_2lay=E_man^2;  
        case 9
            asga_data;
            E1_2lay=(spline(asga_l,asga_n,lb)+sqrt(-1)*(spline(asga_l,asga_k,lb)))^2;
            
        case 10
            K1_n_laf32=1.91731106;L1_n_laf32=9.78600358e-3;K2_n_laf32=2.24019825e-1;L2_n_laf32=3.86141473e-2;
            K3_n_laf32=1.22087075;L3_n_laf32=8.46431265e1;
            E1_2lay=sellmeier_n_laf32(lb,K1_n_laf32,L1_n_laf32,K2_n_laf32,L2_n_laf32,K3_n_laf32,L3_n_laf32);
        case 11
            GASIR_2;
            E1_2lay=(spline(GAS2_l,GAS2_n,lb)+sqrt(-1)*(spline(GAS2_l,GAS2_k,lb)))^2;
        case 12
            GASIR_1;
            E1_2lay=(spline(GAS2_l,GAS2_n,lb)+sqrt(-1)*(spline(GAS2_l,GAS2_k,lb)))^2;
        case 13
            inp;
            E1_2lay=(spline(l_inp,n_inp,lb)+sqrt(-1)*(spline(l_inp,k_inp,lb)))^2;
    end; 
    
    switch E2_2lay_choice
        case 1
            E2_2lay=1;
        case 2
            T_cdte=T; A_cdte = -2.973e-4*T_cdte + 3.8466; B_cdte = 8.057e-4*T_cdte + 3.2215; C_cdte = -1.10e-4*T_cdte + 0.1866; D_cdte = -2.160e-2*T_cdte + 12.718; E_cdte = -3.160e1*T_cdte + 18753;
            E2_2lay=sellmeier_cdte_ge(lb,A_cdte,B_cdte,C_cdte,D_cdte,E_cdte);
        case 3
            A_d=1 ; B_d=0.3306 ; C_d=175.0 ; D_d= 4.3356 ; E_d=106.0 ; 
            E2_2lay=sellmeier_diamant(lb,A_d,B_d,C_d,D_d,E_d);
        case 4
            T_Ge=T; A_Ge=-6.040e-3*T_Ge + 11.05128 ; B_Ge = 9.295e-3*T_Ge + 4.00536 ; C_Ge = -5.392e-4*T_Ge + 0.599034 ; D_Ge = 4.151e-4*T_Ge + 0.09145; E_Ge = 1.51408*T_Ge + 3426.5 ;
            E2_2lay=sellmeier_cdte_ge(lb,A_Ge,B_Ge,C_Ge,D_Ge,E_Ge);;
        case 5
            T_si=T; A_si=1.600e-4*T_si+3.431; B_si=-2.643e-2; C_si=4.324e-3; D_si=-3.194e-4; E_si=8.835e-6;
            E2_2lay=sellmeier_Si(lb,A_si,B_si,C_si,D_si,E_si);
        case 6
            T_ZnSe=T; A_ZnSe = 1; B_ZnSe = 4.46395; C_ZnSe = 0.20108^2; D_ZnSe = 0.46132; E_ZnSe = 0.39211^2; F_ZnSe = 2.88289 ; G_ZnSe = 47.04759^2 ;
            E2_2lay=sellmeier_ZnSe(lb,A_ZnSe,B_ZnSe,C_ZnSe,D_ZnSe,E_ZnSe,F_ZnSe,G_ZnSe);
        case 7
            YF3_data;
            E2_2lay=(spline(YF3_l,YF3_n,lb)+sqrt(-1)*(spline(YF3_l,YF3_k,lb)))^2;
        case 8
            E2_2lay=E_man^2;  
        case 9
            asga_data;
            E2_2lay=(spline(asga_l,asga_n,lb)+sqrt(-1)*(spline(asga_l,asga_k,lb)))^2;
            
        case 10
            K1_n_laf32=1.91731106;L1_n_laf32=9.78600358e-3;K2_n_laf32=2.24019825e-1;L2_n_laf32=3.86141473e-2;
            K3_n_laf32=1.22087075;L3_n_laf32=8.46431265e1;
            E2_2lay=sellmeier_n_laf32(lb,K1_n_laf32,L1_n_laf32,K2_n_laf32,L2_n_laf32,K3_n_laf32,L3_n_laf32);
        case 11
            GASIR_2;
            E2_2lay=(spline(GAS2_l,GAS2_n,lb)+sqrt(-1)*(spline(GAS2_l,GAS2_k,lb)))^2;
        case 12
            GASIR_1;
            E2_2lay=(spline(GAS2_l,GAS2_n,lb)+sqrt(-1)*(spline(GAS2_l,GAS2_k,lb)))^2;
        case 13
            inp;
            E2_2lay=(spline(l_inp,n_inp,lb)+sqrt(-1)*(spline(l_inp,k_inp,lb)))^2;
    end; 
    
    switch E_AR_choice
        case 1
            E_AR=1;
        case 2
            T_cdte=T; A_cdte = -2.973e-4*T_cdte + 3.8466; B_cdte = 8.057e-4*T_cdte + 3.2215; C_cdte = -1.10e-4*T_cdte + 0.1866; D_cdte = -2.160e-2*T_cdte + 12.718; E_cdte = -3.160e1*T_cdte + 18753;
            E_AR=sellmeier_cdte_ge(lb,A_cdte,B_cdte,C_cdte,D_cdte,E_cdte);
        case 3
            A_d=1 ; B_d=0.3306 ; C_d=175.0 ; D_d= 4.3356 ; E_d=106.0 ; 
            E_AR=sellmeier_diamant(lb,A_d,B_d,C_d,D_d,E_d);
        case 4
            T_Ge=T; A_Ge=-6.040e-3*T_Ge + 11.05128 ; B_Ge = 9.295e-3*T_Ge + 4.00536 ; C_Ge = -5.392e-4*T_Ge + 0.599034 ; D_Ge = 4.151e-4*T_Ge + 0.09145; E_Ge = 1.51408*T_Ge + 3426.5 ;
            E_AR=sellmeier_cdte_ge(lb,A_Ge,B_Ge,C_Ge,D_Ge,E_Ge);;
        case 5
            T_si=T; A_si=1.600e-4*T_si+3.431; B_si=-2.643e-2; C_si=4.324e-3; D_si=-3.194e-4; E_si=8.835e-6;
            E_AR=sellmeier_Si(lb,A_si,B_si,C_si,D_si,E_si);
        case 6
            T_ZnSe=T; A_ZnSe = 1; B_ZnSe = 4.46395; C_ZnSe = 0.20108^2; D_ZnSe = 0.46132; E_ZnSe = 0.39211^2; F_ZnSe = 2.88289 ; G_ZnSe = 47.04759^2 ;
            E_AR=sellmeier_ZnSe(lb,A_ZnSe,B_ZnSe,C_ZnSe,D_ZnSe,E_ZnSe,F_ZnSe,G_ZnSe);
        case 7
            YF3_data;
            E_AR=(spline(YF3_l,YF3_n,lb)+sqrt(-1)*(spline(YF3_l,YF3_k,lb)))^2;
        case 8
            E_AR=E_man^2;
        case 9
            asga_data;
            E_AR=(spline(asga_l,asga_n,lb)+sqrt(-1)*(spline(asga_l,asga_k,lb)))^2;    
            
            case 10
            K1_n_laf32=1.91731106;L1_n_laf32=9.78600358e-3;K2_n_laf32=2.24019825e-1;L2_n_laf32=3.86141473e-2;
            K3_n_laf32=1.22087075;L3_n_laf32=8.46431265e1;
            E_AR=sellmeier_n_laf32(lb,K1_n_laf32,L1_n_laf32,K2_n_laf32,L2_n_laf32,K3_n_laf32,L3_n_laf32);
        
    end; 


%     %Diamant
%     %-------
%     
%     A_d=1 ; B_d=0.3306 ; C_d=175.0 ; D_d= 4.3356 ; E_d=106.0 ;    
% 
%     %Germanium
%     %---------
%     
%     T_Ge=77; A_Ge=-6.040e-3*T_Ge + 11.05128 ; B_Ge = 9.295e-3*T_Ge + 4.00536 ; C_Ge = -5.392e-4*T_Ge + 0.599034 ; D_Ge = 4.151e-4*T_Ge + 0.09145; E_Ge = 1.51408*T_Ge + 3426.5 ;
%     
%     
%     %CdTe dispersion coefficient - s2
%     %--------------------------------
%     
%     T_cdte=77; A_cdte = -2.373e-4*T_cdte + 3.8466; B_cdte = 8.057e-4*T_cdte + 3.2215; C_cdte = -1.10e-4*T_cdte + 0.1866; D_cdte = -2.160e-2*T_cdte + 12.718; E_cdte = -3.160e1*T_cdte + 18753;
% 
% 
%     %ZnSe dispersion coefficient - s2
%     %--------------------------------
%     
%     T_ZnSe=298; A_ZnSe = 1; B_ZnSe = 4.46395; C_ZnSe = 0.20108^2; D_ZnSe = 0.46132; E_ZnSe = 0.39211^2; F_ZnSe = 2.88289 ; G_ZnSe = 47.04759^2 ;
%     
%     %Silicon dispersion coefficient - sX
%     %-----------------------------------
%     
%     T_si=298; A_si=1.600e-4*T_si+3.431; B_si=-2.643e-2; C_si=4.324e-3; D_si=-3.194e-4; E_si=8.835e-6;
%     
%     %YF3
%     %---
%     
%     YF3_data;
%             
%     %E1(1,i)=(spline(YF3_l,YF3_n,lb(i))+sqrt(-1)*(spline(YF3_l,YF3_k,lb(i))))^2;