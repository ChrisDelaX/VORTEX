fv = isosurface(Lb_s,d_znse,F_s,t(:,:,:),2e-3)
patch(fv)
camlight
lighting gouraud