function[tp_mat]=E_mat(prof,N)

%Construction matrice eps dite de TOEPLITZ

%Passage de la permittivit� du r�seau � sa transform�e de Fourier

Etmp=ifft(prof);%/(1024);

Etmp=fftshift(Etmp);

i=-N;

for k=1:2*N+1,
    
    p=-N;
    
    for j=1:2*N+1,
        
        tp_mat(k,j)=Etmp(513+(i-p));
        
        p=p+1;
        
    end;
    
i=i+1;    
    
end;