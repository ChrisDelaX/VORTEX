function[res_fin]=null_tirg_double(x0)

global EI_choice EIII_choice EIII EI E1_choice E2_choice lbmin lbmax psi E_AR_choice L_wo_AR ar E_man N nlb tmp1 tmp2 tmp3 tmp4 tmp5 phi d Fa Lb%Lb d  theta 

 
%Fb=abs(x0(4));
 Lb_a=abs(x0(1));Lb=Lb_a;
d_a=abs(x0(2));d=d_a;
    Fa_a=abs(x0(3));Fa=Fa_a;
theta_a=abs(x0(4));theta=theta_a;

x0tmp=x0

for ib=1:nlb,
                lb_t(ib)=lbmin+ib*(lbmax-lbmin)/nlb;
                lb=lb_t(ib);          

%Dispersion mat�riaux
%--------------------

material;

%Profile
%-------
 

profile;
                
Main;%Output;
temp1_a(ib)=2*DET_s(N+1);
temp2_a(ib)=2*DET_p(N+1);
temp4_a(ib)=2*DER_s(N+1);
temp5_a(ib)=2*DER_p(N+1);
%E1
%E2
temp3_a(ib)=mod(dphi_sp_R,pi);
temp3_a(ib)=-temp3_a(ib)+pi;

q(ib)=(temp4_a(ib)./temp5_a(ib));

temp3_b(ib)=abs(d_phi_double(theta));

nul_phase_fin(ib)=(2*(temp3_a(ib))+2*temp3_b(ib)-pi).^2;

nul_res_sp_b(ib)=(((1+sqrt(q(ib))).^2)./((1-sqrt(q(ib))).^2+nul_phase_fin(ib).*sqrt(q(ib)))).^(-1);

end;

res_fin=mean(nul_res_sp_b);

% plot(lb_t,nul_res_sp_b);