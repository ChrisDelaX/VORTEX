%Initialisation de l'algo d'optimisation
%---------------------------------------

%Gestion de la m�moire
%---------------------
%---------------------

    %Lib�ration 
    %----------

    clear all;close all;
    
    global EI_choice EIII_choice E1_choice E2_choice lbmin lbmax theta phi psi E_AR_choice L_wo_AR ar E_man N nlb tmp1 tmp2 tmp3 tmp4 tmp5 Fa
    
    %Lectures des entr�es
    %--------------------
    %--------------------

    %Inputs
    %------
    
    %Param�tres de calculs
    %---------------------

    %Troncature
    
        %En X (N donc 2N+1 ordres au total)  
    
        N=6;
    
    %Param�tres du r�seau
    %--------------------    
    
	%Pas du r�seau
        
        Lb=0.7;
            
	%Epaisseurs
	
        d=2.5;
           
	%Permittivit�s
	%-------------
	
	%Choix mat�riau
        
        %1: Vide/Air
        %2: CdTe
        %3: Diamant
        %4: Germanium
        %5: Silicium
        %6: ZnSe
        %7: YF3
        %8: Manuel
        E_man=1.57;
            %LaF2: E_man=1.57;
            %BaF2: E_man(l=1.97 microns)=1.4647
            %BaF2: E_man(l=2.3253 microns)=1.4635
            %BaF2: E_man(l=2.6738 microns)=1.4623
        
        %Permittivit�s milieu ext�rieur incident
        
        EI_choice=1;
        
        %Permittivit�s milieu ext�rieur �mergent
        
        EIII_choice=3;
        
        %Permittivit�s du r�seau
        %-----------------------
        
            %R�seau en relief de surface
            %---------------------------
            
                %Permittivit� milieu 1
                
                E1_choice=1;
                
                %Permittivit� milieu 2
                
                E2_choice=3;
                                       
                %Facteurs de remplissage
                
                Fa=0.72;% Grande Base trap�ze
                Famin=0.55;Famax=0.85;
                Fb=Fa;
%                 Fb=Fa;% Petite Base trap�ze
%                 if Fb==Fa  
%                 Fbmin=Famin;Fbmax=Fbmin;
%                 else
%                 Fbmin=0.5;Fbmax=0.9;
%                 end;
                
            %Permittivit�s pseudo A/R
            %------------------------
               
                E_AR_choice=7;
                d_AR=0.38;
                             
           
	%Nombre de couches
	%-----------------
	
        L_wo_AR=1;%hors A/R
        
        %Sans Pseudo-A/R YF3 : 1
        
        ar=2;%par d�faut ar=1
           
        %Avec Pseudo-A/R : 2
        
        %Avec Pseudo-A/R sur r�seau trap�zoidal : 3
        
        if ar==2
            if Fb==Fa
            ar=2;%3 couches
            else
            %TBD!!!
            ar=3;%au moins 5 couches, pour la pr�cision de la discr�tisation
            end;
        end;
        
	%Onde incidente 
	%--------------
	
        %Longueur d'onde
        
        lb=4;
        lbmin=2;lbmax=2.4;
        nlb=20;
	
        %Angle incidence non conique
        
        
        theta=0*pi/180;
        %theta=39.5*pi/180;
        thetamin=35*pi/180;thetamax=50*pi/180;
       
        %Angle incidence conique
	
        phi=0*pi/180;
        phimin=0;phimax=0;
            
        %Angle polarisation
        
        psi=pi/4;
        psimin=0;psimax=0;
    
                                 
    %Allocation m�moire
    %------------------

    kx_mat=zeros(2*N+1);
    ky_mat=zeros(2*N+1);
    kIz_mat=zeros(2*N+1);
    kIIIz_mat=zeros(2*N+1);
    
    E=zeros(2*N+1);
    A=zeros(2*N+1);
    B=zeros(2*N+1);
    D=zeros(2*N+1);

    Omega=zeros(2*(2*N+1));
    
    Tuu_l=zeros(2*(2*N+1));
    Rud_l=zeros(2*(2*N+1));
    Rdu_l=zeros(2*(2*N+1));
    Tdd_l=zeros(2*(2*N+1));

    F_lp1=zeros(4*(2*N+1));
  
    X_lp1=zeros(2*(2*N+1));

    %global EI_choice EIII_choice E1_choice E2_choice lbmin lbmax theta phi psi E_AR_choice L_wo_AR ar E_man N
    
    %Optimisation
    %------------
    
    %x0=[Lb,d,d_AR];
    
% Pr�diction des param�tres pour le cas diamant YF3 en bande K (7 ordres et
% 20 points)
%     param_pred=[0.9048    2.4016    0.3844
%     0.8932    2.4398    0.3742
%     0.8791    2.4856    0.3399
%     0.8668    2.5179    0.3330
%     0.8510    2.5535    0.3223
%     0.8386    2.5662    0.3420
%     0.8254    2.5933    0.3298
%     0.8129    2.6204    0.3212
%     0.8014    2.6493    0.3123
%     0.7921    2.6692    0.3286
%     0.7806    2.7083    0.3010
%     0.7716    2.7396    0.2989
%     0.7612    2.7743    0.3043
%     0.7569    2.8076    0.3297
%     0.7487    2.8296    0.3474
%     0.7429    2.8336    0.4058
%     0.7354    2.8561    0.4306
%     0.7293    2.9045    0.4304
%     0.7267    2.9288    0.4873
%     0.7202    3.0545    0.3831
%     0.7168    3.1802    0.3131
%     0.7092    3.2277    0.3214
%     0.7010    3.2913    0.2946
%     0.6987    3.3464    0.3305
%     0.7024    3.3722    0.4538
%     0.6936    3.6602    0.0858
%     0.6992    3.6734    0.2921
%     0.6962    3.7733    0.2790
%     0.6886    3.8780    0.2370
%     0.6896    4.0710    0.1894
%     0.6855    4.2011    0.1581];
    
    %'MaxIter',100
    %options=[];
    
    for i=1:31,
        
        x0_t(i,:)=param_pred(i,:);
        Fa_t(i)=Famin+(i-1)*(Famax-Famin)/30;
        x0=x0_t(i,:);
        Fa=Fa_t(i);
        [x,fval,exitflag] = fminsearch(@null,x0,optimset('MaxIter',100,'Display','iter','TolX',2e-3))
        param(i,:)=x;
        nulldpt(i)=fval;
        tm1(i)=tmp1;
        tm2(i)=tmp2;
        tm3(i)=tmp3;
        tm4(i)=tmp4
        tm5(i)=tmp5;
        
    end;
    
    
%     lb=[350e-9,300e-9,0.55,300e-9];
%     
%     ub=[1e-6,4e-6,0.85,500e-9];
%     
    %[x,fval,exitflag] = fmincon(@null,x0,[],[],[],[],lb,ub)
    
    

