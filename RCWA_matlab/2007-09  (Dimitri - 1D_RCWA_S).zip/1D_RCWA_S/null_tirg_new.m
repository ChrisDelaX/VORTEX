% function[x0,res_fin]=null_tirg_double(x0,parameters)
function[null_res_sp]=null_tirg(x0)

global sig prof N Lb_tmp d_tmp d_AR_tmp d_arret_tmp F_tmp EI_choice EI EIII_choice EIII E1_choice E2_choice E_AR_choice E_arret_choice p L_tmp lb_t lb lbmin lbmax nlb theta phi psi tmp1 tmp2 tmp3 tmp4 tmp5 
  
% d_tmp=abs(x0(1));theta=abs(x0(2));
thetab=abs(x0(1));

%Fb=abs(x0(4));
  %Fa=abs(x0(3));
%   d_AR=abs(x0(4));
%phi=abs(x0(5))

%Fb=Fa+2*d*tan(pi*1/180)/Lb
 
%Fb=abs(x0(4));
% Lb_a=abs(x0(1));Lb=Lb_a;
% d_a=abs(x0(2));d=d_a;
% Fa_a=abs(x0(3));Fa=Fa_a;
% theta_a=abs(x0(4));%theta=theta_a;

%div=1/60/180*pi;
 dth=0.01;

x0tmp=x0

for ib=1:nlb,
                lb_t(ib)=lbmin+(ib-1)*(lbmax-lbmin)/(nlb-1);
                lb=lb_t(ib);          

%Dispersion mat�riaux
%--------------------

Material_new;
EI=EI_tmp;
EIII=EIII_tmp;
% E1_tmp(ib)=EI;E2_tmp(ib)=E2;

%Profile
%-------
    
profile_new;
%Rhomb1
theta=thetab+dth
Main;%Output;
temp1(ib)=2*DET_s(N+1);
temp2(ib)=2*DET_p(N+1);
temp4(ib)=2*DER_s(N+1);
temp5(ib)=2*DER_p(N+1);
%E1
%E2
temp3(ib)=mod(dphi_sp_R,pi);
temp3(ib)=-temp3(ib)+pi;
q(ib)=(temp4(ib)./temp5(ib));
temp3_b(ib)=d_phi_double(theta);
phase1(ib)=temp3(ib)+temp3_b(ib);

%Rhomb 2
theta=thetab-dth
Main;%Output;
temp1(ib)=2*DET_s(N+1);
temp2(ib)=2*DET_p(N+1);
temp4(ib)=2*DER_s(N+1);
temp5(ib)=2*DER_p(N+1);
%E1
%E2
temp3(ib)=mod(dphi_sp_R,pi);
temp3(ib)=-temp3(ib)+pi;
q(ib)=(temp4(ib)./temp5(ib));
temp3_b(ib)=d_phi_double(theta);
phase2(ib)=temp3(ib)+temp3_b(ib);


nul_phase_fin(ib)=(phase1(ib)+phase2(ib)-pi).^2;
%nul_phase_fin(ib)=(4*temp3_b(ib)-pi).^2;


nul_res_sp_b(ib)=(((1+sqrt(q(ib))).^2)./((1-sqrt(q(ib))).^2+nul_phase_fin(ib).*sqrt(q(ib)))).^(-1);

% temp3_s(ib)=mod(temp3_a_tm(ib)-(temp3_b_te(ib)+temp3_b_te_bis(ib))/2,pi);
% temp3_s(ib)=-temp3_s(ib)+pi;
% 
% temp3_p(ib)=mod((temp3_b_tm(ib)+temp3_b_tm_bis(ib))/2-temp3_a_te(ib),pi);
% temp3_p(ib)=-temp3_p(ib)+pi;
% 
% %q(ib)=(temp4_a(ib)./temp5_a(ib));
% 
% 
% 
% nul_phase_fin_s(ib)=(4*temp3_s(ib)-pi).^2/4;
% nul_phase_fin_p(ib)=(4*temp3_p(ib)-pi).^2/4;
% nul_res_sp_b(ib)=(nul_phase_fin_s(ib)+nul_phase_fin_p(ib))/2;
%=(((1+sqrt(q(ib))).^2)./((1-sqrt(q(ib))).^2+nul_phase_fin(ib).*sqrt(q(ib)))).^(-1);

end;
null_res_sp=mean(nul_res_sp_b);
figure;
plot(lb_t,nul_res_sp_b,'color',[0 0 0],'Linewidth',2);
xlabel('Wavelength (microns)');ylabel('Null depth/ghost');title('ZOG APS');axis square;set(gca,'YScale','log');