%Initialisation de l'algo d'optimisation
%---------------------------------------

%Gestion de la m�moire
%---------------------
%---------------------

    %Lib�ration 
    %----------

    clear all;close all;
    
    global EI_choice EIII_choice E1_choice E2_choice E1_2lay_choice E2_2lay_choice lbmin lbmax theta phi psi E_AR_choice F L_wo_AR ar E_man N nlb tmp1 tmp2 tmp3 tmp4 tmp5 Fa
    
    %Lectures des entr�es
    %--------------------
    %--------------------

    %Inputs
    %------
    
    %Param�tres de calculs
    %---------------------

    %Troncature
    
        %En X (N donc 2N+1 ordres au total)  
    
        N=8;
    
    %Param�tres du r�seau
    %--------------------    
    
	%Pas du r�seau
        
        Lb=0.4;
            
	%Epaisseurs
	
       % d=3;
       d=1.75;
       d_R=0.5;
%         d_1lay=0.5;
%         d_2lay=2;
	%Permittivit�s
	%-------------
	
	%Choix mat�riau
        
        %1: Vide/Air
        %2: CdTe
        %3: Diamant
        %4: Germanium
        %5: Silicium
        %6: ZnSe
        %7: YF3
        %8: Manuel
        %9: AsGa
        %10: n-laf32
        %11: GASIR 2
        %12: GASIR 1
        %13: InP
        %14: Infrasil
        E_man=(0.85+sqrt(-1)*12.6);
            %LaF2: E_man=1.57;
            %BaF2: E_man(l=1.97 microns)=1.4647
            %BaF2: E_man(l=2.3253 microns)=1.4635
            %BaF2: E_man(l=2.6738 microns)=1.4623
        
        %Permittivit�s milieu ext�rieur incident
        
        EI_choice=1;
        
        %Permittivit�s milieu ext�rieur �mergent
        
        EIII_choice=8;
        
        %Permittivit�s du r�seau
        %-----------------------
        
            %R�seau en relief de surface
            %---------------------------
            
                %Permittivit� milieu 1
                
                E1_choice=1;
                
                %Permittivit� milieu 2
                
                E2_choice=8;
                
                %Permittivit� milieu 1 mat 2
                
                E1_2lay_choice=1;
                
                %Permittivit� milieu 2 mat 2
                
                E2_2lay_choice=5;
                                       
                %Facteurs de remplissage
                
                Fa=0.75;% Grande Base trap�ze
                %Famin=0.65;Famax=0.85;
                %Fb=0.65;
%                 Fb=Fa;% Petite Base trap�ze
%                 if Fb==Fa  
%                 Fbmin=Famin;Fbmax=Fbmin;
%                 else
%                 Fbmin=0.5;Fbmax=0.9;
%                 end;
                
            %Permittivit�s pseudo A/R
            %------------------------
               
                E_AR_choice=14;
                d_AR=0.3;
                             
           
	%Nombre de couches
	%-----------------
	
        L_wo_AR=1;%hors A/R
        
        %Sans Pseudo-A/R YF3 : 1
        
        ar=1;%par d�faut ar=1
        F=Fa;   
        %Avec Pseudo-A/R : 2
        
        %Avec Pseudo-A/R sur r�seau trap�zoidal : 3
        
%         if ar==2
%             if Fb==Fa
%             ar=2;%3 couches
%             else
%             %TBD!!!
%             ar=3;%au moins 5 couches, pour la pr�cision de la discr�tisation
%             end;
%         end;
%         
	%Onde incidente 
	%--------------
	
        %Longueur d'onde
        
        lb=4;
        lbmin=1.475;lbmax=2.3;
        nlb=32;
	
        %Angle incidence non conique
        
        
        theta=0*pi/180;
        %theta=39.5*pi/180;
        thetamin=35*pi/180;thetamax=50*pi/180;
       
        %Angle incidence conique
	
        phi=0*pi/180;
        phimin=0;phimax=0;
            
        %Angle polarisation
        
        psi=pi/4;
        psimin=0;psimax=0;
    
                                 
    %Allocation m�moire
    %------------------

    kx_mat=zeros(2*N+1);
    ky_mat=zeros(2*N+1);
    kIz_mat=zeros(2*N+1);
    kIIIz_mat=zeros(2*N+1);
    
    E=zeros(2*N+1);
    A=zeros(2*N+1);
    B=zeros(2*N+1);
    D=zeros(2*N+1);

    Omega=zeros(2*(2*N+1));
    
    Tuu_l=zeros(2*(2*N+1));
    Rud_l=zeros(2*(2*N+1));
    Rdu_l=zeros(2*(2*N+1));
    Tdd_l=zeros(2*(2*N+1));

    F_lp1=zeros(4*(2*N+1));
  
    X_lp1=zeros(2*(2*N+1));

    %global EI_choice EIII_choice E1_choice E2_choice lbmin lbmax theta phi psi E_AR_choice L_wo_AR ar E_man N
    
    %Optimisation
    %------------
    
   % x0=[Lb,d,d_R,d_AR];
    x0=[Lb,d,Fa,d_AR];
    
% Pr�diction des param�tres pour le cas diamant YF3 en bande K (7 ordres et
% 20 points)
% param_pred=[1.0542    2.1375    0.3567
%     1.0358    2.1725    0.3379
%     1.0182    2.2083    0.3196
%     1.0030    2.1671    0.4355
%     0.9900    2.2880    0.2893
%     0.9726    2.3204    0.2830
%     0.9589    2.2945    0.3850
%     0.9422    2.3553    0.3207
%     0.9297    2.3314    0.4054
%     0.9161    2.3788    0.3742
%     0.9019    2.4015    0.3763
%     0.8890    2.4313    0.3724
%     0.8764    2.4777    0.3432
%     0.8653    2.5038    0.3505
%     0.8517    2.5398    0.3480
%     0.8371    2.5615    0.3398
%     0.8237    2.5873    0.3280
%     0.8114    2.6132    0.3208
%     0.8000    2.6425    0.3117
%     0.7891    2.6707    0.3053
%     0.7791    2.7022    0.2994
%     0.7694    2.7322    0.2982
%     0.7593    2.7690    0.3048
%     0.7557    2.7847    0.3608
%     0.7454    2.8280    0.3373
%     0.7402    2.8298    0.4029
%     0.7327    2.8531    0.4251
%     0.7248    2.9466    0.3487
%     0.7248    2.9232    0.4849
%     0.7190    3.0390    0.3948
%     0.7163    3.1182    0.3877
%     0.7077    3.2202    0.3129
%     0.6980    3.2797    0.2813
%     0.7012    3.3023    0.4022
%     0.7013    3.3638    0.4527
%     0.6988    3.5674    0.2928
%     0.6971    3.6691    0.2873
%     0.6953    3.7531    0.3166
%     0.6995    3.8182    0.4311
%     0.7032    4.1018    0.300
%     0.6834    4.2946    0.300
%     0.7114    4.3706    0.4088
%     0.6915    4.9962    0.3312
%     0.7278    4.8738    0.3869
%     0.7368    5.2292    0.2996
%     0.7304    5.9313    0.3466
%     0.7687    6.0759    0.2801
%     0.7995    6.6810    0.4651
%     0.8220    7.4902    0.2984
%     0.8577    8.3940    0.3968
%     0.9025    9.7110    0.3711];
    
    %'MaxIter',100
    %options=[];
    
   % for i=1:21,
        %i=1;
        %x0_t(i,:)=param_pred(i,:);
        %Fa_t(i)=Famin+(i-1)*(Famax-Famin)/20;
        %x0=x0_t(i,:);
        %Fa=Fa_t(i);
        [x,fval,exitflag] = fminsearch(@null_refl,x0,optimset('MaxIter',200,'Display','iter','TolX',1e-3))
        param(i,:)=x;
        nulldpt(i)=fval;
        tm1(i)=tmp1;
        tm2(i)=tmp2;
        tm3(i)=tmp3;
        tm4(i)=tmp4
        tm5(i)=tmp5;
        
        %end;
    
    
%     lb=[350e-9,300e-9,0.55,300e-9];
%     
%     ub=[1e-6,4e-6,0.85,500e-9];
%     
    %[x,fval,exitflag] = fmincon(@null,x0,[],[],[],[],lb,ub)
    
    

