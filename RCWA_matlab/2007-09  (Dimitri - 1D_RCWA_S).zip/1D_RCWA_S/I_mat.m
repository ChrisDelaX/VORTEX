function[Itmp]=I_mat(MN)

%Construction matrice identit� I

Itmp=eye(MN);