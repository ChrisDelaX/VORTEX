%Sauvegarde des r�sultats
%------------------------

%Efficacit�s dans la base s, p
%-----------------------------

%DER_s_fin(ib,jb,h,kb,mb,:)=DER_s;
save('E:\RCWA_01_05\Scan_4QZOG_Si_LaF2_Lb_d_Fa_dAR_lb\DER_s_fin.mat','DER_s_fin');
%DER_p_fin(ib,jb,h,kb,mb,:)=DER_p;
save('E:\RCWA_01_05\Scan_4QZOG_Si_LaF2_Lb_d_Fa_dAR_lb\DER_p_fin.mat','DER_p_fin');
%DET_s_fin(ib,jb,h,kb,mb,:)=DET_s;
save('E:\RCWA_01_05\Scan_4QZOG_Si_LaF2_Lb_d_Fa_dAR_lb\DET_s_fin.mat','DET_s_fin');
%DET_p_fin(ib,jb,h,kb,mb,:)=DET_p;
save('E:\RCWA_01_05\Scan_4QZOG_Si_LaF2_Lb_d_Fa_dAR_lb\DET_p_fin.mat','DET_p_fin');

%D�phasage entre s et p
%----------------------

%transmission

%dphi_sp_T_fin(ib,jb,h,kb,mb)=dphi_sp_T;
save('E:\RCWA_01_05\Scan_4QZOG_Si_LaF2_Lb_d_Fa_dAR_lb\dphi_sp_T_fin.mat','dphi_sp_T_fin');

%r�flexion

%dphi_sp_R_fin(ib,jb,h,kb,mb)=dphi_sp_R;
save('E:\RCWA_01_05\Scan_4QZOG_Si_LaF2_Lb_d_Fa_dAR_lb\dphi_sp_R_fin.mat','dphi_sp_R_fin');
