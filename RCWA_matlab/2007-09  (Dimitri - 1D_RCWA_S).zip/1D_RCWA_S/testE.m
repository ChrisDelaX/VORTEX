Ftmp1=(1-(Fa+Fb))/2*1024;

Ftmp2=(1-(Fa))/2*1024;

Ftmp3=(1+(Fa))/2*1024;

Ftmp4=(1+(Fa+Fb))/2*1024;
        
for i=1:1024,
    
            if i<=Ftmp1
        
            Etmp(i)=E1;
        
            elseif i<=Ftmp2
            
            Etmp(i)=E2;
                
            elseif i<=Ftmp3
       
            Etmp(i)=E3;

            elseif i<=Ftmp4
            
            Etmp(i)=E2;
            
            else
            
            Etmp(i)=E1;
            
            end
            
end