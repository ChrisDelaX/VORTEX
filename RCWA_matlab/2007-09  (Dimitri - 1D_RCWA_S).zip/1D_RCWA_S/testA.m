Ftmp1=(1-(Fa+Fb))/2*1024;

Ftmp2=(1-(Fa))/2*1024;

Ftmp3=(1+(Fa))/2*1024;

Ftmp4=(1+(Fa+Fb))/2*1024;
        
for i=1:1024,
    
            if i<=Ftmp1
        
            Etmp(i)=1/E1;
        
            elseif i<=Ftmp2
            
            Etmp(i)=1/E2;
                
            elseif i<=Ftmp3
        
            Etmp(i)=1/E3;

            elseif i<=Ftmp4
            
            Etmp(i)=1/E2;
            
            else
            
            Etmp(i)=1/E1;
            
            end
            
end