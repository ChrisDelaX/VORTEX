function[null_res_sp]=d_phi(theta)

global EI_choice EI_t EIII_choice E1_choice E2_choice  E_AR_choice lb lb_t nlb lbmax lbmin E_man

% x0

% for tb=1:2,
%     div=pi*1/180;
% theta=x0-div+(tb-1)*2*div;
% % for t=1:2,
    
x0=theta
%-0.05+0.1*(t-1)
for ib=1:nlb,
                lb_t(ib)=lbmin+ib*(lbmax-lbmin)/nlb;
                lb=lb_t(ib)  ;       

Material_new;

 EI_t(ib)=EI_tmp;

nti(ib)=sqrt(EIII_tmp/EI_tmp);

%theta=x0;
phi_s(ib)=2*atan((sqrt((sin(theta))^2-nti(ib).^2))/(nti(ib)^2*cos(theta)));
phi_p(ib)=2*atan((sqrt((sin(theta))^2-nti(ib).^2))/(cos(theta)));
dphi(ib)=2*atan((sqrt((sin(theta))^2-nti(ib).^2))/(nti(ib)^2*cos(theta)))-2*atan((sqrt((sin(theta))^2-nti(ib).^2))/(cos(theta)));
nul_phase_fin(ib)=((4*dphi(ib)-pi).^2)/4;
end;
% end;
%   nul_phase_fin=(((2*dphi(:,1)+2*dphi(:,2))-pi).^2)/4;
% null_res_sp(:)=(dphi(:));
 null_res_sp=mean(nul_phase_fin);
 %end;
% null_res_sp=mean(null_res_sp_tmp);
%  plot(lb_t,nul_phase_fin);hold on; plot(lb_t,1e-5*(lb_t/7).^3.37);axis square;set(gca,'YScale','log');