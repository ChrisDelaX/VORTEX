%Equation de Sellmeier ZnSe bis

function[n]=sellmeier_ZnSebis(l,A,B,C,D,E,F,G)

n=(A+B*l+C*l^2+D*l^3)^2;