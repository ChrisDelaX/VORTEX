%Profile trap�zoidale
%--------------------

% Remplissage Grande Base: param�tre Fa

% Remplissage Petite Base: param�tre Fb
 
% mat�riau r�seau 1: E1

% mat�riau r�seau 2: E2

% mat�riau pseudo A/R: E_AR

% L: discr�tisation, nombre de couche

% de 1 � L, du superstrat au substrat

% profondeur totale: d

%   prof

switch ar
    
    case 1 %sans pseudo A/R
        L=L_wo_AR;
        for l=1:L,
            d_l(l)=d/L;
            if L==1    
                pas=1;%indiff�rent
                Fb=Fa;   
            else
            pas=(Fa-Fb)/(L-1);
            end;  
            Ftmp1=(1-(Fb+(l-1)*pas))/2*1024;
            Ftmp2=(1+(Fb+(l-1)*pas))/2*1024;
            for i=1:1024,
                    if i<=Ftmp1
                    prof_inv(l,i)=1/E1;   
                    prof(l,i)=E1;
                    elseif i<=Ftmp2
                    prof_inv(l,i)=1/E2;        
                    prof(l,i)=E2;               
                    else
                    prof_inv(l,i)=1/E1;    
                    prof(l,i)=E1;
                    end;     
		     end;
	     end;
    
    case 2 %avec pseudo A/R
        L=L_wo_AR+2;%2 couches suppl�mentaire pour tenir compte du pseudo A/R
        for l=1:L,
            if l==1%COUCHE 1
                d_l(l)=d_AR;%AR
                if (L-2)==1    
                pas=0;%indiff�rent
                Fb=Fa;   
                else
                pas=(Fa-Fb)/(L-1);
                end;  
                Ftmp1=(1-(Fb+(l-1)*pas))/2*1024;
                Ftmp2=(1+(Fb+(l-1)*pas))/2*1024;
                for i=1:1024,
                        if i<=Ftmp1
                        prof_inv(l,i)=1/E1;   
                        prof(l,i)=E1;
                        elseif i<=Ftmp2
                        prof_inv(l,i)=1/E_AR;%AR         
                        prof(l,i)=E_AR;%AR               
                        else
                        prof_inv(l,i)=1/E1;    
                        prof(l,i)=E1;
                        end;     
			     end;
             elseif l==L%COUCHE L
                d_l(l)=d_AR;%AR
                if (L-2)==1    
                pas=0;%indiff�rent
                Fb=Fa;   
                else
                pas=(Fa-Fb)/(L-2-1);
                end;  
                Ftmp1=(1-(Fb+(l-1)*pas))/2*1024;
                Ftmp2=(1+(Fb+(l-1)*pas))/2*1024;
                for i=1:1024,
                        if i<=Ftmp1
                        prof_inv(l,i)=1/E_AR;%AR   
                        prof(l,i)=E_AR;%AR
                        elseif i<=Ftmp2
                        prof_inv(l,i)=1/E2;        
                        prof(l,i)=E2;            
                        else
                        prof_inv(l,i)=1/E_AR;%AR    
                        prof(l,i)=E_AR;%AR
                        end;     
			     end;
             else%COUCHES INTERMEDIAIRES
                d_l(l)=d/(L-2);
                if (L-2)==1    
                pas=0;%indiff�rent
                Fb=Fa;   
                else
                pas=(Fa-Fb)/(L-2-1);
                end;  
                Ftmp1=(1-(Fb+(l-1)*pas))/2*1024;
                Ftmp2=(1+(Fb+(l-1)*pas))/2*1024;
                for i=1:1024,
                        if i<=Ftmp1
                        prof_inv(l,i)=1/E1;   
                        prof(l,i)=E1;
                        elseif i<=Ftmp2
                        prof_inv(l,i)=1/E2;       
                        prof(l,i)=E2;              
                        else
                        prof_inv(l,i)=1/E1;    
                        prof(l,i)=E1;
                        end;     
			     end;     
             end;
         end;
         
     case 3 %avec pseudo A/R adh�rent aux parois du r�seau trap�zoidal
        
        %TBD!!!
        %couche1
        %-------
        YF3_data;
        E1(1)=1;
        E2(1)=0;
        E3(1)=(spline(YF3_l,YF3_n,lb(i))+sqrt(-1)*(spline(YF3_l,YF3_k,lb(i))))^2;     
        Fa(1)=0.65;       
        Fb(1)=0;    
        %couche2
        %-------
        %ss-couche a
        E1(2)=1;       
        E2(2)=E3(1);
        %E_test(i)=E1(2);
        E3(2)=sellmeier3(lb(i),A_ZnSe,B_ZnSe,C_ZnSe,D_ZnSe,E_ZnSe,F_ZnSe,G_ZnSe);
        Fa(2)=0.65;
        Fb(2)=0.025;       
        %ss-couche b
        E1(3)=1;        
        E2(3)=E3(1);
        %E_test(i)=E1(2);
        E3(3)=sellmeier3(lb(i),A_ZnSe,B_ZnSe,C_ZnSe,D_ZnSe,E_ZnSe,F_ZnSe,G_ZnSe);        
        Fa(3)=0.675;       
        Fb(3)=0.025;                 
        %ss-couche c   
        E1(4)=1;    
        E2(4)=E3(1);
        %E_test(i)=E1(2);
        E3(4)=sellmeier3(lb(i),A_ZnSe,B_ZnSe,C_ZnSe,D_ZnSe,E_ZnSe,F_ZnSe,G_ZnSe);       
        Fa(4)=0.7;        
        Fb(4)=0.025;
        %couche3
        %-------
        E1(5)=0;       
        E2(5)=E3(1);           
        E3(5)=sellmeier3(lb(i),A_ZnSe,B_ZnSe,C_ZnSe,D_ZnSe,E_ZnSe,F_ZnSe,G_ZnSe);        
        Fa(5)=0.75;
        Fb(5)=0.25;
      
    case 4
        
% Simulations du nano-roughness        
%------------------------------

%r=roughness=5 nm par exemple
%----------------------------

L=L_wo_R+2;%2 couches suppl�mentaire pour tenir compte du pseudo A/R
        for l=1:L,
            if l==L%COUCHE L
                d_l(l)=d_R;%AR    
                Ftmp1=(1-Fa)/2*1024;
                Ftmp2=(1+Fa)/2*1024;
                for i=1:1024,
                        if i<=Ftmp1
                            if t(i)==1
                                prof_inv(l,i)=1/E1;   
                                prof(l,i)=E1;
                            else
                                prof_inv(l,i)=1/E2;   
                                prof(l,i)=E2;
                            end;
                        elseif i<=Ftmp2
                        prof_inv(l,i)=1/E2;%AR         
                        prof(l,i)=E2;%AR               
                        else
                            if t(i)==1
                                prof_inv(l,i)=1/E1;   
                                prof(l,i)=E1;
                            else
                                prof_inv(l,i)=1/E2;   
                                prof(l,i)=E2;
                            end;
                        end;     
			     end;
             elseif l==1%COUCHE 1
                d_l(l)=d_R;
                if (L-2)==1    
                pas=0;%indiff�rent
                Fb=Fa;   
                end;  
                Ftmp1=(1-Fb)/2*1024;
                Ftmp2=(1+Fb)/2*1024;
                for i=1:1024,
                        if i<=Ftmp1
                        prof_inv(l,i)=1/E1;%AR   
                        prof(l,i)=E1;%AR
                        elseif i<=Ftmp2
                            if t(i)==1
                                prof_inv(l,i)=1/E1;   
                                prof(l,i)=E1;
                            else
                                prof_inv(l,i)=1/E2;   
                                prof(l,i)=E2;
                            end;           
                        else
                        prof_inv(l,i)=1/E1;%AR    
                        prof(l,i)=E1;%AR
                        end;     
			     end;
                         
             else%COUCHES INTERMEDIAIRES
                d_l(l)=d/(L-2);%-2);
                if (L-2)==1    
                pas=0;%indiff�rent
                Fb=Fa;   
                else
                pas=(Fa-Fb)/(L-2-1);
                end;  
                Ftmp1=(1-(Fb+(l-1)*pas)+shift(l))/2*1024;
                Ftmp2=(1+(Fb+(l-1)*pas)+shift(l))/2*1024;
                for i=1:1024,
                        if i<=Ftmp1
                        prof_inv(l,i)=1/E1;   
                        prof(l,i)=E1;
                        elseif i<=Ftmp2
                        prof_inv(l,i)=1/E2;       
                        prof(l,i)=E2;              
                        else
                        prof_inv(l,i)=1/E1;    
                        prof(l,i)=E1;
                        end;     
			     end;     
             end;
         end;
        
end;

% Renversement du profile
%------------------------

prof=flipdim(prof,1);

prof_inv=flipdim(prof_inv,1);
    
    