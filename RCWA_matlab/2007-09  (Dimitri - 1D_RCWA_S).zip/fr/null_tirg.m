function[null_res_sp]=null_tirg(x0)

global EI_choice EIII_choice E1_choice E2_choice E1_t E2_t lbmin lbmax psi E_AR_choice L_wo_AR ar E_man N nlb sig sigma tmp1 tmp2 tmp3 temp3 tmp4 tmp5 phi Fa d%Lb d  %theta sig sigma 

% EI_choice=varargin(1);
% EIII_choice=varargin(2);
% E1_choice=varargin(3);
% E2_choice=varargin(4);
% lbmin=varargin(5);
% lbmax=varargin(6);
% theta=varargin(7);
% phi=varargin(8);
% psi=varargin(9);
% E_AR_choice=varargin(10);
% L_wo_AR=varargin(11);
% ar=varargin(12);
% E_man=varargin(13);
% N=varargin(14);

%x0=[Lb,d,Fa,d_AR]

Lb=abs(x0(1));
%d=abs(x0(2));
d=abs(x0(2));
theta=abs(x0(3));
%d_AR=abs(x0(5));
%d
x0tmp=x0

for ib=1:nlb,
                lb_t(ib)=lbmin+ib*(lbmax-lbmin)/nlb;
                lb=lb_t(ib);          

%Dispersion mat�riaux
%--------------------

material;

%Profile
%-------
    
profile;
                
Main;%Output;

temp1(ib)=2*DET_s(N+1);
temp2(ib)=2*DET_p(N+1);
temp4(ib)=2*DER_s(N+1);
temp5(ib)=2*DER_p(N+1);
E1_t(ib)=E1; E2_t(ib)=E2;
temp3(ib)=mod(dphi_sp_R,2*pi);

q(ib)=(temp4(ib)./temp5(ib));

nul_phase_fin(ib)=(2*temp3(ib)-pi).^2;

nul_res_sp_b(ib)=(((1+sqrt(q(ib))).^2)./((1-sqrt(q(ib))).^2+nul_phase_fin(ib).*sqrt(q(ib)))).^(-1);
%nul_res_sp_b(ib)=nul_phase_fin(ib)/4;
sig(1:2*(2*N+1),ib)=sigma;       
end;

null_res_sp=mean(nul_res_sp_b);

%figure;

%plot(lb_t,nul_res_sp_b);%figure;plot(lb_t,temp3/2);

tmp1=mean(temp1);
tmp2=mean(temp2);
tmp3=mean(temp3);
tmp4=mean(temp4)
tmp5=mean(temp5)

