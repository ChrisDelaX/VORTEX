function[sres]=rhomb(x0)

% tau1=x0(1);
% tau2=x0(2);

eps1=x0(1);
tau2=x0(2);

%     %Pas du r�seau
%         Lb_tmp=0.9;         
%        
% 	%Epaisseur totale
% 	    d_tmp=1.1328 ;d_min=0.9;d_max=1.3
%         
%     %Facteurs de re0mplissage moyen         
%         F_tmp=0.2778;F_min=0.16;F_max=0.33;
% 
%          %Angle incidence non conique
%             theta=  1.1396;
%             thetamin=1.1221;thetamax=1.1571;
%             

% clear all

load phiphi
%phiphi calcul� avec 12 ordres, 32 points en lambda et 120 en theta (120*32)

load theta
% thetamin=1.1221;thetamax=1.1571;n=120;
% 
% for j=1:120,
%     theta(j)=thetamin+(j-1)*(thetamax-thetamin)/(120-1);
% end;

load ind
for i=1:100,

    lb(i)=6+(i-1)*(14-6)/(100);
    
%Input incidence

% eps1=+0/180*pi;
% n(i)=sqrt(ind(i));
n(i)=1/ind(i);


%Rhomb1

w1=1/180*pi;w2=0./180*pi;
% tau1=asin(sin(1e-3)*2.4);
tau1=0;


th=65/180*pi+2/60/180*pi-(w1-asin(1/(1/ind(50))*sin(w1)))/2;

%Rhomb2
w3=-1/180*pi;w4=0./180*pi;
% tau2=-tau1;


%Interface 1
r1=asin(1/n(i)*sin(eps1-(w1+tau1)))
a1=(w1+tau1)+r1
psi1=a1-tau1
alpha1=th+psi1;
phi1=spline(theta,phiphi(:,i),alpha1);

%Interface 2
r2=asin(n(i)*sin(a1-(w2+tau1)));
a2=(w2+tau1)+r2;

%Interface 3
r3=asin(1/n(i)*sin(a2-(w3+tau2)));
a3=(w3+tau2)+r3;
psi3=-a3+tau2;
alpha3=th+psi3;
phi2=spline(theta,phiphi(:,i),alpha3);

%Interface 4
r4=asin(n(i)*sin(a3-(w4+tau2)));
a4=(w4+tau2)+r4;

dphi(i)=2*phi1+2*phi2;

end;

res=(dphi-pi).^2/4;
plot(lb,res);axis square;set(gca,'YScale','log');

sres=mean(res)