
clear all;%close all;

global EI_choice EIII_choice E1_choice E2_choice  E_AR_choice lb nlb lb_t lbmax lbmin E_man EI_t

theta=1.1;
lbmin=6;lbmax=14;
nlb=100;

%Permittivit�s
%-------------
	
	%Choix mat�riau
        
        %1: Vide/Air
        %2: CdTe
        %3: Diamant
        %4: Germanium
        %5: Silicium
        %6: ZnSe
        %7: YF3
        %8: Manuel
        %9: AsGa
        E_man=1.5-sqrt(-1)*11;
            %LaF2: E_man=1.57;
            %BaF2: E_man(l=1.97 microns)=1.4647
            %BaF2: E_man(l=2.3253 microns)=1.4635
            %BaF2: E_man(l=2.6738 microns)=1.4623
        
        %Permittivit�s milieu ext�rieur incident
        
        EI_choice=19;
        
        %Permittivit�s milieu ext�rieur �mergent
        
        EIII_choice=1;
        
                %Permittivit� milieu 1
                
                E1_choice=1;
                
                %Permittivit� milieu 2
                
                E2_choice=3; E_AR_choice=7;
        
        x0=[theta];
        
        [x,fval,exitflag] = fminsearch(@d_phi,x0,optimset('MaxIter',200,'Display','iter','TolX',1e-3,'TolFun',1e-10));