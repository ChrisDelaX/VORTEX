%Configuration g�n�rale du probl�me
%----------------------------------

%Balayage
%--------

%Choix param�tre
%---------------

%REMARQUE: Unit�s en MICRONS !!!

%1: p�riode, pas du r�seau
%2: �paisseur
%3: facteur de remplissage Fa, grande base du trap�ze
%4: facteur de remplissage Fb, petite base du trap�ze
%5: angle d'incidence non conique
%6: angle d'incidence conique
%7: angle de polarisation
%8: longueur d'onde 
%9: �paisseur A/R
%10: NA

scan1=10;
mesh1=20;
    scan2=2;
    mesh2=30;
        scan3=3;
        mesh3=30;
            scan4=9;
            mesh4=30;
                scan5=8;
                mesh5=30;

%Param�tres de calculs
%---------------------

    %Troncature
    
        %En X (N donc 2N+1 ordres au total)  
    
        N=8;
              
%Param�tres du r�seau
%--------------------    

%0.7076    2.7115    0.7188    0.4040
   
                
    
%Pas du r�seau
    
    Lb=0.42   ;
    Lbmin=0.36;Lbmax=.440;
    
%Epaisseurs

    d=2.88     ;
    dmin=0.7;dmax=1.3;
    
%Permittivit�s
%-------------

%Choix mat�riau
    
    %1: Vide/Air
    %2: CdTe
    %3: Diamant
    %4: Germanium
    %5: Silicium
    %6: ZnSe
    %7: YF3
    %8: Manuel
    E_man=1.57;
        %LaF2: E_man=1.57;
        %BaF2: E_man(l=1.97 microns)=1.4647
        %BaF2: E_man(l=2.3253 microns)=1.4635
        %BaF2: E_man(l=2.6738 microns)=1.4623
    
    %Permittivit�s milieu ext�rieur �mergent (!!!! INVERSION)
    
    EI_choice=1;
    
    %Permittivit�s milieu ext�rieur incident (!!!! INVERSION)
    
    EIII_choice=5;
    
    %Permittivit�s du r�seau
    %-----------------------
    
        %R�seau en relief de surface
        %---------------------------
        
            %Permittivit� milieu 1
            
            E1_choice=1;
            
            %Permittivit� milieu 2
            
            E2_choice=5;
                                   
            %Facteurs de remplissage
            
            Fa=0.9 ;% Grande Base trap�ze
            Famin=0.50;Famax=0.8;
            
            %Fb=0.3;
            Fb=Fa;% Petite Base trap�ze
            if Fb==Fa  
            Fbmin=Famin;Fbmax=Fbmin;
            else
            Fbmin=0.5;Fbmax=0.9;
            end;
            
        %Permittivit�s pseudo A/R
        %------------------------
           
            E_AR_choice=7;
            d_AR=0.413;
            d_AR_min=0.300;d_AR_max=0.450;
              
        %R�seau en volume
        %----------------
                
            %Permittivit� moyenne
            
            %epsm(l)=;
            
            %Modulation de permittivit�
            
            %modmin(l)=;
            %modmax(l)=;
            %mod(l)=;                       
            
%Nombre de couches
%-----------------

    L_wo_AR=1;%hors A/R
    
    %Sans Pseudo-A/R YF3 : 1
    
    ar=2;%par d�faut ar=1
       
    %Avec Pseudo-A/R : 2
    
    %Avec Pseudo-A/R sur r�seau trap�zoidal : 3
    
%     if ar==2
%         if Fb==Fa
%         ar=2;%3 couches
%         else
%         %TBD!!!
%         ar=3;%au moins 5 couches, pour la pr�cision de la discr�tisation
%         end;
%     end;
    
%Onde incidente 
%--------------

    %Longueur d'onde
    
    lb=4;
    lbmin=1.475;lbmax=2.4;%nlb=32;

    %Angle incidence non conique
    
    
    theta=0;
    %theta=39.5*pi/180;
    thetamin=35*pi/180;thetamax=50*pi/180;
   
    %Angle incidence conique

    phi=0*pi/180;
    phimin=0;phimax=0;
        
    %Angle polarisation
    
    psi=pi/4;
    psimin=0;psimax=0;
    
        
        
    

    

    
