function[null_res_sp]=null(x0)

global EI_choice EIII_choice E1_choice E2_choice lbmin lbmax theta phi psi E_AR_choice L_wo_AR ar E_man N nlb tmp1 tmp2 tmp3 tmp4 tmp5 Fa Fb

% EI_choice=varargin(1);
% EIII_choice=varargin(2);
% E1_choice=varargin(3);
% E2_choice=varargin(4);
% lbmin=varargin(5);
% lbmax=varargin(6);
% theta=varargin(7);
% phi=varargin(8);
% psi=varargin(9);
% E_AR_choice=varargin(10);
% L_wo_AR=varargin(11);
% ar=varargin(12);
% E_man=varargin(13);
% N=varargin(14);

%x0=[Lb,d,Fa,d_AR]

Lb=abs(x0(1));
d=abs(x0(2));
%Fa=abs(x0(3));
% Fb=abs(x0(4));
d_AR=abs(x0(3));

x0tmp=x0

for ib=1:nlb,
                lb_t(ib)=lbmin+ib*(lbmax-lbmin)/nlb;
                lb=lb_t(ib);          

%Dispersion mat�riaux
%--------------------

material;

%Profile
%-------
    
profile;
                
Main;%Output;

temp1(ib)=2*DET_s(N+1);
temp2(ib)=2*DET_p(N+1);
temp4(ib)=2*DER_s(N+1);
temp5(ib)=2*DER_p(N+1);
%E1
%E2
temp3(ib)=mod(dphi_sp_T,2*pi);

q(ib)=(temp1(ib)./temp2(ib));

nul_phase_fin(ib)=(temp3(ib)-pi).^2;

nul_res_sp_b(ib)=(((1+sqrt(q(ib))).^2)./((1-sqrt(q(ib))).^2+nul_phase_fin(ib).*sqrt(q(ib)))).^(-1);

end;

null_res_sp=mean(nul_res_sp_b);

%null_res_sp=(nul_res_sp_b(8)+nul_res_sp_b(41))/2;

 %figure;plot(lb_t,nul_res_sp_b);

% tmp1=mean(temp1);
% tmp2=mean(temp2);
% tmp3=mean(temp3);
% tmp4=mean(temp4);
% tmp5=mean(temp5);

tmp1=(temp1);
tmp2=(temp2);
tmp3=(temp3);
tmp4=(temp4);
tmp5=(temp5);

