function[phi]=d_phi(theta)

global EI_choice EI_t EIII_choice E1_choice E2_choice  E_AR_choice lb nlb lbmax lbmin E_man

for ib=1:nlb,
                lb_t(ib)=lbmin+ib*(lbmax-lbmin)/nlb;
                lb=lb_t(ib)  ;       

material;

EI_t(ib)=EI;

nti(ib)=sqrt(EIII/EI);

%theta=x0;
phi_s(ib)=2*atan((sqrt((sin(theta))^2-nti(ib).^2))/(nti(ib)^2*cos(theta)));
phi_p(ib)=2*atan((sqrt((sin(theta))^2-nti(ib).^2))/(cos(theta)));
dphi(ib)=2*atan((sqrt((sin(theta))^2-nti(ib).^2))/(nti(ib)^2*cos(theta)))-2*atan((sqrt((sin(theta))^2-nti(ib).^2))/(cos(theta)));
nul_phase_fin(ib)=((4*dphi(ib)-pi).^2)/4;
end;

phi(1:nlb,1:2)=[phi_s(1:nlb), phi_b(1:nlb)];